pub mod evm_config;
pub mod evm_factory;
pub mod execution_path;
pub mod executor;
pub mod precompile_random;
pub mod read_log;
pub mod restored_slots;
pub mod state_diff;
pub mod witness;

pub use evm_config::N42EvmConfig;
pub use evm_factory::N42EvmFactory;
pub use execution_path::{EvmStrategy, ExecutionPath, ExecutionWorkload};
pub use executor::{
    ParallelExecutionSummary, execute_block_full, execute_block_parallel,
    execute_block_with_witness, parallel_evm_enabled,
};
pub use read_log::{ReadLogDatabase, ReadLogEntry};
pub use restored_slots::{
    RestoredSlot, TrackingBlockExecutorFactory, TrackingExecutor, record_restored_slots,
    restored_slots_for, restored_slots_key,
};
