use alloy_primitives::{Address, B256, U256};
use revm::database::BundleState;
use std::collections::BTreeMap;
use tracing::debug;

/// State diff for a single block: all account and storage changes.
/// Extracted from revm's `BundleState` for incremental sync and state updates.
#[derive(Debug, Clone, Default, serde::Serialize, serde::Deserialize)]
pub struct StateDiff {
    /// Per-account changes in this block.
    pub accounts: BTreeMap<Address, AccountDiff>,
}

/// Changes to a single account in a block.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct AccountDiff {
    /// The type of change to this account.
    pub change_type: AccountChangeType,
    /// Balance before and after (if account existed).
    pub balance: Option<ValueChange<U256>>,
    /// Nonce before and after (if account existed).
    pub nonce: Option<ValueChange<u64>>,
    /// Code change: None if unchanged, Some with old/new bytecode hashes.
    pub code_change: Option<ValueChange<Option<B256>>>,
    /// Storage slot changes for this account.
    pub storage: BTreeMap<U256, ValueChange<U256>>,
}

/// Type of account-level change.
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum AccountChangeType {
    /// Account was created in this block.
    Created,
    /// Account was modified (balance, nonce, code, or storage changed).
    Modified,
    /// Account was destroyed (via SELFDESTRUCT or equivalent).
    Destroyed,
}

/// A before/after pair for tracking a value change.
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct ValueChange<T> {
    /// Value before the block execution.
    pub from: T,
    /// Value after the block execution.
    pub to: T,
}

impl<T> ValueChange<T> {
    /// Creates a new value change.
    pub fn new(from: T, to: T) -> Self {
        Self { from, to }
    }
}

impl StateDiff {
    /// Returns the number of changed accounts.
    pub fn len(&self) -> usize {
        self.accounts.len()
    }

    /// Returns true if no accounts changed.
    pub fn is_empty(&self) -> bool {
        self.accounts.is_empty()
    }

    /// Returns the number of created accounts.
    pub fn created_count(&self) -> usize {
        self.accounts
            .values()
            .filter(|a| a.change_type == AccountChangeType::Created)
            .count()
    }

    /// Returns the number of modified accounts.
    pub fn modified_count(&self) -> usize {
        self.accounts
            .values()
            .filter(|a| a.change_type == AccountChangeType::Modified)
            .count()
    }

    /// Returns the number of destroyed accounts.
    pub fn destroyed_count(&self) -> usize {
        self.accounts
            .values()
            .filter(|a| a.change_type == AccountChangeType::Destroyed)
            .count()
    }

    /// Returns the total number of storage slot changes across all accounts.
    pub fn total_storage_changes(&self) -> usize {
        self.accounts.values().map(|a| a.storage.len()).sum()
    }

    /// Extracts a state diff from a revm `BundleState`.
    ///
    /// The `BundleState` tracks all account and storage changes with their
    /// original values, which allows us to construct a complete before/after diff.
    pub fn from_bundle_state(bundle: &BundleState) -> Self {
        let mut accounts = BTreeMap::new();

        for (address, bundle_account) in &bundle.state {
            let was_destroyed = bundle_account.was_destroyed();
            let original_info = bundle_account.original_info.as_ref();
            let current_info = bundle_account.info.as_ref();

            // `was_destroyed()` is true for revm's `DestroyedChanged` status — an
            // account SELFDESTRUCTed and then RE-CREATED within the same block
            // (reachable under EIP-6780: create+selfdestruct in one tx, then touch
            // the same address later in the block). In that case `current_info` is
            // `Some` and the account EXISTS at block end. Classifying it as
            // `Destroyed` would push `key→None` in apply_diff and drop the live
            // account from the state tree (wrong root / wrong mobile proofs), so
            // the post-state presence (`current_info`) — not `was_destroyed` —
            // decides existence. `Destroyed` is reserved for accounts absent at
            // block end.
            let change_type = match (original_info.is_some(), current_info.is_some()) {
                (_, false) => AccountChangeType::Destroyed,
                (false, true) => AccountChangeType::Created,
                (true, true) => AccountChangeType::Modified,
            };
            debug_assert!(
                change_type != AccountChangeType::Destroyed || current_info.is_none(),
                "account {address:?} classified Destroyed but still present at block end"
            );

            // Extract balance change
            let balance = match (original_info, current_info) {
                (Some(orig), Some(curr)) => Some(ValueChange::new(orig.balance, curr.balance)),
                (None, Some(curr)) => Some(ValueChange::new(U256::ZERO, curr.balance)),
                (Some(orig), None) => Some(ValueChange::new(orig.balance, U256::ZERO)),
                (None, None) => None,
            };

            // Extract nonce change
            let nonce = match (original_info, current_info) {
                (Some(orig), Some(curr)) => Some(ValueChange::new(orig.nonce, curr.nonce)),
                (None, Some(curr)) => Some(ValueChange::new(0, curr.nonce)),
                (Some(orig), None) => Some(ValueChange::new(orig.nonce, 0)),
                (None, None) => None,
            };

            // Extract code change (track by code hash)
            let code_change = match (original_info, current_info) {
                (Some(orig), Some(curr)) if orig.code_hash != curr.code_hash => {
                    Some(ValueChange::new(Some(orig.code_hash), Some(curr.code_hash)))
                }
                (None, Some(curr)) if curr.code_hash != revm::primitives::KECCAK_EMPTY => {
                    Some(ValueChange::new(None, Some(curr.code_hash)))
                }
                (Some(orig), None) if orig.code_hash != revm::primitives::KECCAK_EMPTY => {
                    Some(ValueChange::new(Some(orig.code_hash), None))
                }
                _ => None,
            };

            // Extract storage changes (skip unchanged slots)
            let mut storage = BTreeMap::new();
            for (slot, slot_value) in &bundle_account.storage {
                if slot_value.previous_or_original_value == slot_value.present_value {
                    continue;
                }
                storage.insert(
                    *slot,
                    ValueChange::new(
                        slot_value.previous_or_original_value,
                        slot_value.present_value,
                    ),
                );
            }

            // Only include accounts that actually changed
            let has_changes = balance.as_ref().is_some_and(|v| v.from != v.to)
                || nonce.as_ref().is_some_and(|v| v.from != v.to)
                || code_change.is_some()
                || !storage.is_empty()
                || was_destroyed;

            if has_changes {
                accounts.insert(
                    *address,
                    AccountDiff {
                        change_type,
                        balance,
                        nonce,
                        code_change,
                        storage,
                    },
                );
            }
        }

        debug!(
            target: "n42::execution",
            total = accounts.len(),
            "state diff extracted"
        );

        Self { accounts }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use alloy_primitives::{Address, B256, U256};
    use revm::database::states::StorageSlot;
    use revm::database::{AccountStatus, BundleAccount, BundleState, StorageWithOriginalValues};
    use revm::state::AccountInfo;

    /// Helper: create an AccountInfo with the given balance and nonce.
    fn make_account_info(balance: u64, nonce: u64) -> AccountInfo {
        AccountInfo {
            balance: U256::from(balance),
            nonce,
            code_hash: revm::primitives::KECCAK_EMPTY,
            code: None,
            account_id: None,
        }
    }

    /// Helper: create a BundleAccount for a newly created account.
    fn created_account(balance: u64, nonce: u64) -> BundleAccount {
        BundleAccount {
            info: Some(make_account_info(balance, nonce)),
            original_info: None,
            storage: StorageWithOriginalValues::default(),
            status: AccountStatus::InMemoryChange,
        }
    }

    /// Helper: create a BundleAccount for a modified account.
    fn modified_account(
        orig_balance: u64,
        orig_nonce: u64,
        new_balance: u64,
        new_nonce: u64,
    ) -> BundleAccount {
        BundleAccount {
            info: Some(make_account_info(new_balance, new_nonce)),
            original_info: Some(make_account_info(orig_balance, orig_nonce)),
            storage: StorageWithOriginalValues::default(),
            status: AccountStatus::Changed,
        }
    }

    /// Helper: create a BundleAccount for a destroyed account.
    fn destroyed_account(orig_balance: u64, orig_nonce: u64) -> BundleAccount {
        BundleAccount {
            info: None,
            original_info: Some(make_account_info(orig_balance, orig_nonce)),
            storage: StorageWithOriginalValues::default(),
            status: AccountStatus::Destroyed,
        }
    }

    /// Helper: create a storage slot change.
    fn storage_slot(from: u64, to: u64) -> StorageSlot {
        StorageSlot::new_changed(U256::from(from), U256::from(to))
    }

    #[test]
    fn test_value_change_new() {
        let vc = ValueChange::new(10u64, 20u64);
        assert_eq!(vc.from, 10);
        assert_eq!(vc.to, 20);
    }

    #[test]
    fn test_value_change_equality() {
        let vc1 = ValueChange::new(U256::from(5), U256::from(10));
        let vc2 = ValueChange::new(U256::from(5), U256::from(10));
        let vc3 = ValueChange::new(U256::from(5), U256::from(20));

        assert_eq!(vc1, vc2, "same from/to should be equal");
        assert_ne!(vc1, vc3, "different 'to' should not be equal");
    }

    #[test]
    fn test_account_change_type_equality() {
        assert_eq!(AccountChangeType::Created, AccountChangeType::Created);
        assert_eq!(AccountChangeType::Modified, AccountChangeType::Modified);
        assert_eq!(AccountChangeType::Destroyed, AccountChangeType::Destroyed);
        assert_ne!(AccountChangeType::Created, AccountChangeType::Modified);
        assert_ne!(AccountChangeType::Modified, AccountChangeType::Destroyed);
    }

    #[test]
    fn test_state_diff_default_empty() {
        let diff = StateDiff::default();
        assert!(diff.is_empty(), "default state diff should be empty");
        assert_eq!(diff.len(), 0);
    }

    #[test]
    fn test_state_diff_from_empty_bundle() {
        let bundle = BundleState::default();
        let diff = StateDiff::from_bundle_state(&bundle);
        assert!(diff.is_empty(), "empty bundle should produce empty diff");
    }

    #[test]
    fn test_state_diff_created_account() {
        let addr = Address::with_last_byte(1);
        let mut bundle = BundleState::default();
        bundle.state.insert(addr, created_account(1000, 0));

        let diff = StateDiff::from_bundle_state(&bundle);
        assert_eq!(diff.len(), 1, "should have one changed account");

        let account_diff = diff.accounts.get(&addr).expect("addr should be in diff");
        assert_eq!(account_diff.change_type, AccountChangeType::Created);

        // Balance: 0 → 1000
        let bal = account_diff
            .balance
            .as_ref()
            .expect("should have balance change");
        assert_eq!(bal.from, U256::ZERO);
        assert_eq!(bal.to, U256::from(1000));

        // Nonce: 0 → 0 (no change, but still recorded)
        let nc = account_diff.nonce.as_ref().expect("should have nonce");
        assert_eq!(nc.from, 0);
        assert_eq!(nc.to, 0);
    }

    #[test]
    fn test_state_diff_modified_account() {
        let addr = Address::with_last_byte(2);
        let mut bundle = BundleState::default();
        bundle.state.insert(addr, modified_account(500, 1, 1000, 2));

        let diff = StateDiff::from_bundle_state(&bundle);
        assert_eq!(diff.len(), 1);

        let account_diff = diff.accounts.get(&addr).unwrap();
        assert_eq!(account_diff.change_type, AccountChangeType::Modified);

        let bal = account_diff.balance.as_ref().unwrap();
        assert_eq!(bal.from, U256::from(500));
        assert_eq!(bal.to, U256::from(1000));

        let nc = account_diff.nonce.as_ref().unwrap();
        assert_eq!(nc.from, 1);
        assert_eq!(nc.to, 2);
    }

    #[test]
    fn test_state_diff_destroyed_account() {
        let addr = Address::with_last_byte(3);
        let mut bundle = BundleState::default();
        bundle.state.insert(addr, destroyed_account(2000, 5));

        let diff = StateDiff::from_bundle_state(&bundle);
        assert_eq!(diff.len(), 1);

        let account_diff = diff.accounts.get(&addr).unwrap();
        assert_eq!(account_diff.change_type, AccountChangeType::Destroyed);

        let bal = account_diff.balance.as_ref().unwrap();
        assert_eq!(bal.from, U256::from(2000));
        assert_eq!(bal.to, U256::ZERO);
    }

    #[test]
    fn test_state_diff_storage_changes() {
        let addr = Address::with_last_byte(4);
        let mut account = modified_account(100, 1, 200, 2);
        account.storage.insert(U256::from(0), storage_slot(42, 99));
        account.storage.insert(U256::from(1), storage_slot(0, 100));

        let mut bundle = BundleState::default();
        bundle.state.insert(addr, account);

        let diff = StateDiff::from_bundle_state(&bundle);
        let account_diff = diff.accounts.get(&addr).unwrap();

        assert_eq!(
            account_diff.storage.len(),
            2,
            "should have 2 storage slot changes"
        );

        let slot0 = account_diff.storage.get(&U256::from(0)).unwrap();
        assert_eq!(slot0.from, U256::from(42));
        assert_eq!(slot0.to, U256::from(99));

        let slot1 = account_diff.storage.get(&U256::from(1)).unwrap();
        assert_eq!(slot1.from, U256::ZERO);
        assert_eq!(slot1.to, U256::from(100));
    }

    /// Reproduces the production state-tree path: a `BundleState` carrying a
    /// storage change is serialized to JSON and back (exactly what
    /// `CompactBlockExecution` does for the compact-block broadcast), then a
    /// `StateDiff` is extracted on the receiving side. Asserts storage survives
    /// the round-trip — isolates whether the `storage_changes=0` field observed
    /// in the real-node profile (devlog-71) is a serde-drop or an upstream
    /// capture issue.
    #[test]
    fn test_bundle_state_serde_roundtrip_preserves_storage() {
        let addr = Address::with_last_byte(7);
        let mut account = modified_account(100, 1, 200, 2);
        account.storage.insert(U256::from(0), storage_slot(0, 99));
        account.storage.insert(U256::from(7), storage_slot(5, 0));

        let mut bundle = BundleState::default();
        bundle.state.insert(addr, account);

        // Sanity: pre-roundtrip the diff sees the storage.
        assert_eq!(
            StateDiff::from_bundle_state(&bundle).total_storage_changes(),
            2
        );

        // Round-trip through serde_json, as the compact-block broadcast does.
        let json = serde_json::to_vec(&bundle).expect("BundleState should serialize");
        let restored: BundleState =
            serde_json::from_slice(&json).expect("BundleState should deserialize");

        let diff = StateDiff::from_bundle_state(&restored);
        assert_eq!(
            diff.total_storage_changes(),
            2,
            "storage changes must survive the serde_json round-trip"
        );
        let account_diff = diff.accounts.get(&addr).expect("account should be present");
        assert_eq!(
            account_diff.storage.get(&U256::from(0)).unwrap().to,
            U256::from(99)
        );
        assert_eq!(
            account_diff.storage.get(&U256::from(7)).unwrap().from,
            U256::from(5)
        );
    }

    #[test]
    fn test_state_diff_no_actual_change_filtered() {
        // An account where nothing actually changed (balance, nonce, code all same)
        // should be filtered out.
        let addr = Address::with_last_byte(5);
        let account = modified_account(100, 1, 100, 1); // same values

        let mut bundle = BundleState::default();
        bundle.state.insert(addr, account);

        let diff = StateDiff::from_bundle_state(&bundle);
        assert!(
            diff.is_empty(),
            "account with no actual changes should be filtered out"
        );
    }

    #[test]
    fn test_state_diff_code_change() {
        let addr = Address::with_last_byte(6);
        let old_hash = B256::repeat_byte(0xAA);
        let new_hash = B256::repeat_byte(0xBB);

        let account = BundleAccount {
            info: Some(AccountInfo {
                balance: U256::from(100),
                nonce: 1,
                code_hash: new_hash,
                code: None,
                account_id: None,
            }),
            original_info: Some(AccountInfo {
                balance: U256::from(100),
                nonce: 1,
                code_hash: old_hash,
                code: None,
                account_id: None,
            }),
            storage: StorageWithOriginalValues::default(),
            status: AccountStatus::Changed,
        };

        let mut bundle = BundleState::default();
        bundle.state.insert(addr, account);

        let diff = StateDiff::from_bundle_state(&bundle);
        assert_eq!(diff.len(), 1);

        let account_diff = diff.accounts.get(&addr).unwrap();
        let code_change = account_diff
            .code_change
            .as_ref()
            .expect("should have code change");
        assert_eq!(code_change.from, Some(old_hash));
        assert_eq!(code_change.to, Some(new_hash));
    }

    #[test]
    fn test_state_diff_serde_json_roundtrip() {
        let addr = Address::with_last_byte(1);
        let mut diff = StateDiff::default();
        diff.accounts.insert(
            addr,
            AccountDiff {
                change_type: AccountChangeType::Created,
                balance: Some(ValueChange::new(U256::ZERO, U256::from(1000))),
                nonce: Some(ValueChange::new(0u64, 1u64)),
                code_change: None,
                storage: BTreeMap::new(),
            },
        );

        let json = serde_json::to_string(&diff).expect("json serialize");
        let deserialized: StateDiff = serde_json::from_str(&json).expect("json deserialize");

        assert_eq!(deserialized.len(), 1);
        let account = deserialized.accounts.get(&addr).unwrap();
        assert_eq!(account.change_type, AccountChangeType::Created);
        assert_eq!(account.balance.unwrap().to, U256::from(1000));
    }

    #[test]
    fn test_state_diff_bincode_roundtrip() {
        let addr = Address::with_last_byte(2);
        let mut storage = BTreeMap::new();
        storage.insert(
            U256::from(0),
            ValueChange::new(U256::from(10), U256::from(20)),
        );

        let mut diff = StateDiff::default();
        diff.accounts.insert(
            addr,
            AccountDiff {
                change_type: AccountChangeType::Modified,
                balance: Some(ValueChange::new(U256::from(100), U256::from(200))),
                nonce: Some(ValueChange::new(5u64, 6u64)),
                code_change: Some(ValueChange::new(
                    Some(B256::repeat_byte(0xAA)),
                    Some(B256::repeat_byte(0xBB)),
                )),
                storage,
            },
        );

        let encoded = bincode::serialize(&diff).expect("bincode serialize");
        let decoded: StateDiff = bincode::deserialize(&encoded).expect("bincode deserialize");

        assert_eq!(decoded.len(), 1);
        let account = decoded.accounts.get(&addr).unwrap();
        assert_eq!(account.change_type, AccountChangeType::Modified);
        assert_eq!(account.storage.len(), 1);
    }

    #[test]
    fn test_account_change_type_serde_roundtrip() {
        for variant in [
            AccountChangeType::Created,
            AccountChangeType::Modified,
            AccountChangeType::Destroyed,
        ] {
            let json = serde_json::to_string(&variant).expect("serialize");
            let deserialized: AccountChangeType = serde_json::from_str(&json).expect("deserialize");
            assert_eq!(variant, deserialized);
        }
    }

    #[test]
    fn test_state_diff_multiple_accounts() {
        let addr1 = Address::with_last_byte(10);
        let addr2 = Address::with_last_byte(20);
        let addr3 = Address::with_last_byte(30);

        let mut bundle = BundleState::default();
        bundle.state.insert(addr1, created_account(100, 0));
        bundle.state.insert(addr2, modified_account(200, 1, 300, 2));
        bundle.state.insert(addr3, destroyed_account(400, 3));

        let diff = StateDiff::from_bundle_state(&bundle);
        assert_eq!(diff.len(), 3, "should have 3 changed accounts");

        assert_eq!(
            diff.accounts[&addr1].change_type,
            AccountChangeType::Created
        );
        assert_eq!(
            diff.accounts[&addr2].change_type,
            AccountChangeType::Modified
        );
        assert_eq!(
            diff.accounts[&addr3].change_type,
            AccountChangeType::Destroyed
        );
    }

    #[test]
    fn test_state_diff_summary_methods() {
        let addr1 = Address::with_last_byte(10);
        let addr2 = Address::with_last_byte(20);
        let addr3 = Address::with_last_byte(30);
        let addr4 = Address::with_last_byte(40);

        let mut bundle = BundleState::default();
        bundle.state.insert(addr1, created_account(100, 0));
        bundle.state.insert(addr2, modified_account(200, 1, 300, 2));

        let mut destroyed = destroyed_account(400, 3);
        destroyed.storage.insert(U256::from(0), storage_slot(10, 0));
        bundle.state.insert(addr3, destroyed);

        let mut modified_with_storage = modified_account(500, 4, 600, 5);
        modified_with_storage
            .storage
            .insert(U256::from(0), storage_slot(0, 42));
        modified_with_storage
            .storage
            .insert(U256::from(1), storage_slot(0, 99));
        bundle.state.insert(addr4, modified_with_storage);

        let diff = StateDiff::from_bundle_state(&bundle);
        assert_eq!(diff.len(), 4);
        assert_eq!(diff.created_count(), 1);
        assert_eq!(diff.modified_count(), 2);
        assert_eq!(diff.destroyed_count(), 1);
        assert_eq!(
            diff.total_storage_changes(),
            3,
            "1 slot from destroyed + 2 from modified"
        );
    }

    #[test]
    fn test_state_diff_summary_empty() {
        let diff = StateDiff::default();
        assert_eq!(diff.created_count(), 0);
        assert_eq!(diff.modified_count(), 0);
        assert_eq!(diff.destroyed_count(), 0);
        assert_eq!(diff.total_storage_changes(), 0);
    }

    #[test]
    fn test_state_diff_unchanged_storage_filtered() {
        let addr = Address::with_last_byte(7);
        let mut account = modified_account(100, 1, 200, 2);
        // Add a storage slot where value did NOT change.
        account.storage.insert(
            U256::from(0),
            StorageSlot::new_changed(U256::from(42), U256::from(42)),
        );
        // Add a storage slot that DID change.
        account.storage.insert(U256::from(1), storage_slot(0, 99));

        let mut bundle = BundleState::default();
        bundle.state.insert(addr, account);

        let diff = StateDiff::from_bundle_state(&bundle);
        let account_diff = diff.accounts.get(&addr).unwrap();
        assert_eq!(
            account_diff.storage.len(),
            1,
            "unchanged storage slot should be filtered out"
        );
        assert!(account_diff.storage.contains_key(&U256::from(1)));
        assert!(!account_diff.storage.contains_key(&U256::from(0)));
    }

    #[test]
    fn test_state_diff_destroyed_with_storage() {
        let addr = Address::with_last_byte(8);
        let mut account = destroyed_account(500, 2);
        account.storage.insert(U256::from(5), storage_slot(100, 0));

        let mut bundle = BundleState::default();
        bundle.state.insert(addr, account);

        let diff = StateDiff::from_bundle_state(&bundle);
        let account_diff = diff.accounts.get(&addr).unwrap();
        assert_eq!(account_diff.change_type, AccountChangeType::Destroyed);
        assert_eq!(account_diff.storage.len(), 1);
        let slot = account_diff.storage.get(&U256::from(5)).unwrap();
        assert_eq!(slot.from, U256::from(100));
        assert_eq!(slot.to, U256::ZERO);
    }

    /// Helper: an account SELFDESTRUCTed and then RE-CREATED within the same
    /// block — revm's `DestroyedChanged` status. `was_destroyed()` is true yet
    /// `info` is `Some` (the account exists at block end).
    fn destroyed_then_recreated(
        orig_balance: u64,
        orig_nonce: u64,
        new_balance: u64,
        new_nonce: u64,
    ) -> BundleAccount {
        BundleAccount {
            info: Some(make_account_info(new_balance, new_nonce)),
            original_info: Some(make_account_info(orig_balance, orig_nonce)),
            storage: StorageWithOriginalValues::default(),
            status: AccountStatus::DestroyedChanged,
        }
    }

    /// Regression: a destroyed-then-recreated account (revm `DestroyedChanged`,
    /// reachable under EIP-6780) must NOT be classified `Destroyed` — it exists
    /// at block end, and labeling it `Destroyed` would drop the live account
    /// from the state tree (apply_diff pushes `key→None`). It must be `Modified`
    /// (existed before the block) carrying the recreated info.
    #[test]
    fn test_state_diff_destroyed_then_recreated_is_not_dropped() {
        let addr = Address::with_last_byte(9);
        let mut bundle = BundleState::default();
        bundle
            .state
            .insert(addr, destroyed_then_recreated(2000, 5, 700, 1));

        let diff = StateDiff::from_bundle_state(&bundle);
        let account_diff = diff.accounts.get(&addr).expect("addr should be in diff");

        assert_eq!(
            account_diff.change_type,
            AccountChangeType::Modified,
            "destroyed-then-recreated must stay live, not Destroyed"
        );
        // Carries the recreated (post-block) balance/nonce.
        assert_eq!(account_diff.balance.as_ref().unwrap().to, U256::from(700));
        assert_eq!(account_diff.nonce.as_ref().unwrap().to, 1);
    }

    /// A freshly-created account that SELFDESTRUCTs in the same block ends absent
    /// (revm `Destroyed` with `original_info == None`): net-absent ⇒ `Destroyed`.
    #[test]
    fn test_state_diff_created_then_destroyed_is_absent() {
        let addr = Address::with_last_byte(10);
        let mut bundle = BundleState::default();
        bundle.state.insert(
            addr,
            BundleAccount {
                info: None,
                original_info: None,
                storage: StorageWithOriginalValues::default(),
                status: AccountStatus::Destroyed,
            },
        );

        let diff = StateDiff::from_bundle_state(&bundle);
        let account_diff = diff.accounts.get(&addr).expect("addr should be in diff");
        assert_eq!(account_diff.change_type, AccountChangeType::Destroyed);
    }
}
