pub(crate) mod bad_block_cache;
mod consensus_loop;
mod execution_bridge;
pub use execution_bridge::compact_block_enabled;
mod state_mgmt;
mod view_jump_throttle;

use crate::blob_port::BlobStorePort;
use crate::consensus_state::{PoolDepthSnapshot, SharedConsensusState};
use crate::el::{ExecutionLayer, ExecutionPath};
use crate::epoch_schedule::EpochSchedule;
use crate::exec_cache::ExecutionOutputCache;
use crate::net_port::ConsensusNetwork;
use crate::sinks::{StakingSink, StateSink, WithdrawalSource, ZkSink};
use alloy_primitives::{Address, B256};
use alloy_rpc_types_engine::{ExecutionData, ForkchoiceState, PayloadStatusEnum};
use metrics::{counter, gauge, histogram};
use n42_consensus::{
    AuthenticatedConsensusMessage, ConsensusEngine, EngineOutput, FUTURE_VIEW_WINDOW, ValidatorSet,
};
use n42_network::{NetworkError, NetworkEvent, PeerId, SyncPayload};
#[cfg(debug_assertions)]
use n42_primitives::BlsSecretKey;
use n42_primitives::{ConsensusMessage, QuorumCertificate};
use std::collections::{BTreeMap, HashMap, HashSet, VecDeque};
use std::path::PathBuf;
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::mpsc;
use tokio::time::Instant;
use tracing::{debug, error, info, warn};

/// Batched network transaction import payload sent to the tx-pool bridge. Defined
/// locally (identical to `tx_bridge::TxImportBatch`) so the consensus service does
/// not depend on the reth-coupled `tx_bridge` module — both are `Vec<Vec<u8>>`, so
/// the channel ends stay compatible.
pub type TxImportBatch = Vec<Vec<u8>>;

/// zstd magic bytes: all zstd frames start with 0x28B52FFD.
const ZSTD_MAGIC: [u8; 4] = [0x28, 0xB5, 0x2F, 0xFD];
/// 1M transfer transactions are about 78 MiB before envelope/sidecar data.
/// Keep a bounded but non-blocking ceiling above that target; the old 64 MiB
/// limit made the new chunk transport succeed only to fail during decode.
const MAX_DECOMPRESSED_BLOCK_COMPONENT_SIZE: usize = 512 * 1024 * 1024;

/// TX forwarding batches are latency-bounded by a 50ms flush timer, so we can
/// use a larger batch target to reduce cross-task and cross-peer overhead.
const TX_FORWARD_BATCH_TARGET: usize = 512;
// Gov5 serves block-by-hash from its local database. A healthy local validator
// responds well inside this deadline; waiting for the ten-second transport
// timeout makes a long reverse ancestry effectively serial at one block per
// timeout whenever a command is suppressed or a swarm terminal event is lost.
const H2_V4_FETCH_RETRY_TIMEOUT: Duration = Duration::from_secs(2);
const H2_V4_FETCH_RETRY_ROUND: Duration = Duration::from_secs(30);
// A body can be delivered and committed before duplicate H2 proposals/QCs
// already queued on the consensus lane are drained. Keep the same short
// fulfillment tombstone as the network service so those duplicates cannot
// re-arm an orchestrator-local retry timer for a request the network suppresses.
const H2_V4_FETCH_FULFILLED_RETENTION: Duration = Duration::from_secs(30);
const MAX_H2_V4_FETCH_FULFILLED: usize = 4096;
const DEFAULT_H2_V4_CATCHUP_BUFFER_BLOCKS: usize = 2048;
const MAX_H2_V4_CATCHUP_BUFFER_BLOCKS: usize = 131_072;

fn h2_v4_catchup_buffer_blocks() -> usize {
    std::env::var("N42_GOV5_CATCHUP_BUFFER_BLOCKS")
        .ok()
        .and_then(|value| value.parse::<usize>().ok())
        .unwrap_or(DEFAULT_H2_V4_CATCHUP_BUFFER_BLOCKS)
        .clamp(
            DEFAULT_H2_V4_CATCHUP_BUFFER_BLOCKS,
            MAX_H2_V4_CATCHUP_BUFFER_BLOCKS,
        )
}

/// Maximum number of already-queued R1/R2 votes verified in one randomized
/// BLS multi-pairing. Draining is non-blocking, so this adds no timer latency.
const CONSENSUS_VOTE_BATCH_MAX: usize = 256;

/// Minimum gossip warm-up before leader proposal attempts.
const DEFAULT_LEADER_PROPOSE_WARMUP_MS: u64 = 500;

/// Re-check interval while waiting for validator quorum.
const LEADER_QUORUM_RETRY_MS: u64 = 500;

/// Default interval for re-sending the current view's locally signed R1/R2
/// vote when the collector may have missed the first delivery.
const DEFAULT_VOTE_RESEND_MS: u64 = 2_000;

/// Minimum spacing between two publishes of a byte-identical H2 message.
const H2_REBROADCAST_MIN_INTERVAL: Duration = Duration::from_millis(750);

/// A locally signed vote awaiting evidence that the view progressed. Re-sending
/// the exact bytes is safe because collectors deduplicate by `(view, voter)`.
#[derive(Clone)]
struct PendingVoteResend {
    view: u64,
    target: u32,
    message: n42_primitives::ConsensusMessage,
    next_at: Instant,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum LeaderBuildWaitMode {
    /// The pending leader build should be executed directly once quorum is reached.
    Direct,
    /// The pending leader build should resume through `schedule_payload_build` once quorum is reached.
    Scheduled,
}

thread_local! {
    // One zstd context per thread. `zstd::bulk::compress`/`decompress` build
    // and tear down a `ZSTD_CCtx`/`ZSTD_DCtx` (window buffers included) on
    // every call; a reused context is reset per frame and produces the same
    // bytes for the same level (see `pooled_zstd_matches_one_shot`).
    static ZSTD_COMPRESSOR: std::cell::RefCell<Option<zstd::bulk::Compressor<'static>>> =
        const { std::cell::RefCell::new(None) };
    static ZSTD_DECOMPRESSOR: std::cell::RefCell<Option<zstd::bulk::Decompressor<'static>>> =
        const { std::cell::RefCell::new(None) };
}

/// zstd-compress `payload` at `level` with this thread's pooled context.
pub fn zstd_compress_pooled(payload: &[u8], level: i32) -> std::io::Result<Vec<u8>> {
    ZSTD_COMPRESSOR.with(|slot| {
        let mut slot = slot.borrow_mut();
        if slot.is_none() {
            *slot = Some(zstd::bulk::Compressor::new(level)?);
        }
        let compressor = slot.as_mut().expect("compressor was just created");
        // The level is process-wide in practice (`payload_zstd_level` is
        // cached), but keep the context honest if a caller passes another.
        compressor.set_compression_level(level)?;
        compressor.compress(payload)
    })
}

/// zstd-decompress `data` into at most `capacity` bytes with this thread's
/// pooled context.
pub fn zstd_decompress_pooled(data: &[u8], capacity: usize) -> std::io::Result<Vec<u8>> {
    ZSTD_DECOMPRESSOR.with(|slot| {
        let mut slot = slot.borrow_mut();
        if slot.is_none() {
            *slot = Some(zstd::bulk::Decompressor::new()?);
        }
        slot.as_mut()
            .expect("decompressor was just created")
            .decompress(data, capacity)
    })
}

/// Compress a block-data component with zstd. Production keeps level 3; throughput
/// qualification can choose a faster level through `N42_ZSTD_LEVEL`.
pub fn compress_payload(payload: &[u8]) -> Vec<u8> {
    let level = payload_zstd_level();
    zstd_compress_pooled(payload, level).unwrap_or_else(|e| {
        tracing::warn!(target: "n42::cl", len = payload.len(), error = %e, "zstd compression failed, sending uncompressed");
        payload.to_vec()
    })
}

/// Compress the execution-payload wire image, with an explicit benchmark switch
/// that does not also disable compression of the compact execution sidecar.
pub fn compress_execution_payload(payload: &[u8]) -> Vec<u8> {
    static ENABLED: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    let enabled = *ENABLED.get_or_init(|| {
        !matches!(
            std::env::var("N42_PAYLOAD_ZSTD").ok().as_deref(),
            Some("0") | Some("false") | Some("off")
        )
    });
    if !enabled {
        return payload.to_vec();
    }
    compress_payload(payload)
}

fn payload_zstd_level() -> i32 {
    static LEVEL: std::sync::OnceLock<i32> = std::sync::OnceLock::new();
    *LEVEL.get_or_init(|| {
        std::env::var("N42_ZSTD_LEVEL")
            .ok()
            .and_then(|value| value.parse::<i32>().ok())
            .map(|value| value.clamp(1, 9))
            .unwrap_or(3)
    })
}

/// Decompress payload if zstd-compressed; pass through an uncompressed wire image.
/// Backward-compatible with old nodes that sent uncompressed JSON.
pub fn decompress_payload(data: &[u8]) -> std::io::Result<Vec<u8>> {
    if data.len() >= 4 && data[..4] == ZSTD_MAGIC {
        zstd_decompress_pooled(data, MAX_DECOMPRESSED_BLOCK_COMPONENT_SIZE)
            .map_err(|e| std::io::Error::new(std::io::ErrorKind::InvalidData, e))
    } else {
        Ok(data.to_vec())
    }
}

/// Versioned execution-payload framing. The JSON header retains Alloy's exact
/// V1-V4/sidecar representation with an empty transaction array; transactions
/// follow as raw bytes so JSON hex encoding no longer doubles the dominant data.
const EXECUTION_PAYLOAD_BINARY_V1_MAGIC: [u8; 8] = *b"N42EPB01";
const EXECUTION_PAYLOAD_BINARY_HEADER_BYTES: usize = 16;
const MAX_EXECUTION_PAYLOAD_HEADER_BYTES: usize = 1024 * 1024;
const MAX_EXECUTION_PAYLOAD_TRANSACTIONS: usize = 2_000_000;

pub(super) struct EncodedExecutionPayload {
    pub bytes: Vec<u8>,
    pub format: &'static str,
    pub header_bytes: usize,
    pub transaction_bytes: usize,
}

fn execution_payload_binary_enabled() -> bool {
    static ENABLED: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    *ENABLED.get_or_init(|| {
        std::env::var("N42_EXECUTION_PAYLOAD_BINARY")
            .map(|value| value != "0")
            .unwrap_or(true)
    })
}

fn invalid_payload(error: impl std::fmt::Display) -> std::io::Error {
    std::io::Error::new(std::io::ErrorKind::InvalidData, error.to_string())
}

/// Encode without cloning the transaction bodies. The transaction vector is
/// removed only while the small JSON header is serialized and is restored on
/// every return path.
pub(super) fn encode_execution_payload(
    execution: &mut ExecutionData,
) -> std::io::Result<EncodedExecutionPayload> {
    if !execution_payload_binary_enabled() {
        let bytes = serde_json::to_vec(execution).map_err(invalid_payload)?;
        return Ok(EncodedExecutionPayload {
            transaction_bytes: execution
                .payload
                .transactions()
                .iter()
                .map(|transaction| transaction.len())
                .sum(),
            header_bytes: bytes.len(),
            bytes,
            format: "json",
        });
    }

    let transactions = std::mem::take(execution.payload.transactions_mut());
    let header_result = serde_json::to_vec(execution);
    *execution.payload.transactions_mut() = transactions;
    let header = header_result.map_err(invalid_payload)?;

    let header_len = u32::try_from(header.len())
        .map_err(|_| invalid_payload("execution payload header exceeds u32"))?;
    let transactions = execution.payload.transactions();
    let transaction_count = u32::try_from(transactions.len())
        .map_err(|_| invalid_payload("execution payload transaction count exceeds u32"))?;
    let transaction_bytes = transactions.iter().try_fold(0usize, |total, transaction| {
        let _ = u32::try_from(transaction.len())
            .map_err(|_| invalid_payload("execution transaction exceeds u32"))?;
        total
            .checked_add(transaction.len())
            .ok_or_else(|| invalid_payload("execution transaction bytes overflow"))
    })?;
    let capacity = EXECUTION_PAYLOAD_BINARY_HEADER_BYTES
        .checked_add(header.len())
        .and_then(|size| size.checked_add(transactions.len().saturating_mul(4)))
        .and_then(|size| size.checked_add(transaction_bytes))
        .ok_or_else(|| invalid_payload("execution payload size overflow"))?;

    let mut bytes = Vec::with_capacity(capacity);
    bytes.extend_from_slice(&EXECUTION_PAYLOAD_BINARY_V1_MAGIC);
    bytes.extend_from_slice(&header_len.to_le_bytes());
    bytes.extend_from_slice(&transaction_count.to_le_bytes());
    bytes.extend_from_slice(&header);
    for transaction in transactions {
        let transaction_len =
            u32::try_from(transaction.len()).expect("transaction length was validated above");
        bytes.extend_from_slice(&transaction_len.to_le_bytes());
        bytes.extend_from_slice(transaction);
    }

    Ok(EncodedExecutionPayload {
        bytes,
        format: "binary-v1",
        header_bytes: header.len(),
        transaction_bytes,
    })
}

pub(super) fn execution_payload_wire_format(payload: &[u8]) -> &'static str {
    if payload.starts_with(&EXECUTION_PAYLOAD_BINARY_V1_MAGIC) {
        "binary-v1"
    } else {
        "json"
    }
}

pub(super) fn decode_execution_payload(payload: &[u8]) -> std::io::Result<ExecutionData> {
    if !payload.starts_with(&EXECUTION_PAYLOAD_BINARY_V1_MAGIC) {
        return serde_json::from_slice(payload).map_err(invalid_payload);
    }
    decode_binary_execution_payload(payload, None)
}

/// Decode a received payload while retaining the decompressed allocation as the
/// backing store for every transaction body. A full block otherwise copies
/// roughly 20 MiB into 163K independent `Bytes` values on every follower.
pub(super) fn decode_execution_payload_owned(payload: Vec<u8>) -> std::io::Result<ExecutionData> {
    if !payload.starts_with(&EXECUTION_PAYLOAD_BINARY_V1_MAGIC) {
        return serde_json::from_slice(&payload).map_err(invalid_payload);
    }
    let backing = alloy_primitives::Bytes::from(payload);
    decode_binary_execution_payload(backing.as_ref(), Some(&backing))
}

fn decode_binary_execution_payload(
    payload: &[u8],
    backing: Option<&alloy_primitives::Bytes>,
) -> std::io::Result<ExecutionData> {
    if payload.len() < EXECUTION_PAYLOAD_BINARY_HEADER_BYTES {
        return Err(invalid_payload("truncated binary execution payload header"));
    }

    let header_len = u32::from_le_bytes(
        payload[8..12]
            .try_into()
            .expect("four-byte header length slice"),
    ) as usize;
    let transaction_count = u32::from_le_bytes(
        payload[12..16]
            .try_into()
            .expect("four-byte transaction count slice"),
    ) as usize;
    if header_len > MAX_EXECUTION_PAYLOAD_HEADER_BYTES {
        return Err(invalid_payload(
            "binary execution payload header is too large",
        ));
    }
    if transaction_count > MAX_EXECUTION_PAYLOAD_TRANSACTIONS {
        return Err(invalid_payload(
            "binary execution payload transaction count is too large",
        ));
    }
    let header_end = EXECUTION_PAYLOAD_BINARY_HEADER_BYTES
        .checked_add(header_len)
        .filter(|end| *end <= payload.len())
        .ok_or_else(|| invalid_payload("truncated binary execution payload JSON header"))?;
    let mut execution: ExecutionData =
        serde_json::from_slice(&payload[EXECUTION_PAYLOAD_BINARY_HEADER_BYTES..header_end])
            .map_err(invalid_payload)?;
    if !execution.payload.transactions().is_empty() {
        return Err(invalid_payload(
            "binary execution payload JSON header contains transactions",
        ));
    }

    let minimum_transaction_bytes = transaction_count
        .checked_mul(4)
        .and_then(|lengths| header_end.checked_add(lengths))
        .filter(|minimum| *minimum <= payload.len())
        .ok_or_else(|| invalid_payload("truncated binary execution transaction lengths"))?;
    let _ = minimum_transaction_bytes;
    let mut cursor = header_end;
    let mut transactions = Vec::with_capacity(transaction_count);
    let mut shared_transaction_bytes = 0u64;
    for _ in 0..transaction_count {
        let length_end = cursor
            .checked_add(4)
            .filter(|end| *end <= payload.len())
            .ok_or_else(|| invalid_payload("truncated binary execution transaction length"))?;
        let transaction_len = u32::from_le_bytes(
            payload[cursor..length_end]
                .try_into()
                .expect("four-byte transaction length slice"),
        ) as usize;
        cursor = length_end;
        let transaction_end = cursor
            .checked_add(transaction_len)
            .filter(|end| *end <= payload.len())
            .ok_or_else(|| invalid_payload("truncated binary execution transaction"))?;
        transactions.push(match backing {
            Some(backing) => {
                shared_transaction_bytes =
                    shared_transaction_bytes.saturating_add(transaction_len as u64);
                backing.slice(cursor..transaction_end)
            }
            None => alloy_primitives::Bytes::copy_from_slice(&payload[cursor..transaction_end]),
        });
        cursor = transaction_end;
    }
    if cursor != payload.len() {
        return Err(invalid_payload("trailing binary execution payload bytes"));
    }
    *execution.payload.transactions_mut() = transactions;
    if shared_transaction_bytes > 0 {
        metrics::counter!("n42_execution_payload_decode_copy_avoided_bytes_total")
            .increment(shared_transaction_bytes);
    }
    Ok(execution)
}

/// The staking sink still consumes the historical JSON representation. This
/// conversion is only reached for blocks whose validated metadata did not
/// already prove that the staking address is absent.
pub(super) fn execution_payload_json_for_staking(payload: &[u8]) -> std::io::Result<Vec<u8>> {
    if payload.starts_with(&EXECUTION_PAYLOAD_BINARY_V1_MAGIC) {
        serde_json::to_vec(&decode_execution_payload(payload)?).map_err(invalid_payload)
    } else {
        Ok(payload.to_vec())
    }
}

/// Exact RLP call-target marker for the native staking address inside a raw
/// Ethereum transaction envelope.
const STAKING_TARGET_RLP: [u8; 21] = [
    0x94, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x42,
];

/// Cheap typed prefilter run before the payload is moved into reth.
pub(super) fn execution_might_contain_staking_target(execution: &ExecutionData) -> bool {
    execution.payload.transactions().iter().any(|transaction| {
        transaction
            .windows(STAKING_TARGET_RLP.len())
            .any(|window| window == STAKING_TARGET_RLP)
    })
}

fn elapsed_since_unix_ms(start_ms: u64) -> Option<u64> {
    if start_ms == 0 {
        return None;
    }
    let now_ms = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .ok()?
        .as_millis() as u64;
    Some(now_ms.saturating_sub(start_ms))
}

/// Block data broadcast via /n42/blocks/1 GossipSub topic.
///
/// NOTE: Serialized with bincode. Adding new fields requires all nodes to upgrade
/// simultaneously — bincode does not support missing trailing fields on deserialization.
/// New→old is fine (bincode ignores trailing bytes), but old→new will fail.
#[derive(Clone, serde::Serialize, serde::Deserialize)]
pub struct BlockDataBroadcast {
    pub block_hash: B256,
    pub view: u64,
    /// Execution payload — zstd-compressed binary-v1 or legacy JSON.
    /// Use `decompress_payload()` and `decode_execution_payload()`.
    pub payload_json: Vec<u8>,
    /// Block timestamp (seconds since epoch). Stored directly to avoid JSON re-parsing.
    /// Defaults to 0 for backwards compatibility with older serialized broadcasts.
    #[serde(default)]
    pub timestamp: u64,
    /// Compact Block: zstd-compressed bincode of `CompactBlockExecution`.
    /// When present, followers load this into `payload_cache` to skip EVM re-execution.
    /// None for backwards compatibility with older peers.
    #[serde(default)]
    pub execution_output: Option<Vec<u8>>,
    /// Leader wall-clock timestamp in unix milliseconds when payload became ready
    /// for broadcast. Used only for cross-task timing diagnostics.
    #[serde(default)]
    pub leader_ready_unix_ms: u64,
}

/// Consensus context captured when a leader starts an asynchronous payload build.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) struct PayloadBuildContext {
    view: u64,
    parent_hash: B256,
}

/// A resolved payload together with the context it was built under.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) struct PayloadBuildReady {
    context: PayloadBuildContext,
    block_hash: B256,
}

/// Serializable proxy for `(BlockExecutionOutput<Receipt>, Vec<Address>)`.
/// `BlockExecutionResult` from alloy-evm doesn't derive serde, so we flatten it.
#[derive(serde::Serialize, serde::Deserialize)]
pub struct CompactBlockExecution {
    pub bundle_state: revm::database::states::BundleState,
    pub receipts: Vec<reth_ethereum_primitives::Receipt>,
    pub requests: alloy_eips::eip7685::Requests,
    pub gas_used: u64,
    pub blob_gas_used: u64,
    pub senders: Vec<Address>,
    /// Transaction trie root authenticated by the leader's block hash.  This
    /// lets followers avoid rebuilding the same 163K-transaction trie before
    /// decoding the body.  Older compact messages omit it and retain the
    /// standard full-root computation.
    #[serde(default)]
    pub transactions_root: Option<B256>,
}

/// Blob sidecar broadcast via /n42/blobs/1 GossipSub topic.
#[derive(serde::Serialize, serde::Deserialize)]
pub struct BlobSidecarBroadcast {
    pub block_hash: B256,
    pub view: u64,
    pub sidecars: Vec<(B256, Vec<u8>)>,
}

/// Per-block pipeline timing tracker.
///
/// The consensus slot interval acts as a "bus clock": within each tick,
/// build / import / consensus / communication stages run in parallel.
/// This struct records wall-clock timestamps for each stage so we can
/// quantify overlap and identify serialization bottlenecks.
///
/// ```text
/// Slot N clock tick ──────────────────────────────────────── slot_time
/// ├── [Build]           tx_pack + evm_exec + state_root
/// ├── [Broadcast]       block data + blob sidecars
/// ├── [Consensus]       voting rounds (overlaps with import)
/// ├── [Import]          new_payload + fcu (overlaps with consensus)
/// └── [Commit]          finalize
/// ```
#[derive(Debug, Clone)]
pub(crate) struct PipelineTiming {
    /// When we first learned about this block (build trigger or block_data received).
    pub(crate) created: Instant,
    /// Role of this node for the block.
    pub(crate) is_leader: bool,
    /// Leader: payload resolved & broadcast. Follower: block data received.
    pub(crate) build_complete: Option<Instant>,
    /// Eager import (new_payload + fcu) completed.
    pub(crate) import_complete: Option<Instant>,
    /// Consensus committed (Decide received or CommitQC formed).
    pub(crate) committed: Option<Instant>,
}

#[derive(Debug, Default)]
struct TimeoutViewDiag {
    build_start: Option<Instant>,
    build_pool_pending: usize,
    build_pool_queued: usize,
    block_data_received_count: u32,
    first_block_data_received: Option<Instant>,
    timeout_at: Option<Instant>,
    timeout_pool_pending: usize,
    timeout_pool_queued: usize,
}

impl PipelineTiming {
    fn new_follower() -> Self {
        Self {
            created: Instant::now(),
            is_leader: false,
            build_complete: None,
            import_complete: None,
            committed: None,
        }
    }

    /// Produces a one-line summary of pipeline stage durations (ms).
    fn summary(&self) -> String {
        let role = if self.is_leader { "L" } else { "F" };
        let build_ms = self
            .build_complete
            .map(|t| t.duration_since(self.created).as_millis() as u64);
        let import_ms = self
            .import_complete
            .map(|t| t.duration_since(self.created).as_millis() as u64);
        let commit_ms = self
            .committed
            .map(|t| t.duration_since(self.created).as_millis() as u64);
        // Overlap: how much of import happened during consensus (before commit)
        let import_before_commit = match (self.import_complete, self.committed) {
            (Some(imp), Some(com)) if imp <= com => {
                Some(com.duration_since(imp).as_millis() as u64)
            }
            _ => None,
        };
        format!(
            "role={role} build={build}ms import={import}ms commit={commit}ms import_headroom={headroom}ms",
            build = build_ms
                .map(|v| v.to_string())
                .unwrap_or_else(|| "-".into()),
            import = import_ms
                .map(|v| v.to_string())
                .unwrap_or_else(|| "-".into()),
            commit = commit_ms
                .map(|v| v.to_string())
                .unwrap_or_else(|| "-".into()),
            headroom = import_before_commit
                .map(|v| v.to_string())
                .unwrap_or_else(|| "-".into()),
        )
    }

    /// Emit per-stage metrics histograms.
    fn emit_metrics(&self) {
        if let Some(t) = self.build_complete {
            histogram!("n42_pipeline_build_ms")
                .record(t.duration_since(self.created).as_millis() as f64);
        }
        if let Some(t) = self.import_complete {
            histogram!("n42_pipeline_import_ms")
                .record(t.duration_since(self.created).as_millis() as f64);
        }
        if let Some(t) = self.committed {
            let total = t.duration_since(self.created).as_millis() as f64;
            histogram!("n42_pipeline_total_ms").record(total);
        }
        // Overlap ratio: what fraction of total time was "useful work" vs waiting
        if let (Some(build), Some(import), Some(commit)) =
            (self.build_complete, self.import_complete, self.committed)
        {
            let build_dur = build.duration_since(self.created).as_millis() as f64;
            let import_dur = import.duration_since(self.created).as_millis() as f64;
            let total = commit.duration_since(self.created).as_millis() as f64;
            if total > 0.0 {
                // Parallelism ratio: (build + import) / total.  >1.0 means good overlap.
                let parallelism = (build_dur + import_dur) / total;
                gauge!("n42_pipeline_parallelism").set(parallelism);
            }
        }
    }
}

/// Deferred finalization: Decide arrived before BlockData (f=0 race).
struct PendingFinalization {
    view: u64,
    block_hash: B256,
    #[allow(dead_code)]
    commit_qc: QuorumCertificate,
}

/// Consensus agreement and execution finality are deliberately separate.
/// A CommitQC records `Committed`; a successful speculative `new_payload`
/// promotes the exact hash to `ExecutionReady`; only a successful canonical
/// FCU records `Finalized`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum AsyncCommitStage {
    Committed,
    ExecutionReady,
    Finalized,
}

struct AsyncCommitState {
    view: u64,
    block_hash: B256,
    commit_qc: QuorumCertificate,
    stage: AsyncCommitStage,
    finalize_in_flight: bool,
    committed_at: Instant,
}

type FinalizeDone = (u64, B256, QuorumCertificate, bool);
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ImportOutcome {
    Valid,
    Syncing,
    Invalid,
}
type ImportDone = (B256, u64, ImportOutcome, u64);
type SidecarDiffWork = (u64, B256, n42_execution::state_diff::StateDiff);
type SharedBlockData = Arc<Vec<u8>>;
type StateDiffReady = (B256, n42_execution::state_diff::StateDiff);
type CommitExecutionTimeout = (u64, B256);
type EagerImportDone = (
    B256,
    u64,
    B256,
    u64,
    bool,
    Option<n42_execution::state_diff::StateDiff>,
);

pub struct CommittedBlock {
    pub view: u64,
    pub block_hash: B256,
    pub commit_qc: QuorumCertificate,
    pub payload: Vec<u8>,
    /// Compressed payload length without materializing another owned copy.
    pub(crate) payload_len: usize,
    /// Exact live BlockData envelope, shared with the pending/recent caches.
    /// Sync/recovery paths materialize `payload` only when they actually serve it.
    pub(crate) block_data: Option<SharedBlockData>,
    pub validator_changes: Option<Vec<n42_primitives::consensus::ValidatorChange>>,
    /// Full execution lineage from the previously execution-validated head to
    /// this committed block. It may include a prepared ancestor that never
    /// obtained its own CommitQC before a timeout/restart.
    pub execution_lineage: Vec<SyncPayload>,
}

impl CommittedBlock {
    fn retained_payload(&self) -> Vec<u8> {
        if !self.payload.is_empty() {
            return self.payload.clone();
        }
        self.block_data
            .as_ref()
            .and_then(|data| bincode::deserialize::<BlockDataBroadcast>(data.as_slice()).ok())
            .map(|broadcast| broadcast.payload_json)
            .unwrap_or_default()
    }
}

#[derive(Clone)]
struct RecentBlockData {
    view: u64,
    block_hash: B256,
    block_data: SharedBlockData,
    payload_len: usize,
    /// Populated only after reth accepts the exact payload as valid. The raw
    /// broadcast envelope itself is unauthenticated, so lineage code must not
    /// trust metadata merely claimed by its sender.
    execution_parent_hash: Option<B256>,
    execution_block_number: Option<u64>,
    execution_has_staking_target: Option<bool>,
    /// State-tree delta derived from the locally received compact execution
    /// output. It is attached only after reth validates the matching payload,
    /// so commit-time sidecars can reuse it without trusting peer bytes.
    execution_state_diff: Option<n42_execution::state_diff::StateDiff>,
}

/// Bridges the consensus engine with the P2P network layer and reth Engine API.
///
/// Runs as a background task via `tokio::select!` over network events, engine outputs,
/// pacemaker timeouts, and BlockReady signals.
pub struct ConsensusService {
    engine: ConsensusEngine,
    /// Enables bidirectional H2-v4 consensus conversion. `None` preserves the
    /// native network and observer behavior exactly.
    h2_v4_identity: Option<n42_network::h2_v4::H2V4ChainIdentity>,
    /// H2-authenticated block hash -> consensus view. Gov5 block gossip is not
    /// executed until one of these bindings exists.
    h2_v4_block_views: BTreeMap<B256, u64>,
    /// Insertion order for the bounded binding map above. `BTreeMap::pop_first`
    /// is hash order, not age order: once the map reached capacity, a live
    /// low-valued block hash could otherwise evict itself immediately and
    /// strand its already-received body in the unbound cache forever.
    h2_v4_block_view_order: VecDeque<B256>,
    /// Header-derived execution height for authenticated/interoperable blocks.
    /// This lets asynchronous `Valid` completions advance the exact height
    /// floor without confusing a newer consensus count for executed state.
    h2_v4_block_numbers: BTreeMap<B256, u64>,
    /// Structurally valid gov5 bodies that arrived before their H2 binding.
    h2_v4_unbound_blocks: BTreeMap<B256, (PeerId, Vec<u8>)>,
    /// Authenticated ancestry collected newest-to-oldest during far catch-up.
    /// It is released to Engine API only in ascending block order.
    h2_v4_catchup_blocks: BTreeMap<u64, (PeerId, Vec<u8>, u64)>,
    /// Explicitly bounded block count for authenticated reverse-ancestry
    /// catch-up. Production keeps the conservative default; qualification can
    /// opt into a larger, hard-capped window for a known retained chain.
    h2_v4_catchup_buffer_blocks: usize,
    /// Avoids rescanning the bounded hash-indexed execution metadata while a
    /// reverse catch-up holds the same durable head for many thousands of
    /// incoming ancestors.
    h2_v4_last_pruned_head_block_number: Option<u64>,
    h2_v4_catchup_active: bool,
    /// Peers that failed to serve an authenticated block hash during the
    /// current bounded retry round. A mixed Rust/Gov set may gossip a child
    /// from a Rust validator whose execution head is also behind; retrying
    /// that same peer forever prevents either Rust node from reaching a Gov
    /// peer that already has the missing parent.
    h2_v4_fetch_failed_peers: BTreeMap<B256, (Instant, HashSet<PeerId>)>,
    /// Accepted Gov5 block-by-hash commands awaiting a body. The network layer
    /// has its own bounded request table, but capacity/cooldown suppression is
    /// intentionally non-blocking; this orchestrator-owned deadline guarantees
    /// that a consensus-authenticated body is retried even if no failure event
    /// can be emitted for a command that was suppressed before transmission.
    h2_v4_fetch_requested_at: HashMap<B256, (Instant, PeerId)>,
    /// Round-robin cursor over connected peers for the gov5 execution pull
    /// (see `state_mgmt::initiate_gov5_execution_pull`).
    gov5_execution_pull_rounds: u64,
    /// When the last gov5 execution pull was issued; throttles the per-view
    /// re-arm to one pull per fetch deadline.
    gov5_execution_pull_last_at: Option<Instant>,
    /// Recently delivered block hashes. This mirrors the network-layer
    /// fulfillment tombstones because request commands are fire-and-forget:
    /// a network-side suppression cannot otherwise stop this orchestrator from
    /// recording a nonexistent request and retrying it two seconds later.
    h2_v4_fetch_fulfilled_at: HashMap<B256, Instant>,
    /// Network port (Caplin sentinel-client seam). One in-process adapter today
    /// (`NetworkHandle`); the trait object lets the orchestrator move into a
    /// service crate without depending on `n42-network` / libp2p internals.
    network: Arc<dyn ConsensusNetwork>,
    /// High-priority: consensus messages only (Vote, Proposal, PrepareQC, etc.)
    consensus_event_rx: Option<mpsc::Receiver<NetworkEvent>>,
    /// Lower-priority: data events (BlockData, TX, Sync, Peers)
    net_event_rx: mpsc::Receiver<NetworkEvent>,
    output_rx: mpsc::Receiver<EngineOutput>,
    /// The execution-layer seam (Caplin-style `ExecutionEngine`). `None` for
    /// tests / EL-less observer paths. One in-process adapter
    /// (`RethExecutionLayer`) wraps the reth engine + payload-builder handles.
    el: Option<Arc<dyn ExecutionLayer>>,
    consensus_state: Option<Arc<SharedConsensusState>>,
    /// Most recent locally execution-validated committed head. This is deliberately
    /// distinct from `committed_block_count`: HotStuff agreement may advance before
    /// reth has accepted the corresponding payload.
    head_block_hash: B256,
    /// Canonical execution height paired with `head_block_hash`. Historical
    /// H2 bodies released from the unbound cache at or below this floor are
    /// already executed and must not consume the bounded catch-up suffix.
    head_block_number: u64,
    /// Highest committed/sync view whose block reth confirmed as `Valid`.
    /// Guards async finalize/import completions from regressing the executed head.
    execution_validated_head_view: u64,
    /// Bounded record of speculative eager imports that reth already accepted.
    /// A matching commit may promote the block without waiting for a second EL result.
    eager_execution_validated: VecDeque<B256>,
    /// State-tree sidecar diffs staged at commit time, applied only once
    /// execution is CONFIRMED (advance_execution_validated_head) - never on a
    /// block reth could still reject.
    pending_sidecar_diffs: BTreeMap<u64, (B256, n42_execution::state_diff::StateDiff)>,
    /// Exact block hash reth confirmed for each staged sidecar view. A diff is
    /// never flushed merely because a later view advanced; its staged hash
    /// must match this execution-valid canonical binding first.
    execution_validated_sidecar_hashes: BTreeMap<u64, B256>,
    /// Committed views whose compact execution output was unavailable or
    /// malformed when the block committed. A gap is an ordering barrier:
    /// later diffs remain staged until late BlockData recovers the missing one.
    missing_sidecar_diffs: BTreeMap<u64, B256>,
    /// Confirmed sidecar diffs waiting for the single FIFO background worker.
    /// A shared queue is required because separate spawn_blocking calls can
    /// acquire the StateSink lock out of commit order.
    sidecar_apply_queue: Arc<std::sync::Mutex<VecDeque<SidecarDiffWork>>>,
    sidecar_apply_worker_running: Arc<std::sync::atomic::AtomicBool>,
    /// Highest view accepted by the sidecar worker, retained across worker
    /// lifetimes so a later queue cannot replay or regress an already-applied
    /// append-ordered diff.
    last_sidecar_applied_view: Arc<std::sync::atomic::AtomicU64>,
    last_commit_qc: Option<QuorumCertificate>,
    /// Cached `keccak256(commit_qc.aggregate_signature)` — avoids re-hashing on every payload build.
    prev_randao_cache: B256,
    block_ready_tx: mpsc::Sender<PayloadBuildReady>,
    block_ready_rx: mpsc::Receiver<PayloadBuildReady>,
    fee_recipient: Address,
    slot_time: Duration,
    next_build_at: Option<Instant>,
    next_slot_timestamp: Option<u64>,
    consecutive_empty_skips: u32,
    pending_block_data: BTreeMap<B256, SharedBlockData>,
    /// Raw proposal payloads retained across ordinary pending-cache clears so
    /// CommitQC descendants can prove and serve any prepared execution
    /// ancestors needed by a restarting reth tree.
    recent_block_data: VecDeque<RecentBlockData>,
    pending_executions: HashSet<B256>,
    pending_finalization: Option<PendingFinalization>,
    /// Ordered commit lifecycle. A later execution-ready child never overtakes
    /// an earlier committed parent when canonical FCUs are dispatched.
    async_commit_states: BTreeMap<u64, AsyncCommitState>,
    /// Blocks that returned `Syncing` from new_payload, queued for retry.
    /// Each entry is `(serialized_data, retry_count)` — dropped after 3 retries.
    syncing_blocks: VecDeque<(Vec<u8>, u32)>,
    /// Deterministic `new_payload(INVALID)` verdicts, bounded by an LRU policy.
    bad_blocks: bad_block_cache::BadBlockCache,
    tx_import_tx: Option<mpsc::Sender<TxImportBatch>>,
    tx_broadcast_rx: Option<mpsc::Receiver<Vec<u8>>>,
    committed_blocks: VecDeque<CommittedBlock>,
    connected_peers: HashSet<PeerId>,
    /// Pending leader-proposal quorum gate for a specific view.
    ///
    /// `LeaderBuildWaitMode::Direct` means the gate will call
    /// `do_trigger_payload_build` directly once quorum is reached.
    /// `LeaderBuildWaitMode::Scheduled` means the gate re-enters
    /// `schedule_payload_build` once quorum is reached.
    leader_build_waiting_view: Option<(u64, LeaderBuildWaitMode)>,
    /// Earliest instant at which the startup leader may propose for the
    /// associated view. Peer-connect events can satisfy the quorum gate before
    /// the configured warmup floor, so the floor must be tracked separately
    /// from the recheck timer.
    leader_build_not_before: Option<(u64, Instant)>,
    sync_in_flight: bool,
    sync_started_at: Option<Instant>,
    /// `[from_view, to_view]` of the most recent in-flight sync / catch-up
    /// request. Sync responses are validated against this range so a peer
    /// cannot inject blocks we never asked for (T2a). Cleared together with
    /// `sync_requested_peers` when that request group completes.
    sync_request_range: Option<(u64, u64)>,
    /// Peers to which the active sync range was actually sent. Responses from
    /// any other peer are unsolicited and must not clear or mutate active sync
    /// state. Catch-up fan-out keeps every successful recipient here until one
    /// returns useful data or all recipients finish.
    sync_requested_peers: HashSet<PeerId>,
    state_file: Option<PathBuf>,
    validator_set_for_sync: Option<ValidatorSet>,
    /// View at which a validator_changes block was applied during sync.
    /// Guards the epoch-advance check in the sync loop: we only fire advance_epoch
    /// at a boundary if the staging came from a block we actually replayed in sync
    /// (not from pre-existing live-consensus state), preventing premature advances.
    epoch_sync_staged_view: Option<u64>,
    mobile_packet_tx: Option<mpsc::Sender<(B256, u64)>>,
    leader_payload_rx: mpsc::Receiver<(B256, SharedBlockData)>,
    leader_payload_tx: mpsc::Sender<(B256, SharedBlockData)>,
    /// Receives notifications when a background `import_and_notify` task completes.
    /// Tuple: (block_hash, view, execution outcome, block timestamp).
    import_done_rx: mpsc::Receiver<ImportDone>,
    import_done_tx: mpsc::Sender<ImportDone>,
    /// Receives finalize-FCU completion from the optional async finalize path.
    /// Tuple: (view, block_hash, commit_qc, finalized).
    finalize_done_rx: mpsc::Receiver<FinalizeDone>,
    finalize_done_tx: mpsc::Sender<FinalizeDone>,
    blob_store: Option<Arc<dyn BlobStorePort>>,
    /// Compact-block execution-output cache behind the [`ExecutionOutputCache`]
    /// port. `None` ⇒ compact-block inject/take are no-ops (tests / EL-less).
    exec_output_cache: Option<Arc<dyn ExecutionOutputCache>>,
    /// True while a background import task is running.
    bg_import_in_flight: bool,
    /// Hashes already queued or in-flight for background import.
    /// Prevents duplicate Case B work for the same block.
    bg_import_hashes: HashSet<B256>,
    /// Queue of pending imports waiting for the current bg import to finish.
    /// Entries: (serialized_block_data, block_hash, view).
    bg_import_queue: VecDeque<(SharedBlockData, B256, u64)>,
    /// Speculative build: eager import tasks notify when a block is imported to reth.
    /// Allows the next leader to start building before consensus commits the current block.
    eager_import_done_tx: mpsc::Sender<EagerImportDone>,
    eager_import_done_rx: mpsc::Receiver<EagerImportDone>,
    /// Wakes a committed lifecycle that did not receive `new_payload(Valid)`
    /// within the bounded grace period. The timer runs outside the consensus
    /// loop; its handler starts the retained-data import/catch-up fallback.
    commit_execution_timeout_tx: mpsc::Sender<CommitExecutionTimeout>,
    commit_execution_timeout_rx: mpsc::Receiver<CommitExecutionTimeout>,
    /// State-tree delta completion is deliberately separate from eager import.
    /// `new_payload(Valid)` unblocks finalization and the next leader; deriving
    /// an auxiliary QMDB/Twig sidecar must never extend that critical cadence.
    state_diff_ready_tx: mpsc::Sender<StateDiffReady>,
    state_diff_ready_rx: mpsc::Receiver<StateDiffReady>,
    /// Hash of the block whose speculative build is in progress.
    /// Set when build is triggered by eager import (before consensus commit).
    /// Cleared on ViewChanged or when finalize confirms the block.
    speculative_build_hash: Option<B256>,
    /// View and parent hash for which a payload build task is currently running.
    /// Prevents duplicate builds based on the same parent, which produce different
    /// blocks at the same height and overwhelm reth with conflicting `new_payload` calls
    /// — triggering pipeline sync and chain stalls.
    building_on_parent: Option<PayloadBuildContext>,
    /// When the current payload build was triggered. Used to measure actual build duration
    /// in PipelineTiming (created → build_complete). Reset when build finishes or is cancelled.
    build_triggered_at: Option<Instant>,
    /// Notifies the orchestrator when a payload resolve task finishes (success or failure).
    /// Used to clear `building_on_parent` so new builds are not permanently blocked
    /// when a resolve task takes longer than the pacemaker timeout.
    build_complete_tx: mpsc::Sender<PayloadBuildContext>,
    build_complete_rx: mpsc::Receiver<PayloadBuildContext>,
    /// Staking scan/persist behind the [`StakingSink`] port.
    staking_sink: Option<Arc<dyn StakingSink>>,
    /// Validated staking classifications waiting for execution-block order.
    /// Commit can overtake eager validation, so unknown blocks are filled in
    /// later without ever skipping the durable staking watermark forward.
    pending_staking_scans: BTreeMap<u64, (B256, bool)>,
    /// Reward + matured-stake withdrawal computation behind the
    /// [`WithdrawalSource`] port (build-path query).
    withdrawal_source: Option<Arc<dyn WithdrawalSource>>,
    committed_block_count: u64,
    /// Tracks the timestamp of the last built/committed block to prevent
    /// "invalid timestamp" errors from the Engine API.  The Engine API requires
    /// `new_payload_attributes.timestamp > head_block.timestamp` (strictly greater).
    /// Without this guard, fast block production (slot_time=0 or f=0 single-node)
    /// can produce two blocks within the same wall-clock second, violating the rule.
    last_committed_timestamp: u64,
    /// Timestamp when the current view started (recorded on ViewChanged).
    /// Used to measure commit latency: time from view start to BlockCommitted.
    view_started_at: Option<tokio::time::Instant>,
    /// Epoch schedule loaded from `epoch_schedule.json`.
    /// Used to pre-stage the next epoch's validator set at each epoch transition.
    epoch_schedule: Option<EpochSchedule>,
    /// Buffer for batching tx forwards to the current leader.
    tx_forward_buffer: Vec<Vec<u8>>,
    /// View in which a missing remote tx-forward leader was already reported.
    /// A deliberately absent validator can hold a view for the full pacemaker
    /// timeout, so the 50 ms flush tick must not emit the same warning repeatedly.
    tx_forward_missing_leader_warned_view: Option<u64>,
    /// Last R1/R2 vote sent in the current view. If direct delivery was lost and
    /// the view has not advanced, retry it periodically to the collector.
    pending_vote_resend: Option<PendingVoteResend>,
    /// Last H2 publish time per distinct encoded message. An identical
    /// message is published at most once per `H2_REBROADCAST_MIN_INTERVAL`:
    /// on the H2 transport every broadcast is a gossip publish plus one direct
    /// stream to every validator, so any echo between this node and its peers
    /// (a relayed timeout answered with a timeout, a duplicate that a peer
    /// re-forwards) amplifies into hundreds of streams per second, exhausts
    /// request-response capacity on both ends and starves block delivery
    /// (observed on chain 94: 3,151 dropped inbound streams in 40 s, then no
    /// block bodies for 20 minutes). Intentional resends run at 2 s and 12 s.
    recent_h2_broadcasts: std::sync::Mutex<HashMap<[u8; 32], Instant>>,
    /// gov5's simulated committee pool when the chain's genesis enables one.
    /// A leader then stamps `parentBeaconRoot = Blake3(parent evidence)` into
    /// the payload it builds, as gov5's `Prepare` does; without the parent's
    /// native header the build is refused rather than stamped wrongly.
    committee_pool: Option<Arc<n42_consensus::SimulatedCommitteePool>>,
    /// The member cannot seal a gov5 block (no local QMDB root); never start a
    /// payload build, let the view time out like an absent validator.
    leader_disabled: bool,
    /// Per-block pipeline timing tracker. Populated incrementally as events flow
    /// through the orchestrator. Logged and emitted as metrics at commit time.
    /// Bounded to 32 entries; older entries are evicted.
    pipeline_timings: HashMap<B256, PipelineTiming>,
    /// Last local consensus commit wall-clock. Used for inter-block cadence metrics.
    last_commit_instant: Option<Instant>,
    last_commit_view: Option<u64>,
    last_commit_hash: Option<B256>,
    /// Observation-only high-TPS timeout diagnostics keyed by consensus view.
    timeout_view_diags: BTreeMap<u64, TimeoutViewDiag>,
    /// Last committed parent for which commit->build_start has already been recorded.
    commit_to_build_recorded_parent: Option<B256>,
    /// Highest block number for which eager import received a deterministic
    /// `new_payload(Valid)` verdict. Non-Valid attempts never advance it, so an
    /// out-of-order child cannot suppress the missing parents needed for catch-up.
    eager_import_block_guard: Arc<std::sync::atomic::AtomicU64>,
    /// Fast propose mode: skip slot boundary alignment, build immediately after
    /// ViewChanged/BlockCommitted. Consensus voting naturally paces block production.
    /// Enabled by `N42_FAST_PROPOSE=1`. Default: false (grid-aligned slots).
    fast_propose: bool,
    /// Moves finalize forkchoiceUpdated off the consensus select-loop hot path.
    /// Enabled by default; `N42_ASYNC_FINALIZE_FCU=0` is the controlled fallback.
    async_finalize_fcu: bool,
    /// Deferred state-root mode (env `N42_DEFER_STATE_ROOT`, read once by the node
    /// at construction). When set, finalized blocks log a deferred-state-root note.
    /// Cached as a `bool` so the orchestrator no longer calls the reth EVM helper.
    defer_state_root: bool,
    /// Sparse Binary Merkle Tree for parallel state commitment, behind the
    /// [`StateSink`] port. Updated asynchronously after each committed block.
    jmt: Option<Arc<dyn StateSink>>,
    /// Twig state tree for append-only state commitments, behind the
    /// [`StateSink`] port. Updated asynchronously after each committed block.
    twig: Option<Arc<dyn StateSink>>,
    /// ZK proof scheduler behind the [`ZkSink`] port: generates ZK proofs
    /// asynchronously as a sidecar. Enabled by `N42_ZK_PROOF=1`.
    zk_scheduler: Option<Arc<dyn ZkSink>>,
    /// Whether deterministic validator PeerIds may be derived when no explicit
    /// `p2p_peer_id` bindings are configured.
    allow_deterministic_validator_peers: bool,
    /// Admin command receiver for RPC-originated validator reconfig requests.
    admin_rx: Option<mpsc::Receiver<crate::consensus_state::AdminCommand>>,
    /// MDBX-backed store for per-block consensus evidence (QC + mobile attestation).
    /// Shares the JMT MDBX environment. Written after each committed block.
    evidence_store: Option<Arc<n42_jmt::EvidenceStore>>,
    /// Per-peer rate limiter for messages that would otherwise force the engine
    /// into the BLS-heavy QC view-jump path. See `view_jump_throttle.rs`.
    view_jump_throttle: view_jump_throttle::ViewJumpThrottle,
}

impl ConsensusService {
    fn h2_v4_fetch_fulfilled_recently(&mut self, block_hash: B256, now: Instant) -> bool {
        if self
            .h2_v4_fetch_fulfilled_at
            .get(&block_hash)
            .is_some_and(|fulfilled_at| {
                now.saturating_duration_since(*fulfilled_at) < H2_V4_FETCH_FULFILLED_RETENTION
            })
        {
            return true;
        }
        self.h2_v4_fetch_fulfilled_at.remove(&block_hash);
        false
    }

    fn remember_h2_v4_fetch_fulfilled(&mut self, block_hash: B256, now: Instant) {
        if self.h2_v4_fetch_fulfilled_at.len() >= MAX_H2_V4_FETCH_FULFILLED {
            self.h2_v4_fetch_fulfilled_at.retain(|_, fulfilled_at| {
                now.saturating_duration_since(*fulfilled_at) < H2_V4_FETCH_FULFILLED_RETENTION
            });
        }
        if self.h2_v4_fetch_fulfilled_at.len() >= MAX_H2_V4_FETCH_FULFILLED
            && let Some(oldest) = self
                .h2_v4_fetch_fulfilled_at
                .iter()
                .min_by_key(|(_, fulfilled_at)| *fulfilled_at)
                .map(|(hash, _)| *hash)
        {
            self.h2_v4_fetch_fulfilled_at.remove(&oldest);
        }
        self.h2_v4_fetch_fulfilled_at.insert(block_hash, now);
    }

    fn request_h2_v4_gov5_block(&mut self, peer: PeerId, block_hash: B256) {
        let now = Instant::now();
        if block_hash == B256::ZERO || self.h2_v4_fetch_fulfilled_recently(block_hash, now) {
            return;
        }
        if block_hash == self.head_block_hash
            || self.pending_block_data.contains_key(&block_hash)
            || self.h2_v4_unbound_blocks.contains_key(&block_hash)
            || self
                .h2_v4_block_numbers
                .get(&block_hash)
                .is_some_and(|height| self.h2_v4_catchup_blocks.contains_key(height))
            || self.h2_v4_fetch_requested_at.contains_key(&block_hash)
        {
            return;
        }
        match self.network.request_gov5_block_by_hash(peer, block_hash) {
            Ok(()) => {
                self.h2_v4_fetch_requested_at
                    .insert(block_hash, (Instant::now(), peer));
                while self.h2_v4_fetch_requested_at.len() > 2048 {
                    let Some(oldest) = self
                        .h2_v4_fetch_requested_at
                        .iter()
                        .min_by_key(|(_, (requested_at, _))| *requested_at)
                        .map(|(hash, _)| *hash)
                    else {
                        break;
                    };
                    self.h2_v4_fetch_requested_at.remove(&oldest);
                }
                debug!(target: "n42::interop::h2v4", %peer, %block_hash, "tracking authenticated Gov5 block fetch");
            }
            Err(error) => {
                warn!(target: "n42::interop::h2v4", %peer, %block_hash, %error, "could not queue authenticated Gov5 block fetch");
            }
        }
    }

    fn retry_expired_h2_v4_fetches(&mut self) {
        let now = Instant::now();
        let expired = self
            .h2_v4_fetch_requested_at
            .iter()
            .filter_map(|(hash, (requested_at, peer))| {
                (now.duration_since(*requested_at) >= H2_V4_FETCH_RETRY_TIMEOUT)
                    .then_some((*hash, *peer))
            })
            .collect::<Vec<_>>();
        for (block_hash, previous_peer) in expired {
            self.h2_v4_fetch_requested_at.remove(&block_hash);
            if self.h2_v4_fetch_fulfilled_recently(block_hash, now)
                || block_hash == self.head_block_hash
                || self.pending_block_data.contains_key(&block_hash)
                || self.h2_v4_unbound_blocks.contains_key(&block_hash)
            {
                continue;
            }
            let attempted = {
                let entry = self
                    .h2_v4_fetch_failed_peers
                    .entry(block_hash)
                    .or_insert_with(|| (now, HashSet::new()));
                if now.duration_since(entry.0) >= H2_V4_FETCH_RETRY_ROUND {
                    entry.0 = now;
                    entry.1.clear();
                }
                entry.1.insert(previous_peer);
                entry.1.clone()
            };
            while self.h2_v4_fetch_failed_peers.len() > 2048 {
                self.h2_v4_fetch_failed_peers.pop_first();
            }
            let mut retry_peer = self
                .connected_peers
                .iter()
                .copied()
                .find(|peer| !attempted.contains(peer));
            if retry_peer.is_none() {
                // Every connected peer has had one bounded attempt. Start a
                // fresh round instead of leaving this ancestry hash stranded.
                if let Some(entry) = self.h2_v4_fetch_failed_peers.get_mut(&block_hash) {
                    entry.0 = now;
                    entry.1.clear();
                }
                retry_peer = self.connected_peers.iter().copied().next();
            }
            if let Some(retry_peer) = retry_peer {
                counter!("n42_h2_v4_block_fetch_deadline_retries_total").increment(1);
                warn!(
                    target: "n42::interop::h2v4",
                    %block_hash,
                    %previous_peer,
                    %retry_peer,
                    attempted = attempted.len(),
                    "authenticated Gov5 block fetch deadline expired; retrying"
                );
                self.request_h2_v4_gov5_block(retry_peer, block_hash);
            } else {
                self.h2_v4_fetch_requested_at
                    .insert(block_hash, (now, previous_peer));
            }
        }
    }

    async fn retire_h2_v4_fetch_satisfied_elsewhere(&mut self, block_hash: B256) {
        self.h2_v4_fetch_requested_at.remove(&block_hash);
        self.h2_v4_fetch_failed_peers.remove(&block_hash);
        self.remember_h2_v4_fetch_fulfilled(block_hash, Instant::now());
        // The observer and participant orchestrators share one network
        // service, but intentionally keep independent ancestry trackers. A
        // body delivered to this orchestrator can therefore satisfy a fetch
        // started by the other one. Always retire the network-layer hash;
        // conditioning this command on the local tracker leaves that shared
        // request alive until its transport deadline.
        if let Err(error) = self
            .network
            .cancel_gov5_block_fetch_reliable(block_hash)
            .await
        {
            warn!(
                target: "n42::interop::h2v4",
                %block_hash,
                %error,
                "could not retire Gov5 fetch satisfied by another delivery path"
            );
        }
    }

    fn remember_h2_v4_block_view(&mut self, block_hash: B256, view: u64) {
        const MAX_H2_V4_BLOCK_BINDINGS: usize = 2048;
        if !self.h2_v4_block_views.contains_key(&block_hash) {
            self.h2_v4_block_view_order.push_back(block_hash);
        }
        self.h2_v4_block_views.insert(block_hash, view);
        while self.h2_v4_block_views.len() > MAX_H2_V4_BLOCK_BINDINGS {
            let Some(oldest) = self.h2_v4_block_view_order.pop_front() else {
                break;
            };
            self.h2_v4_block_views.remove(&oldest);
        }
    }

    fn prune_executed_h2_v4_catchup_history(&mut self) {
        while self
            .h2_v4_catchup_blocks
            .first_key_value()
            .is_some_and(|(height, _)| *height <= self.head_block_number)
        {
            self.h2_v4_catchup_blocks.pop_first();
        }
        if self.h2_v4_last_pruned_head_block_number != Some(self.head_block_number) {
            self.h2_v4_block_numbers
                .retain(|_, height| *height > self.head_block_number);
            self.h2_v4_last_pruned_head_block_number = Some(self.head_block_number);
        }
        if self.h2_v4_catchup_blocks.is_empty() {
            self.h2_v4_catchup_active = false;
        }
    }

    fn stage_h2_v4_catchup_block(
        &mut self,
        source: PeerId,
        rlp: Vec<u8>,
        height: u64,
        authenticated_view: u64,
        activate: bool,
    ) -> bool {
        self.prune_executed_h2_v4_catchup_history();
        if self.h2_v4_catchup_blocks.len() >= self.h2_v4_catchup_buffer_blocks
            && !self.h2_v4_catchup_blocks.contains_key(&height)
        {
            error!(
                target: "n42::interop::h2v4",
                limit = self.h2_v4_catchup_buffer_blocks,
                height,
                "authenticated Gov5 catch-up exceeds the bounded buffer"
            );
            return false;
        }
        self.h2_v4_catchup_blocks
            .insert(height, (source, rlp, authenticated_view));
        if activate {
            self.h2_v4_catchup_active = true;
        }
        let buffered = self.h2_v4_catchup_blocks.len();
        if buffered == 1 || buffered.is_multiple_of(1024) {
            info!(
                target: "n42::interop::h2v4",
                buffered,
                oldest_height = self.h2_v4_catchup_blocks.first_key_value().map(|(height, _)| *height),
                newest_height = self.h2_v4_catchup_blocks.last_key_value().map(|(height, _)| *height),
                execution_head_number = self.head_block_number,
                "authenticated Gov5 reverse ancestry progress"
            );
        }
        true
    }

    fn ready_h2_v4_bound_blocks_in_height_order(&self) -> Vec<B256> {
        let mut ready = self
            .h2_v4_unbound_blocks
            .iter()
            .filter(|(hash, _)| self.h2_v4_block_views.contains_key(*hash))
            .map(|(hash, (_, rlp))| {
                let height = n42_network::decode_gov5_block_rlp(rlp)
                    .map(|block| block.header.number)
                    // Keep malformed entries visible to the canonical handler,
                    // which records the rejection. They sort behind valid bodies.
                    .unwrap_or(u64::MAX);
                (height, *hash)
            })
            .collect::<Vec<_>>();
        ready.sort_unstable();
        ready.into_iter().map(|(_, hash)| hash).collect()
    }

    fn ready_h2_v4_catchup_heights(&self) -> Option<Vec<u64>> {
        if !self.h2_v4_catchup_active {
            return None;
        }
        // During a far reverse walk, the suffix is deliberately contiguous at
        // its newest end but has not reached the durable execution head yet.
        // This readiness function is called after every lifecycle event; a
        // full newest-to-oldest scan here makes catch-up quadratic. The oldest
        // buffered body can close the suffix only when it is the exact direct
        // successor of the durable head. Keep the common incomplete check O(1)
        // and perform the full hash-chain validation only once that boundary
        // is present.
        let expected_first_height = self.head_block_number.checked_add(1)?;
        let (&first_height, (_, oldest_rlp, _)) = self.h2_v4_catchup_blocks.first_key_value()?;
        if first_height != expected_first_height {
            return None;
        }
        let oldest = n42_network::decode_gov5_block_rlp(oldest_rlp).ok()?;
        if oldest.header.parent_hash != self.head_block_hash {
            return None;
        }
        // The unbound-message cache can release old, already-executed blocks
        // after a QC jump authenticates their hashes. Starting at the newest
        // authenticated block, select only the exact parent-hash chain that
        // terminates at the durable execution head.
        let (&last_height, (_, newest_rlp, _)) = self.h2_v4_catchup_blocks.last_key_value()?;
        let newest = n42_network::decode_gov5_block_rlp(newest_rlp).ok()?;
        let mut expected_hash = newest.block_hash;
        let mut height = last_height;
        let mut selected_heights = Vec::new();
        loop {
            let (_, candidate_rlp, _) = self.h2_v4_catchup_blocks.get(&height)?;
            let candidate = n42_network::decode_gov5_block_rlp(candidate_rlp).ok()?;
            if candidate.block_hash != expected_hash {
                return None;
            }
            selected_heights.push(height);
            if candidate.header.parent_hash == self.head_block_hash {
                selected_heights.reverse();
                return Some(selected_heights);
            }
            if height == 0 {
                return None;
            }
            expected_hash = candidate.header.parent_hash;
            height -= 1;
        }
    }

    async fn release_ready_h2_v4_catchup_blocks(&mut self) -> bool {
        let Some(selected_heights) = self.ready_h2_v4_catchup_heights() else {
            return false;
        };
        let mut catchup = Vec::with_capacity(selected_heights.len());
        for height in selected_heights {
            let Some(entry) = self.h2_v4_catchup_blocks.remove(&height) else {
                error!(target: "n42::interop::h2v4", height, "selected Gov5 catch-up block disappeared");
                return false;
            };
            catchup.push(entry);
        }
        // Everything left is an unrelated historical release or a stale
        // branch at/below the selected suffix. Retaining it would poison the
        // next catch-up activation.
        self.h2_v4_catchup_blocks.clear();
        self.h2_v4_catchup_active = false;
        info!(
            target: "n42::interop::h2v4",
            blocks = catchup.len(),
            "releasing reverse-delivered authenticated Gov5 ancestry in execution order"
        );
        for (catchup_source, catchup_rlp, catchup_view) in catchup {
            let catchup_block = match n42_network::decode_gov5_block_rlp(&catchup_rlp) {
                Ok(block) => block,
                Err(error) => {
                    error!(target: "n42::interop::h2v4", %error, "buffered Gov5 block failed repeat decoding");
                    return false;
                }
            };
            if !self
                .import_h2_v4_catchup_block(catchup_source, catchup_block, catchup_view)
                .await
            {
                return false;
            }
        }
        info!(
            target: "n42::interop::h2v4",
            execution_validated_view = self.execution_validated_head_view,
            execution_validated_head = %self.head_block_hash,
            "authenticated Gov5 ancestry reached a durable execution head"
        );
        true
    }

    async fn handle_h2_v4_gov5_block(
        &mut self,
        source: PeerId,
        rlp: Vec<u8>,
        requested_hash: Option<B256>,
    ) {
        const MAX_H2_V4_UNBOUND_BLOCKS: usize = 512;
        let block = match n42_network::decode_gov5_block_rlp(&rlp) {
            Ok(block) => block,
            Err(error) => {
                counter!("n42_h2_v4_blocks_rejected_total", "reason" => "decode").increment(1);
                warn!(target: "n42::interop::h2v4", %source, %error, "rejected invalid gov5 block body");
                return;
            }
        };
        if requested_hash.is_some_and(|expected| expected != block.block_hash) {
            counter!("n42_h2_v4_blocks_rejected_total", "reason" => "requested_hash").increment(1);
            warn!(target: "n42::interop::h2v4", %source, expected = ?requested_hash, received = %block.block_hash, "gov5 block response hash mismatch");
            return;
        }
        self.retire_h2_v4_fetch_satisfied_elsewhere(block.block_hash)
            .await;
        let Some(bound_view) = self.h2_v4_block_views.get(&block.block_hash).copied() else {
            self.h2_v4_unbound_blocks
                .insert(block.block_hash, (source, rlp));
            while self.h2_v4_unbound_blocks.len() > MAX_H2_V4_UNBOUND_BLOCKS {
                self.h2_v4_unbound_blocks.pop_first();
            }
            debug!(target: "n42::interop::h2v4", %source, hash = %block.block_hash, number = block.header.number, "holding gov5 block until H2-v4 authenticates its hash");
            return;
        };
        let view = match n42_network::gov5_header_view(&block.header) {
            Ok(view) => view,
            Err(error) => {
                counter!("n42_h2_v4_blocks_rejected_total", "reason" => "header_view").increment(1);
                warn!(target: "n42::interop::h2v4", %source, hash = %block.block_hash, %error, "rejected Gov5 block without an exact header view");
                return;
            }
        };
        // A verified proposal can legitimately re-propose an already built
        // locked block in a later view, so its certificate view may be newer
        // than the immutable view committed into that block's header. The
        // authenticated hash already binds the complete header/body; only a
        // header claiming a view newer than its certificate is impossible.
        // Zero remains the internal transitively-authenticated parent sentinel.
        if bound_view != 0 && view > bound_view {
            counter!("n42_h2_v4_blocks_rejected_total", "reason" => "consensus_header_view")
                .increment(1);
            warn!(target: "n42::interop::h2v4", %source, hash = %block.block_hash, bound_view, header_view = view, "rejected Gov5 block whose header view is newer than its H2 certificate");
            return;
        }
        self.remember_h2_v4_block_view(block.block_hash, view);
        if block.header.number <= self.head_block_number {
            self.prune_executed_h2_v4_catchup_history();
            debug!(
                target: "n42::interop::h2v4",
                %source,
                hash = %block.block_hash,
                number = block.header.number,
                execution_head_number = self.head_block_number,
                "ignoring already-executed historical Gov5 block"
            );
            return;
        }
        // Retain heights only after the body hash has an authenticated H2
        // binding and only while it is ahead of the durable execution floor.
        // Otherwise a stream of unbound or already-executed history could
        // evict the mapping for a live asynchronous Engine API completion.
        self.h2_v4_block_numbers
            .insert(block.block_hash, block.header.number);
        // Keep the complete bounded reverse suffix addressable by hash. Live
        // proposals can otherwise start overlapping ancestry walkers: when an
        // already-staged parent falls out of a small hash index, re-downloading
        // it recursively walks the same historical chain again.
        let block_number_index_limit = self
            .h2_v4_catchup_buffer_blocks
            .saturating_add(DEFAULT_H2_V4_CATCHUP_BUFFER_BLOCKS);
        while self.h2_v4_block_numbers.len() > block_number_index_limit {
            self.h2_v4_block_numbers.pop_first();
        }
        // A consensus-authenticated child header cryptographically binds its
        // exact parent hash. Walk that ancestry newest-to-oldest, but buffer
        // execution until the complete bounded segment can be released in
        // ascending order. This still exercises reverse network delivery while
        // ensuring every parent reaches Engine API before its child.
        // A known hash binding is not proof that the parent reached execution:
        // several future Proposal/QC messages can arrive together and populate
        // the binding map while Reth is still behind. The only safe live
        // boundary is the durable execution head itself.
        let missing_parent =
            block.header.number > 0 && block.header.parent_hash != self.head_block_hash;
        // Retain even the direct successor until execution advances. If several
        // authenticated bodies are released from a backlogged consensus batch,
        // the successor may be handled asynchronously just before its child
        // reveals the gap. Without this one-block staging floor, catch-up then
        // lacks the exact first parent and cannot reconnect to the durable head.
        let activate_catchup = self.h2_v4_catchup_active || missing_parent;
        if !self.stage_h2_v4_catchup_block(
            source,
            rlp.clone(),
            block.header.number,
            view,
            activate_catchup,
        ) {
            return;
        }
        if missing_parent {
            // The child header authenticates the exact parent hash, but timeout
            // views mean the parent's view cannot be inferred arithmetically.
            // Record a sentinel until the parent header supplies its exact view.
            if !self
                .h2_v4_block_views
                .contains_key(&block.header.parent_hash)
            {
                self.remember_h2_v4_block_view(block.header.parent_hash, 0);
            }
            self.request_h2_v4_gov5_block(source, block.header.parent_hash);
            return;
        }
        if self.h2_v4_catchup_active {
            if !self.release_ready_h2_v4_catchup_blocks().await {
                warn!(
                    target: "n42::interop::h2v4",
                    buffered = self.h2_v4_catchup_blocks.len(),
                    execution_head = %self.head_block_hash,
                    "waiting for authenticated Gov5 suffix to reach the durable execution head"
                );
            }
        } else {
            self.process_h2_v4_gov5_block(source, block, view).await;
        }
    }

    /// Imports a transitively authenticated catch-up segment synchronously.
    ///
    /// `handle_block_data` is intentionally concurrent for the ordinary live
    /// path. A far-behind node needs the stronger property that every parent
    /// obtains `new_payload(Valid)` before its child and that each successful
    /// FCU immediately persists the exact header-derived view/hash proof.
    async fn import_h2_v4_catchup_block(
        &mut self,
        source: PeerId,
        block: n42_network::Gov5GossipBlock,
        view: u64,
    ) -> bool {
        let Some(el) = self.el.clone() else {
            error!(target: "n42::interop::h2v4", "cannot import authenticated Gov5 catch-up without an execution layer");
            return false;
        };
        let block_hash = block.block_hash;
        let block_number = block.header.number;
        let block_timestamp = block.header.timestamp;
        let execution_data = match crate::replay_import::build_gov5_gossip_execution_data(&block) {
            Ok(data) => data,
            Err(error) => {
                error!(target: "n42::interop::h2v4", %source, %block_hash, block_number, view, %error, "could not reconstruct authenticated Gov5 catch-up payload");
                return false;
            }
        };

        match el
            .new_payload_for(ExecutionPath::HISTORICAL_SEQUENTIAL, execution_data)
            .await
        {
            Ok(status) if matches!(status.status, PayloadStatusEnum::Valid) => {
                info!(target: "n42::interop::h2v4", %block_hash, block_number, view, "authenticated Gov5 catch-up parent reached new_payload(Valid)");
            }
            Ok(status) => {
                error!(target: "n42::interop::h2v4", %source, %block_hash, block_number, view, status = ?status.status, "authenticated Gov5 catch-up stopped on non-Valid payload");
                return false;
            }
            Err(error) => {
                error!(target: "n42::interop::h2v4", %source, %block_hash, block_number, view, %error, "authenticated Gov5 catch-up new_payload failed");
                return false;
            }
        }

        // Blocks at/below the durable floor have already been made canonical by
        // bootstrap or an earlier run. Re-submitting them to new_payload proves
        // the complete parent chain without issuing a backward FCU.
        if view <= self.execution_validated_head_view {
            if let Err(error) =
                self.engine
                    .process_event(n42_consensus::ConsensusEvent::BlockImportedWithParent {
                        block_hash,
                        parent_hash: block.header.parent_hash,
                    })
            {
                error!(target: "n42::interop::h2v4", %block_hash, view, %error, "could not release execution-gated vote for replayed Gov5 parent");
            }
            return true;
        }

        let forkchoice = ForkchoiceState {
            head_block_hash: block_hash,
            safe_block_hash: block_hash,
            finalized_block_hash: block_hash,
        };
        match el
            .fork_choice_updated_for(ExecutionPath::HISTORICAL_SEQUENTIAL, forkchoice)
            .await
        {
            Ok(result) if matches!(result.payload_status.status, PayloadStatusEnum::Valid) => {
                self.last_committed_timestamp = self.last_committed_timestamp.max(block_timestamp);
                self.advance_execution_validated_head(
                    view,
                    block_hash,
                    "authenticated Gov5 catch-up",
                );
                self.head_block_number = self.head_block_number.max(block_number);
                self.prune_executed_h2_v4_catchup_history();
                crate::qualification_abort_at("execution_validated");
                // This synchronous catch-up path bypasses handle_valid_import,
                // which normally releases the H2 execution-gated vote and
                // closes a matching deferred finalization. Omitting these
                // notifications leaves the consensus state machine waiting
                // forever even though Reth is already canonical at this hash.
                let imported = BlockDataBroadcast {
                    block_hash,
                    view,
                    payload_json: Vec::new(),
                    timestamp: block_timestamp,
                    execution_output: None,
                    leader_ready_unix_ms: 0,
                };
                self.complete_deferred_finalization(&imported).await;
                if let Err(error) = self.engine.process_event(
                    n42_consensus::ConsensusEvent::BlockImportedWithParent {
                        block_hash,
                        parent_hash: block.header.parent_hash,
                    },
                ) {
                    error!(target: "n42::interop::h2v4", %block_hash, view, %error, "could not release execution-gated vote for Gov5 catch-up block");
                }
                true
            }
            Ok(result) => {
                error!(target: "n42::interop::h2v4", %source, %block_hash, block_number, view, status = ?result.payload_status.status, "authenticated Gov5 catch-up FCU was not Valid");
                false
            }
            Err(error) => {
                error!(target: "n42::interop::h2v4", %source, %block_hash, block_number, view, %error, "authenticated Gov5 catch-up FCU failed");
                false
            }
        }
    }

    async fn process_h2_v4_gov5_block(
        &mut self,
        source: PeerId,
        block: n42_network::Gov5GossipBlock,
        view: u64,
    ) {
        let mut execution_data = match crate::replay_import::build_gov5_gossip_execution_data(
            &block,
        ) {
            Ok(data) => data,
            Err(error) => {
                counter!("n42_h2_v4_blocks_rejected_total", "reason" => "execution_payload")
                    .increment(1);
                warn!(target: "n42::interop::h2v4", %source, hash = %block.block_hash, %error, "could not reconstruct gov5 execution payload");
                return;
            }
        };
        let payload_json = match encode_execution_payload(&mut execution_data) {
            Ok(payload) => compress_payload(&payload.bytes),
            Err(error) => {
                warn!(target: "n42::interop::h2v4", %source, hash = %block.block_hash, %error, "could not serialize gov5 execution payload");
                return;
            }
        };
        let broadcast = BlockDataBroadcast {
            block_hash: block.block_hash,
            view,
            payload_json,
            timestamp: block.header.timestamp,
            execution_output: None,
            leader_ready_unix_ms: 0,
        };
        match bincode::serialize(&broadcast) {
            Ok(data) => self.handle_block_data(data).await,
            Err(error) => {
                warn!(target: "n42::interop::h2v4", %source, hash = %block.block_hash, %error, "could not encode internal block data")
            }
        }
    }

    async fn drain_h2_v4_bound_blocks(&mut self) {
        // The cache is keyed by hash for authentication lookup, but execution
        // ancestry is ordered by height. A temporarily backlogged batch can
        // contain several bodies; hash-order release makes children race their
        // parents and can strand reth in Syncing even though every body arrived.
        let ready = self.ready_h2_v4_bound_blocks_in_height_order();
        for hash in ready {
            if let Some((source, rlp)) = self.h2_v4_unbound_blocks.remove(&hash) {
                self.handle_h2_v4_gov5_block(source, rlp, Some(hash)).await;
            }
        }
    }

    /// Returns true when an identical H2 message was published less than
    /// `H2_REBROADCAST_MIN_INTERVAL` ago; records the publish otherwise.
    fn h2_rebroadcast_suppressed(&self, encoded: &[u8]) -> bool {
        let key = *blake3::hash(encoded).as_bytes();
        let now = Instant::now();
        let mut recent = self
            .recent_h2_broadcasts
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        if let Some(last) = recent.get(&key)
            && now.duration_since(*last) < H2_REBROADCAST_MIN_INTERVAL
        {
            return true;
        }
        if recent.len() >= 512 {
            recent.retain(|_, sent| now.duration_since(*sent) < Duration::from_secs(10));
        }
        recent.insert(key, now);
        false
    }

    fn broadcast_engine_consensus(&self, message: ConsensusMessage) -> Result<(), NetworkError> {
        #[cfg(debug_assertions)]
        let mut message = message;
        // Deliberately corrupts our own signatures so a qualification run can
        // observe how peers reject them. Vote and CommitVote go out once per
        // validator per block on the native path too, so an env var alone is
        // not a safe gate: a stray value in a unit file or container image
        // would silently stop this node from producing a valid vote in any
        // view. Compiled out of release builds entirely.
        #[cfg(debug_assertions)]
        if std::env::var("N42_QUALIFICATION_FORGE_CONSENSUS")
            .ok()
            .as_deref()
            == Some("1")
        {
            let forged = BlsSecretKey::key_gen(&[0xA5; 32])
                .expect("fixed qualification BLS key must be valid")
                .sign(b"n42-qualification-forged-consensus");
            match &mut message {
                ConsensusMessage::Proposal(value) => value.signature = forged.clone(),
                ConsensusMessage::Vote(value) => value.signature = forged.clone(),
                ConsensusMessage::CommitVote(value) => value.signature = forged.clone(),
                ConsensusMessage::Timeout(value) => value.signature = forged.clone(),
                ConsensusMessage::NewView(value) => value.signature = forged,
                ConsensusMessage::PrepareQC(_) | ConsensusMessage::Decide(_) => {}
            }
        }
        if let Some(identity) = self.h2_v4_identity {
            let envelope =
                n42_network::consensus_to_h2_v4(identity, &message).map_err(|error| {
                    NetworkError::Codec(format!("H2-v4 consensus conversion failed: {error}"))
                })?;
            let encoded = n42_network::h2_wire::encode_gov5_gossip_message(&envelope.message)
                .map_err(|error| NetworkError::Codec(format!("H2 encoding failed: {error}")))?;
            if self.h2_rebroadcast_suppressed(&encoded) {
                counter!("n42_h2_v4_rebroadcasts_suppressed_total", "kind" => envelope.message.kind().as_str())
                    .increment(1);
                debug!(target: "n42::interop::h2v4", kind = envelope.message.kind().as_str(), "suppressed identical H2 rebroadcast");
                return Ok(());
            }
            self.network.broadcast_h2_v4(envelope)
        } else {
            self.network.broadcast_consensus(message)
        }
    }

    fn vote_resend_delay() -> Duration {
        Duration::from_millis(
            std::env::var("N42_VOTE_RESEND_MS")
                .ok()
                .and_then(|value| value.parse::<u64>().ok())
                .unwrap_or(DEFAULT_VOTE_RESEND_MS)
                .max(100),
        )
    }

    fn resend_pending_vote(&mut self) {
        let Some(pending) = self.pending_vote_resend.clone() else {
            return;
        };

        let current_view = self.engine.current_view();
        if pending.view != current_view {
            self.pending_vote_resend = None;
            return;
        }

        let mut delivered_directly = false;
        if self.h2_v4_identity.is_none()
            && let Some(peer_id) = self.network.validator_peer(pending.target)
        {
            match self.network.send_direct(peer_id, pending.message.clone()) {
                Ok(()) => delivered_directly = true,
                Err(error) => warn!(
                    target: "n42::cl::orchestrator",
                    view = pending.view,
                    target = pending.target,
                    %error,
                    "direct vote resend failed; falling back to gossip"
                ),
            }
        }

        if !delivered_directly && let Err(error) = self.broadcast_engine_consensus(pending.message)
        {
            warn!(
                target: "n42::cl::orchestrator",
                view = pending.view,
                target = pending.target,
                %error,
                "fallback gossip vote resend failed"
            );
        }

        counter!("n42_consensus_vote_resends_total", "delivery" => if delivered_directly { "direct" } else { "gossip" })
            .increment(1);
        if let Some(next) = self.pending_vote_resend.as_mut() {
            next.next_at = Instant::now() + Self::vote_resend_delay();
        }
    }

    fn async_finalize_fcu_enabled() -> bool {
        std::env::var("N42_ASYNC_FINALIZE_FCU")
            .ok()
            .and_then(|v| v.parse::<u64>().ok())
            // Unit tests keep the synchronous completion path unless they opt
            // in explicitly; production uses the asynchronous state machine.
            .unwrap_or(if cfg!(test) { 0 } else { 1 })
            > 0
    }

    fn mobile_packet_generation_enabled() -> bool {
        static ENABLED: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
        *ENABLED.get_or_init(|| {
            !matches!(
                std::env::var("N42_DISABLE_MOBILE_PACKETS").ok().as_deref(),
                Some("1") | Some("true") | Some("yes")
            )
        })
    }

    fn cache_pending_block_data(
        &mut self,
        hash: B256,
        data: impl Into<SharedBlockData>,
        protected_hashes: &[B256],
    ) -> bool {
        self.cache_pending_block_data_inner(hash, data.into(), protected_hashes, None)
    }

    fn cache_pending_block_data_with_metadata(
        &mut self,
        hash: B256,
        data: impl Into<SharedBlockData>,
        protected_hashes: &[B256],
        view: u64,
        payload_len: usize,
    ) -> bool {
        self.cache_pending_block_data_inner(
            hash,
            data.into(),
            protected_hashes,
            Some((view, payload_len)),
        )
    }

    fn cache_pending_block_data_inner(
        &mut self,
        hash: B256,
        data: SharedBlockData,
        protected_hashes: &[B256],
        metadata: Option<(u64, usize)>,
    ) -> bool {
        // A Decide-before-BlockData race may have left the sidecar paused at
        // this committed view. Recover the owned StateDiff directly from the
        // late bytes even if the bounded raw-data cache cannot retain them.
        self.try_recover_missing_sidecar_diff(hash, &data);
        self.remember_recent_block_data(hash, Arc::clone(&data), metadata);
        if self.pending_block_data.contains_key(&hash) {
            return false;
        }

        if self.pending_block_data.len() >= execution_bridge::MAX_PENDING_BLOCK_DATA {
            let evict_key = self
                .pending_block_data
                .keys()
                .find(|candidate| !protected_hashes.contains(*candidate))
                .copied();

            let Some(evict_key) = evict_key else {
                counter!("n42_pending_block_data_full_protected_drop_total").increment(1);
                warn!(
                    target: "n42::cl::orchestrator",
                    %hash,
                    protected = protected_hashes.len(),
                    "pending block data cache full with no evictable entry, dropping block data"
                );
                return false;
            };
            self.pending_block_data.remove(&evict_key);
        }

        self.pending_block_data.insert(hash, data);
        true
    }

    fn remember_recent_block_data(
        &mut self,
        hash: B256,
        data: SharedBlockData,
        metadata: Option<(u64, usize)>,
    ) {
        if self
            .recent_block_data
            .iter()
            .any(|entry| entry.block_hash == hash)
        {
            return;
        }
        let (view, payload_len) = match metadata {
            Some(metadata) => metadata,
            None => {
                let Ok(broadcast) = bincode::deserialize::<BlockDataBroadcast>(data.as_slice())
                else {
                    return;
                };
                if broadcast.block_hash != hash {
                    return;
                }
                (broadcast.view, broadcast.payload_json.len())
            }
        };
        if self.recent_block_data.len() >= execution_bridge::MAX_PENDING_BLOCK_DATA {
            self.recent_block_data.pop_front();
        }
        counter!(
            "n42_block_data_copy_avoided_bytes_total",
            "site" => "recent_cache"
        )
        .increment(data.len() as u64);
        self.recent_block_data.push_back(RecentBlockData {
            view,
            block_hash: hash,
            block_data: data,
            payload_len,
            execution_parent_hash: None,
            execution_block_number: None,
            execution_has_staking_target: None,
            execution_state_diff: None,
        });
    }

    fn record_validated_execution_metadata(
        &mut self,
        hash: B256,
        parent_hash: B256,
        block_number: u64,
        has_staking_target: bool,
        state_diff: Option<n42_execution::state_diff::StateDiff>,
    ) {
        if let Some(entry) = self
            .recent_block_data
            .iter_mut()
            .find(|entry| entry.block_hash == hash)
        {
            entry.execution_parent_hash = Some(parent_hash);
            entry.execution_block_number = Some(block_number);
            entry.execution_has_staking_target = Some(has_staking_target);
            // Eager validity is intentionally reported before the auxiliary
            // state-diff worker completes. A metadata refresh carrying `None`
            // must not erase a diff that won the channel race and arrived first.
            if state_diff.is_some() {
                entry.execution_state_diff = state_diff;
            }
        }
    }

    fn execution_parent_and_number(data: &[u8]) -> Option<(B256, u64)> {
        let broadcast = bincode::deserialize::<BlockDataBroadcast>(data).ok()?;
        let payload = decompress_payload(&broadcast.payload_json).ok()?;
        let execution = decode_execution_payload_owned(payload).ok()?;
        (execution.block_hash() == broadcast.block_hash)
            .then(|| (execution.parent_hash(), execution.block_number()))
    }

    fn execution_parent_and_number_from_payload(payload_json: &[u8]) -> Option<(B256, u64)> {
        let payload = decompress_payload(payload_json).ok()?;
        let execution = decode_execution_payload_owned(payload).ok()?;
        Some((execution.parent_hash(), execution.block_number()))
    }

    /// Returns the raw execution chain from the current validated head through
    /// `block_hash`. An empty result means the bounded proposal cache cannot
    /// prove a complete parent-linked lineage and callers must stay conservative.
    fn recent_execution_lineage(&self, block_hash: B256) -> Vec<RecentBlockData> {
        let mut current = block_hash;
        let mut reversed = Vec::new();
        let mut seen = HashSet::new();

        while current != self.head_block_hash
            && reversed.len() < execution_bridge::MAX_PENDING_BLOCK_DATA
        {
            if !seen.insert(current) {
                return Vec::new();
            }
            let Some(mut entry) = self
                .recent_block_data
                .iter()
                .find(|entry| entry.block_hash == current)
                .cloned()
            else {
                return Vec::new();
            };
            let (parent, block_number) =
                match (entry.execution_parent_hash, entry.execution_block_number) {
                    (Some(parent), Some(block_number)) => (parent, block_number),
                    _ => {
                        let Some(metadata) = Self::execution_parent_and_number(&entry.block_data)
                        else {
                            return Vec::new();
                        };
                        metadata
                    }
                };
            entry.execution_parent_hash = Some(parent);
            entry.execution_block_number = Some(block_number);
            reversed.push(entry);
            current = parent;
        }

        if current != self.head_block_hash {
            return Vec::new();
        }
        reversed.reverse();
        reversed
    }

    fn try_recover_missing_sidecar_diff(&mut self, hash: B256, data: &[u8]) {
        if self.jmt.is_none() && self.twig.is_none() {
            return;
        }
        let Some(view) = self
            .missing_sidecar_diffs
            .iter()
            .find_map(|(view, missing_hash)| (*missing_hash == hash).then_some(*view))
        else {
            return;
        };
        let Some(diff) = Self::extract_state_diff_for_state_tree(hash, data) else {
            return;
        };

        self.missing_sidecar_diffs.remove(&view);
        self.pending_sidecar_diffs.insert(view, (hash, diff));
        counter!("n42_sidecar_diff_gap_recovered_total").increment(1);
        info!(
            target: "n42::twig",
            view,
            %hash,
            "recovered missing committed sidecar diff from late block data"
        );
        if view <= self.execution_validated_head_view {
            self.enqueue_confirmed_sidecar_state_diffs(self.execution_validated_head_view);
        }
    }

    /// Drop a staged diff whose corresponding payload failed execution
    /// validation. Keeping peer-supplied bytes after a non-`Valid` result could
    /// let a later honest payload with the same declared hash flush the forged
    /// diff into QMDB/Twig.
    fn discard_unvalidated_sidecar_diff(&mut self, view: u64, hash: B256) {
        let matches = self
            .pending_sidecar_diffs
            .get(&view)
            .is_some_and(|(staged_hash, _)| *staged_hash == hash);
        let removed = matches && self.pending_sidecar_diffs.remove(&view).is_some();
        if removed {
            self.missing_sidecar_diffs.insert(view, hash);
            counter!("n42_sidecar_unvalidated_diffs_discarded_total").increment(1);
            warn!(
                target: "n42::twig",
                view,
                %hash,
                "discarded sidecar diff after payload failed execution validation"
            );
        }
    }

    fn leader_propose_warmup_delay() -> Duration {
        std::env::var("N42_STARTUP_DELAY_MS")
            .ok()
            .and_then(|s| s.parse::<u64>().ok())
            .filter(|v| *v > 0)
            .map(Duration::from_millis)
            .unwrap_or_else(|| Duration::from_millis(DEFAULT_LEADER_PROPOSE_WARMUP_MS))
    }

    fn leader_quorum_recheck_delay() -> Duration {
        Duration::from_millis(LEADER_QUORUM_RETRY_MS)
    }

    fn connected_validator_peer_count(&self) -> usize {
        let connected_peers: HashSet<_> = self.connected_peers.iter().copied().collect();
        self.network
            .all_validator_peers()
            .into_iter()
            .map(|(_, peer_id)| peer_id)
            .filter(|peer_id| connected_peers.contains(peer_id))
            .count()
    }

    fn quorum_peers_needed(&self) -> usize {
        // The leader contributes its own vote, so it needs n-f-1 connected
        // validator peers before building. This also makes f=0 multi-validator
        // sets wait for every other validator.
        self.engine.quorum_size().saturating_sub(1)
    }

    fn has_quorum_peers(&self) -> bool {
        self.connected_validator_peer_count() >= self.quorum_peers_needed()
    }

    fn pending_leader_build_mode_for_current_view(&self) -> Option<LeaderBuildWaitMode> {
        let current_view = self.engine.current_view();
        self.leader_build_waiting_view
            .and_then(|(view, mode)| (view == current_view).then_some(mode))
    }

    fn begin_leader_build_wait(&mut self, mode: LeaderBuildWaitMode, slot_timestamp: Option<u64>) {
        self.leader_build_waiting_view = Some((self.engine.current_view(), mode));
        self.next_slot_timestamp = slot_timestamp;
    }

    fn clear_leader_build_wait(&mut self) {
        self.leader_build_waiting_view = None;
        self.leader_build_not_before = None;
    }

    fn schedule_leader_build_recheck(&mut self, delay: Duration) {
        self.next_build_at = Some(Instant::now() + delay);
    }

    fn arm_leader_build_timer_as_direct_wait(&mut self, slot_timestamp: Option<u64>) {
        if self.pending_leader_build_mode_for_current_view().is_none() {
            self.begin_leader_build_wait(LeaderBuildWaitMode::Direct, slot_timestamp);
        } else if let Some(slot_timestamp) = slot_timestamp {
            self.next_slot_timestamp = Some(slot_timestamp);
        }
    }

    async fn evaluate_leader_build_wait(&mut self, slot_timestamp: Option<u64>) {
        let Some(mode) = self.pending_leader_build_mode_for_current_view() else {
            return;
        };

        if !self.engine.is_current_leader() {
            self.clear_leader_build_wait();
            return;
        }

        let current_view = self.engine.current_view();
        if let Some((floor_view, not_before)) = self.leader_build_not_before {
            if floor_view != current_view {
                self.leader_build_not_before = None;
            } else if let Some(remaining) = not_before.checked_duration_since(Instant::now()) {
                debug!(
                    target: "n42::cl::orchestrator",
                    view = current_view,
                    remaining_ms = remaining.as_millis() as u64,
                    "leader build waiting for warmup floor"
                );
                self.schedule_leader_build_recheck(remaining);
                return;
            } else {
                self.leader_build_not_before = None;
            }
        }

        if let Some(slot_timestamp) = slot_timestamp {
            self.next_slot_timestamp = Some(slot_timestamp);
        }

        let connected_validator_peers = self.connected_validator_peer_count();
        let needed_quorum_peers = self.quorum_peers_needed();
        let has_quorum_peers = self.has_quorum_peers();
        debug_assert_eq!(
            has_quorum_peers,
            connected_validator_peers >= needed_quorum_peers
        );
        if !has_quorum_peers {
            debug!(
                target: "n42::cl::orchestrator",
                view = self.engine.current_view(),
                ?mode,
                connected_validator_peers,
                needed_quorum_peers,
                "leader build waiting for validator peer quorum"
            );
            self.schedule_leader_build_recheck(Self::leader_quorum_recheck_delay());
            return;
        }

        info!(
            target: "n42::cl::orchestrator",
            view = self.engine.current_view(),
            ?mode,
            connected_validator_peers,
            needed_quorum_peers,
            "validator peer quorum reached for leader build"
        );

        self.clear_leader_build_wait();
        match mode {
            LeaderBuildWaitMode::Direct => {
                let slot_timestamp = self.next_slot_timestamp.take();
                self.do_trigger_payload_build(slot_timestamp).await;
            }
            LeaderBuildWaitMode::Scheduled => {
                self.schedule_payload_build().await;
            }
        }
    }

    /// Accepts a resolved payload only under the LockedQC parent/view captured
    /// when its build began. A view change must never wrap an old child of B in
    /// a new Proposal justified by LockedQC(A).
    fn handle_payload_build_ready(&mut self, ready: PayloadBuildReady) -> bool {
        let current_context = self.required_payload_build_context();
        let owns_guard = self.building_on_parent == Some(ready.context);
        if owns_guard {
            self.building_on_parent = None;
        }

        if current_context != Some(ready.context) {
            warn!(
                target: "n42::cl::orchestrator",
                built_view = ready.context.view,
                built_parent = %ready.context.parent_hash,
                current_view = self.engine.current_view(),
                required_parent = ?current_context.map(|context| context.parent_hash),
                block_hash = %ready.block_hash,
                "discarding payload resolved for stale view or non-LockedQC parent"
            );
            counter!("n42_stale_payload_builds_total").increment(1);
            if owns_guard {
                self.build_triggered_at = None;
            }
            if self.building_on_parent.is_none() {
                self.schedule_build_retry();
            }
            return false;
        }

        let now = Instant::now();
        let timing = PipelineTiming {
            created: self.build_triggered_at.take().unwrap_or(now),
            is_leader: true,
            build_complete: Some(now),
            import_complete: None,
            committed: None,
        };
        self.record_pipeline_timing(ready.block_hash, timing);

        info!(target: "n42::cl::orchestrator", hash = %ready.block_hash,
            view = ready.context.view, parent = %ready.context.parent_hash,
            "payload built on LockedQC parent, feeding BlockReady to consensus");
        if let Err(error) = self
            .engine
            .process_event(n42_consensus::ConsensusEvent::BlockReady(
                ready.block_hash,
                None,
            ))
        {
            error!(target: "n42::cl::orchestrator", %error, "error processing BlockReady event");
            return false;
        }
        true
    }

    /// Clears only the guard owned by the task that completed. An older
    /// resolve task may finish after a new-view build has already started.
    fn handle_payload_build_complete(&mut self, completed: PayloadBuildContext) -> bool {
        if self.building_on_parent != Some(completed) {
            debug!(target: "n42::cl::orchestrator", ?completed,
                active = ?self.building_on_parent,
                "ignoring stale payload-build completion");
            return false;
        }

        debug!(target: "n42::cl::orchestrator", ?completed,
            "build task completed, clearing its building_on_parent guard");
        self.building_on_parent = None;
        self.build_triggered_at = None;
        true
    }

    fn drain_leader_payload_rx(&mut self, protected_hashes: &[B256]) {
        while let Ok((hash, data)) = self.leader_payload_rx.try_recv() {
            let decoded = bincode::deserialize::<BlockDataBroadcast>(&data).ok();
            if let Some(broadcast) = decoded.as_ref() {
                self.cache_pending_block_data_with_metadata(
                    hash,
                    Arc::clone(&data),
                    protected_hashes,
                    broadcast.view,
                    broadcast.payload_json.len(),
                );
            } else {
                self.cache_pending_block_data(hash, Arc::clone(&data), protected_hashes);
            }
            let execution_lineage = self
                .recent_execution_lineage(hash)
                .into_iter()
                .map(|entry| SyncPayload {
                    view: entry.view,
                    block_hash: entry.block_hash,
                    block_data: entry.block_data.as_ref().clone(),
                })
                .collect::<Vec<_>>();
            if let Some(broadcast) = decoded {
                if broadcast.timestamp > 0 {
                    self.last_committed_timestamp =
                        self.last_committed_timestamp.max(broadcast.timestamp);
                }
                if let Some(block) = self
                    .committed_blocks
                    .iter_mut()
                    .rev()
                    .find(|block| block.block_hash == hash)
                {
                    if block.block_data.is_none() {
                        block.payload_len = broadcast.payload_json.len();
                        block.block_data = Some(Arc::clone(&data));
                        debug!(
                            target: "n42::cl::consensus_loop",
                            %hash,
                            "linked committed block to shared envelope while draining leader feedback"
                        );
                    }
                    if block.execution_lineage.is_empty() && execution_lineage.len() > 1 {
                        block.execution_lineage = execution_lineage;
                    }
                }
            }
        }
    }

    fn diag_leader_index_for_view(&self, view: u64) -> u32 {
        if view == self.engine.current_view() {
            return self.engine.current_leader_index();
        }
        let validator_count = self.engine.validator_count().max(1) as u64;
        (view % validator_count) as u32
    }

    fn timeout_diag_entry(&mut self, view: u64) -> &mut TimeoutViewDiag {
        const MAX_TIMEOUT_DIAG_VIEWS: usize = 256;
        while self.timeout_view_diags.len() >= MAX_TIMEOUT_DIAG_VIEWS {
            let Some(oldest) = self.timeout_view_diags.keys().next().copied() else {
                break;
            };
            self.timeout_view_diags.remove(&oldest);
        }
        self.timeout_view_diags.entry(view).or_default()
    }

    fn record_timeout_diag_build_start(
        &mut self,
        view: u64,
        parent: B256,
        pool_pending: usize,
        pool_queued: usize,
        build_start: Instant,
    ) {
        let leader_idx = self.diag_leader_index_for_view(view);
        let my_index = self.engine.my_index();
        let prev_view = view.saturating_sub(1);
        let prev_timeout_to_build_start_ms = self
            .timeout_view_diags
            .get(&prev_view)
            .and_then(|diag| diag.timeout_at)
            .map(|timeout_at| {
                build_start
                    .saturating_duration_since(timeout_at)
                    .as_millis() as u64
            });
        let prev_view_had_timeout = prev_timeout_to_build_start_ms.is_some();

        let diag = self.timeout_diag_entry(view);
        diag.build_start = Some(build_start);
        diag.build_pool_pending = pool_pending;
        diag.build_pool_queued = pool_queued;

        info!(
            target: "n42::cl::timeout_diag",
            view,
            leader_idx,
            my_index,
            %parent,
            pool_pending,
            pool_queued,
            prev_view,
            prev_view_had_timeout,
            prev_timeout_to_build_start_ms = prev_timeout_to_build_start_ms.unwrap_or(0),
            "N42_TIMEOUT_VIEW: leader_build_start"
        );
    }

    fn record_timeout_diag_block_data_received(
        &mut self,
        view: u64,
        hash: B256,
        bytes: usize,
        leader_ready_unix_ms: u64,
        duplicate: bool,
    ) {
        let now = Instant::now();
        let current_view = self.engine.current_view();
        let leader_idx = self.diag_leader_index_for_view(view);
        let my_index = self.engine.my_index();
        let since_leader_ready_ms = elapsed_since_unix_ms(leader_ready_unix_ms).unwrap_or(0);

        let diag = self.timeout_diag_entry(view);
        diag.block_data_received_count = diag.block_data_received_count.saturating_add(1);
        if diag.first_block_data_received.is_none() {
            diag.first_block_data_received = Some(now);
        }
        let received_after_timeout_ms = diag
            .timeout_at
            .map(|timeout_at| now.saturating_duration_since(timeout_at).as_millis() as u64);
        let timeout_seen = received_after_timeout_ms.is_some();

        info!(
            target: "n42::cl::timeout_diag",
            view,
            current_view,
            leader_idx,
            my_index,
            %hash,
            bytes,
            duplicate,
            block_data_received_count = diag.block_data_received_count,
            has_leader_ready_ts = leader_ready_unix_ms > 0,
            since_leader_ready_ms,
            timeout_seen,
            received_after_timeout_ms = received_after_timeout_ms.unwrap_or(0),
            "N42_TIMEOUT_VIEW: block_data_received"
        );
    }

    fn record_timeout_diag_timeout_triggered(&mut self, view: u64) {
        let now = Instant::now();
        let pool_depth = self.pool_depth_snapshot();
        let leader_idx = self.engine.current_leader_index();
        let my_index = self.engine.my_index();
        let elapsed_since_last_commit_ms = self
            .last_commit_instant
            .map(|last_commit| now.saturating_duration_since(last_commit).as_millis() as u64);
        let view_elapsed_ms = self
            .view_started_at
            .map(|started| started.elapsed().as_millis() as u64);

        let building_on_parent = self.building_on_parent;
        let next_build_scheduled = self.next_build_at.is_some();
        let speculative_build_hash = self.speculative_build_hash;
        let bg_import_in_flight = self.bg_import_in_flight;
        let bg_import_queue_len = self.bg_import_queue.len();
        let pending_block_data_len = self.pending_block_data.len();
        let pending_executions_len = self.pending_executions.len();
        let phase = format!("{:?}", self.engine.current_phase());
        let is_leader = self.engine.is_current_leader();
        let last_commit_view = self.last_commit_view.unwrap_or_default();
        let last_commit_hash = self.last_commit_hash;

        let diag = self.timeout_diag_entry(view);
        let build_started = diag.build_start.is_some();
        let build_start_age_ms = diag
            .build_start
            .map(|build_start| now.saturating_duration_since(build_start).as_millis() as u64);
        let block_data_received_count = diag.block_data_received_count;
        let block_data_before_timeout = diag.first_block_data_received.is_some();
        diag.timeout_at.get_or_insert(now);
        diag.timeout_pool_pending = pool_depth.pending;
        diag.timeout_pool_queued = pool_depth.queued;

        info!(
            target: "n42::cl::timeout_diag",
            view,
            leader_idx,
            my_index,
            is_leader,
            phase = %phase,
            pool_pending = pool_depth.pending,
            pool_queued = pool_depth.queued,
            last_commit_view,
            last_commit_hash = ?last_commit_hash,
            elapsed_since_last_commit_ms = elapsed_since_last_commit_ms.unwrap_or(0),
            has_last_commit = elapsed_since_last_commit_ms.is_some(),
            view_elapsed_ms = view_elapsed_ms.unwrap_or(0),
            has_view_start = view_elapsed_ms.is_some(),
            build_started,
            build_start_age_ms = build_start_age_ms.unwrap_or(0),
            block_data_received_count,
            block_data_before_timeout,
            pending_block_data_len,
            pending_executions_len,
            building_on_parent = ?building_on_parent,
            next_build_scheduled,
            speculative_build_hash = ?speculative_build_hash,
            bg_import_in_flight,
            bg_import_queue_len,
            "N42_TIMEOUT_VIEW: timeout_triggered"
        );
    }

    fn record_timeout_diag_view_changed(&mut self, new_view: u64) {
        let now = Instant::now();
        let timed_out_view = new_view.saturating_sub(1);
        let Some(diag) = self.timeout_view_diags.get(&timed_out_view) else {
            return;
        };
        let Some(timeout_at) = diag.timeout_at else {
            return;
        };
        let pool_depth = self.pool_depth_snapshot();
        let timeout_to_view_change_ms =
            now.saturating_duration_since(timeout_at).as_millis() as u64;
        let prev_leader_idx = self.diag_leader_index_for_view(timed_out_view);
        let next_leader_idx = self.diag_leader_index_for_view(new_view);

        info!(
            target: "n42::cl::timeout_diag",
            timed_out_view,
            new_view,
            prev_leader_idx,
            next_leader_idx,
            my_index = self.engine.my_index(),
            timeout_to_view_change_ms,
            timeout_pool_pending = diag.timeout_pool_pending,
            timeout_pool_queued = diag.timeout_pool_queued,
            pool_pending = pool_depth.pending,
            pool_queued = pool_depth.queued,
            build_started = diag.build_start.is_some(),
            block_data_received_count = diag.block_data_received_count,
            "N42_TIMEOUT_VIEW: view_change_after_timeout"
        );
    }

    pub fn new(
        engine: ConsensusEngine,
        network: Arc<dyn ConsensusNetwork>,
        net_event_rx: mpsc::Receiver<NetworkEvent>,
        output_rx: mpsc::Receiver<EngineOutput>,
    ) -> Self {
        // Tests use this constructor; create a dummy consensus channel.
        let (block_ready_tx, block_ready_rx) = mpsc::channel(256);
        let (leader_payload_tx, leader_payload_rx) = mpsc::channel(64);
        let (import_done_tx, import_done_rx) = mpsc::channel(256);
        let (finalize_done_tx, finalize_done_rx) = mpsc::channel(256);
        let (eager_import_done_tx, eager_import_done_rx) = mpsc::channel(256);
        let (commit_execution_timeout_tx, commit_execution_timeout_rx) = mpsc::channel(256);
        let (state_diff_ready_tx, state_diff_ready_rx) = mpsc::channel(256);
        let (build_complete_tx, build_complete_rx) = mpsc::channel(256);
        Self {
            engine,
            h2_v4_identity: None,
            h2_v4_block_views: BTreeMap::new(),
            h2_v4_block_view_order: VecDeque::new(),
            h2_v4_block_numbers: BTreeMap::new(),
            h2_v4_unbound_blocks: BTreeMap::new(),
            h2_v4_catchup_blocks: BTreeMap::new(),
            h2_v4_catchup_buffer_blocks: h2_v4_catchup_buffer_blocks(),
            h2_v4_last_pruned_head_block_number: None,
            h2_v4_catchup_active: false,
            h2_v4_fetch_failed_peers: BTreeMap::new(),
            h2_v4_fetch_requested_at: HashMap::new(),
            gov5_execution_pull_rounds: 0,
            gov5_execution_pull_last_at: None,
            h2_v4_fetch_fulfilled_at: HashMap::new(),
            network,
            consensus_event_rx: None,
            net_event_rx,
            output_rx,
            el: None,
            consensus_state: None,
            head_block_hash: B256::ZERO,
            head_block_number: 0,
            execution_validated_head_view: 0,
            eager_execution_validated: VecDeque::new(),
            pending_sidecar_diffs: BTreeMap::new(),
            execution_validated_sidecar_hashes: BTreeMap::new(),
            missing_sidecar_diffs: BTreeMap::new(),
            sidecar_apply_queue: Arc::new(std::sync::Mutex::new(VecDeque::new())),
            sidecar_apply_worker_running: Arc::new(std::sync::atomic::AtomicBool::new(false)),
            last_sidecar_applied_view: Arc::new(std::sync::atomic::AtomicU64::new(0)),
            last_commit_qc: None,
            prev_randao_cache: B256::ZERO,
            block_ready_tx,
            block_ready_rx,
            fee_recipient: Address::ZERO,
            slot_time: Duration::ZERO,
            next_build_at: None,
            next_slot_timestamp: None,
            consecutive_empty_skips: 0,
            pending_block_data: BTreeMap::new(),
            recent_block_data: VecDeque::new(),
            pending_executions: HashSet::new(),
            pending_finalization: None,
            async_commit_states: BTreeMap::new(),
            syncing_blocks: VecDeque::new(),
            bad_blocks: bad_block_cache::BadBlockCache::default(),
            tx_import_tx: None,
            tx_broadcast_rx: None,
            committed_blocks: VecDeque::new(),
            connected_peers: HashSet::new(),
            leader_build_waiting_view: None,
            leader_build_not_before: None,
            sync_in_flight: false,
            sync_started_at: None,
            sync_request_range: None,
            sync_requested_peers: HashSet::new(),
            state_file: None,
            validator_set_for_sync: None,
            epoch_sync_staged_view: None,
            mobile_packet_tx: None,
            leader_payload_rx,
            leader_payload_tx,
            import_done_rx,
            import_done_tx,
            finalize_done_rx,
            finalize_done_tx,
            blob_store: None,
            exec_output_cache: None,
            bg_import_in_flight: false,
            bg_import_hashes: HashSet::new(),
            bg_import_queue: VecDeque::new(),
            eager_import_done_tx,
            eager_import_done_rx,
            commit_execution_timeout_tx,
            commit_execution_timeout_rx,
            state_diff_ready_tx,
            state_diff_ready_rx,
            speculative_build_hash: None,
            building_on_parent: None,
            build_triggered_at: None,
            build_complete_tx,
            build_complete_rx,
            staking_sink: None,
            pending_staking_scans: BTreeMap::new(),
            withdrawal_source: None,
            committed_block_count: 0,
            last_committed_timestamp: 0,
            view_started_at: None,
            epoch_schedule: None,
            tx_forward_buffer: Vec::new(),
            tx_forward_missing_leader_warned_view: None,
            pending_vote_resend: None,
            recent_h2_broadcasts: std::sync::Mutex::new(HashMap::new()),
            leader_disabled: false,
            committee_pool: None,
            pipeline_timings: HashMap::new(),
            last_commit_instant: None,
            last_commit_view: None,
            last_commit_hash: None,
            timeout_view_diags: BTreeMap::new(),
            commit_to_build_recorded_parent: None,
            eager_import_block_guard: Arc::new(std::sync::atomic::AtomicU64::new(0)),
            fast_propose: std::env::var("N42_FAST_PROPOSE")
                .ok()
                .and_then(|v| v.parse::<u64>().ok())
                .unwrap_or(0)
                > 0,
            async_finalize_fcu: Self::async_finalize_fcu_enabled(),
            defer_state_root: false,
            jmt: None,
            twig: None,
            zk_scheduler: None,
            allow_deterministic_validator_peers: true,
            admin_rx: None,
            evidence_store: None,
            view_jump_throttle: view_jump_throttle::ViewJumpThrottle::default(),
        }
    }

    pub(super) async fn enqueue_mobile_packet(
        &self,
        block_hash: B256,
        view: u64,
        reason: &'static str,
    ) {
        if !Self::mobile_packet_generation_enabled() {
            return;
        }
        let Some(tx) = self.mobile_packet_tx.as_ref().cloned() else {
            return;
        };

        match tx.try_send((block_hash, view)) {
            Ok(()) => {}
            Err(tokio::sync::mpsc::error::TrySendError::Closed(_)) => {
                warn!(
                    target: "n42::cl::mobile",
                    %block_hash,
                    view,
                    reason,
                    "mobile packet channel closed"
                );
            }
            Err(tokio::sync::mpsc::error::TrySendError::Full(packet)) => {
                warn!(
                    target: "n42::cl::mobile",
                    %block_hash,
                    view,
                    reason,
                    "mobile packet channel full, waiting to enqueue"
                );
                if let Err(error) = tx.send(packet).await {
                    warn!(
                        target: "n42::cl::mobile",
                        %block_hash,
                        view,
                        reason,
                        error = %error,
                        "mobile packet enqueue failed after backpressure wait"
                    );
                }
            }
        }
    }

    pub(super) async fn enqueue_tx_import(&self, data: Vec<u8>, reason: &'static str) {
        self.enqueue_tx_import_batch(vec![data], reason).await;
    }

    pub(super) async fn enqueue_tx_import_batch(&self, batch: TxImportBatch, reason: &'static str) {
        let Some(tx) = self.tx_import_tx.as_ref().cloned() else {
            return;
        };

        if batch.is_empty() {
            return;
        }

        match tx.try_send(batch) {
            Ok(()) => {}
            Err(tokio::sync::mpsc::error::TrySendError::Closed(_)) => {
                warn!(target: "n42::cl::tx", reason, "tx import channel closed");
            }
            Err(tokio::sync::mpsc::error::TrySendError::Full(_batch)) => {
                // Drop the batch instead of blocking the consensus loop.
                // Under high load, waiting for the TX import channel to drain
                // causes event starvation and invalid-ancestor cascades.
                warn!(
                    target: "n42::cl::tx",
                    reason,
                    "tx import channel full, dropping batch to avoid blocking consensus loop"
                );
                counter!("n42_tx_import_drops_total").increment(1);
            }
        }
    }

    pub(super) fn pool_depth_snapshot(&self) -> PoolDepthSnapshot {
        self.consensus_state
            .as_ref()
            .map(|state| state.load_pool_depth())
            .unwrap_or_default()
    }

    #[allow(clippy::too_many_arguments)]
    pub fn with_execution_layer(
        engine: ConsensusEngine,
        network: Arc<dyn ConsensusNetwork>,
        consensus_event_rx: mpsc::Receiver<NetworkEvent>,
        net_event_rx: mpsc::Receiver<NetworkEvent>,
        output_rx: mpsc::Receiver<EngineOutput>,
        el: Arc<dyn ExecutionLayer>,
        consensus_state: Arc<SharedConsensusState>,
        head_block_hash: B256,
        head_block_number: u64,
        fee_recipient: Address,
    ) -> Self {
        let (block_ready_tx, block_ready_rx) = mpsc::channel(256);
        let (leader_payload_tx, leader_payload_rx) = mpsc::channel(64);
        let (import_done_tx, import_done_rx) = mpsc::channel(256);
        let (finalize_done_tx, finalize_done_rx) = mpsc::channel(256);
        let (eager_import_done_tx, eager_import_done_rx) = mpsc::channel(256);
        let (commit_execution_timeout_tx, commit_execution_timeout_rx) = mpsc::channel(256);
        let (state_diff_ready_tx, state_diff_ready_rx) = mpsc::channel(256);
        let (build_complete_tx, build_complete_rx) = mpsc::channel(256);

        let slot_time_ms: u64 = std::env::var("N42_BLOCK_INTERVAL_MS")
            .ok()
            .and_then(|s| s.parse().ok())
            .unwrap_or(0);
        let slot_time = Duration::from_millis(slot_time_ms);

        let fast_propose = std::env::var("N42_FAST_PROPOSE")
            .ok()
            .and_then(|v| v.parse::<u64>().ok())
            .unwrap_or(0)
            > 0;
        let async_finalize_fcu = Self::async_finalize_fcu_enabled();
        let h2_v4_catchup_buffer_blocks = h2_v4_catchup_buffer_blocks();

        if slot_time_ms > 0 {
            info!(target: "n42::cl::orchestrator", slot_time_ms, fast_propose, async_finalize_fcu, "slot timing configured");
        }
        if h2_v4_catchup_buffer_blocks != DEFAULT_H2_V4_CATCHUP_BUFFER_BLOCKS {
            info!(
                target: "n42::interop::h2v4",
                h2_v4_catchup_buffer_blocks,
                max = MAX_H2_V4_CATCHUP_BUFFER_BLOCKS,
                "configured authenticated Gov5 catch-up buffer"
            );
        }

        Self {
            engine,
            h2_v4_identity: None,
            h2_v4_block_views: BTreeMap::new(),
            h2_v4_block_view_order: VecDeque::new(),
            h2_v4_block_numbers: BTreeMap::new(),
            h2_v4_unbound_blocks: BTreeMap::new(),
            h2_v4_catchup_blocks: BTreeMap::new(),
            h2_v4_catchup_buffer_blocks,
            h2_v4_last_pruned_head_block_number: None,
            h2_v4_catchup_active: false,
            h2_v4_fetch_failed_peers: BTreeMap::new(),
            h2_v4_fetch_requested_at: HashMap::new(),
            gov5_execution_pull_rounds: 0,
            gov5_execution_pull_last_at: None,
            h2_v4_fetch_fulfilled_at: HashMap::new(),
            network,
            consensus_event_rx: Some(consensus_event_rx),
            net_event_rx,
            output_rx,
            el: Some(el),
            consensus_state: Some(consensus_state),
            head_block_hash,
            head_block_number,
            execution_validated_head_view: 0,
            eager_execution_validated: VecDeque::new(),
            pending_sidecar_diffs: BTreeMap::new(),
            execution_validated_sidecar_hashes: BTreeMap::new(),
            missing_sidecar_diffs: BTreeMap::new(),
            sidecar_apply_queue: Arc::new(std::sync::Mutex::new(VecDeque::new())),
            sidecar_apply_worker_running: Arc::new(std::sync::atomic::AtomicBool::new(false)),
            last_sidecar_applied_view: Arc::new(std::sync::atomic::AtomicU64::new(0)),
            last_commit_qc: None,
            prev_randao_cache: B256::ZERO,
            block_ready_tx,
            block_ready_rx,
            fee_recipient,
            slot_time,
            next_build_at: None,
            next_slot_timestamp: None,
            consecutive_empty_skips: 0,
            pending_block_data: BTreeMap::new(),
            recent_block_data: VecDeque::new(),
            pending_executions: HashSet::new(),
            pending_finalization: None,
            async_commit_states: BTreeMap::new(),
            syncing_blocks: VecDeque::new(),
            bad_blocks: bad_block_cache::BadBlockCache::default(),
            tx_import_tx: None,
            tx_broadcast_rx: None,
            committed_blocks: VecDeque::new(),
            connected_peers: HashSet::new(),
            leader_build_waiting_view: None,
            leader_build_not_before: None,
            sync_in_flight: false,
            sync_started_at: None,
            sync_request_range: None,
            sync_requested_peers: HashSet::new(),
            state_file: None,
            validator_set_for_sync: None,
            epoch_sync_staged_view: None,
            mobile_packet_tx: None,
            leader_payload_rx,
            leader_payload_tx,
            import_done_rx,
            import_done_tx,
            finalize_done_rx,
            finalize_done_tx,
            blob_store: None,
            exec_output_cache: None,
            bg_import_in_flight: false,
            bg_import_hashes: HashSet::new(),
            bg_import_queue: VecDeque::new(),
            eager_import_done_tx,
            eager_import_done_rx,
            commit_execution_timeout_tx,
            commit_execution_timeout_rx,
            state_diff_ready_tx,
            state_diff_ready_rx,
            speculative_build_hash: None,
            building_on_parent: None,
            build_triggered_at: None,
            build_complete_tx,
            build_complete_rx,
            staking_sink: None,
            pending_staking_scans: BTreeMap::new(),
            withdrawal_source: None,
            committed_block_count: 0,
            last_committed_timestamp: 0,
            view_started_at: None,
            epoch_schedule: None,
            tx_forward_buffer: Vec::new(),
            tx_forward_missing_leader_warned_view: None,
            pending_vote_resend: None,
            recent_h2_broadcasts: std::sync::Mutex::new(HashMap::new()),
            leader_disabled: false,
            committee_pool: None,
            pipeline_timings: HashMap::new(),
            last_commit_instant: None,
            last_commit_view: None,
            last_commit_hash: None,
            timeout_view_diags: BTreeMap::new(),
            commit_to_build_recorded_parent: None,
            eager_import_block_guard: Arc::new(std::sync::atomic::AtomicU64::new(0)),
            fast_propose,
            async_finalize_fcu,
            defer_state_root: false,
            jmt: None,
            twig: None,
            zk_scheduler: None,
            allow_deterministic_validator_peers: true,
            admin_rx: None,
            evidence_store: None,
            view_jump_throttle: view_jump_throttle::ViewJumpThrottle::default(),
        }
    }

    pub fn with_exec_output_cache(mut self, cache: Arc<dyn ExecutionOutputCache>) -> Self {
        self.exec_output_cache = Some(cache);
        self
    }

    pub fn with_h2_v4_catchup_buffer_blocks(mut self, blocks: usize) -> Self {
        self.h2_v4_catchup_buffer_blocks = blocks.clamp(
            DEFAULT_H2_V4_CATCHUP_BUFFER_BLOCKS,
            MAX_H2_V4_CATCHUP_BUFFER_BLOCKS,
        );
        self
    }

    /// Enables the complete H2-v4 participant profile: chain-bound POP BLS
    /// signatures in the engine plus bidirectional network conversion.
    pub fn with_h2_v4_participant(
        mut self,
        identity: n42_network::h2_v4::H2V4ChainIdentity,
    ) -> Self {
        self.engine.enable_h2_v4_signing(identity);
        self.h2_v4_identity = Some(identity);
        self
    }

    /// Stamps gov5's committee-evidence root into every payload this node
    /// builds (`parentBeaconRoot = Blake3(parent evidence)`); the execution
    /// side verifies the same link on import.
    pub fn with_committee_pool(mut self, pool: Arc<n42_consensus::SimulatedCommitteePool>) -> Self {
        self.committee_pool = Some(pool);
        self
    }

    /// Keeps the H2 transport of [`Self::with_h2_v4_participant`] but signs
    /// and verifies with gov5's pre-interopV4 domains, for a fleet whose
    /// chainspec does not set `hotstuff.interopV4`.
    pub fn with_gov5_legacy_signing(mut self) -> Self {
        self.engine.enable_gov5_legacy_signing();
        self
    }

    /// Never build a payload as leader (a member without a local QMDB root
    /// cannot seal a gov5 block); its leader views time out like an absent
    /// validator's while it keeps importing and voting.
    pub fn with_leader_disabled(mut self) -> Self {
        self.leader_disabled = true;
        self
    }

    pub fn with_blob_store(mut self, blob_store: Arc<dyn BlobStorePort>) -> Self {
        self.blob_store = Some(blob_store);
        self
    }

    /// Caches the deferred-state-root mode (read from `N42_DEFER_STATE_ROOT` by the
    /// node) so the orchestrator does not call the reth EVM helper directly.
    pub fn with_defer_state_root(mut self, defer: bool) -> Self {
        self.defer_state_root = defer;
        self
    }

    pub fn with_state_persistence(mut self, path: PathBuf) -> Self {
        self.state_file = Some(path);
        self
    }

    pub fn with_validator_set(mut self, vs: ValidatorSet) -> Self {
        self.validator_set_for_sync = Some(vs);
        self
    }

    pub fn with_mobile_packet_tx(mut self, tx: mpsc::Sender<(B256, u64)>) -> Self {
        self.mobile_packet_tx = Some(tx);
        self
    }

    /// Attaches the reward+staking withdrawal source (build-path query). The
    /// node builds the concrete adapter (`NodeWithdrawalSource`) and passes the
    /// trait object so this crate stays free of the reward/staking concretes.
    pub fn with_withdrawal_source(mut self, source: Arc<dyn WithdrawalSource>) -> Self {
        self.withdrawal_source = Some(source);
        self
    }

    /// Attaches the staking scan/persist sink. The node builds the concrete
    /// adapter (`ManagerStakingSink`) and passes the trait object.
    pub fn with_staking_sink(mut self, sink: Arc<dyn StakingSink>) -> Self {
        self.staking_sink = Some(sink);
        self
    }

    /// Restores the committed block count from a persisted snapshot.
    /// Without this, the counter starts at 0 after restart, which can cause
    /// the `MobileRewardManager` to re-trigger epoch boundary rewards.
    pub fn with_committed_block_count(mut self, count: u64) -> Self {
        self.committed_block_count = count;
        self
    }

    /// Attaches an epoch schedule for dynamic validator set rotation.
    ///
    /// When set, the orchestrator consults the schedule at each `EpochTransition`
    /// event and automatically stages the next epoch's validator set.
    pub fn with_jmt(mut self, jmt: Arc<dyn StateSink>) -> Self {
        self.jmt = Some(jmt);
        self
    }

    pub fn with_twig(mut self, twig: Arc<dyn StateSink>) -> Self {
        self.twig = Some(twig);
        self
    }

    /// Attaches a ZK proof scheduler for asynchronous proof generation.
    ///
    /// When set, the orchestrator triggers ZK proof generation after each
    /// committed block (at the configured interval). Proofs are generated
    /// in `spawn_blocking` and never block the consensus path.
    pub fn with_zk_scheduler(mut self, sink: Arc<dyn ZkSink>) -> Self {
        self.zk_scheduler = Some(sink);
        self
    }

    pub fn with_epoch_schedule(mut self, schedule: EpochSchedule) -> Self {
        // The transition handler stages epoch N+1 after entering N, but a
        // freshly started/recovered service has not emitted such an event yet.
        // Pre-stage an exact next-epoch schedule entry here so the first
        // configured rotation is not skipped.
        let next_epoch = self.engine.epoch_manager().current_epoch() + 1;
        if !self.engine.epoch_manager().has_staged_next()
            && let Some((validators, fault_tolerance)) = schedule.get_for_epoch(next_epoch)
        {
            match self
                .engine
                .epoch_manager_mut()
                .stage_next_epoch(validators, fault_tolerance)
            {
                Ok(()) => info!(
                    target: "n42::cl::orchestrator",
                    next_epoch,
                    validator_count = validators.len(),
                    fault_tolerance,
                    "pre-staged next epoch validator set from schedule"
                ),
                Err(error) => warn!(
                    target: "n42::cl::orchestrator",
                    next_epoch,
                    %error,
                    "failed to pre-stage next epoch validator set from schedule"
                ),
            }
        }
        self.epoch_schedule = Some(schedule);
        self
    }

    pub fn with_allow_deterministic_validator_peers(mut self, allow: bool) -> Self {
        self.allow_deterministic_validator_peers = allow;
        self
    }

    /// Restores `prev_randao` derivation state from a recovered CommitQC (crash recovery).
    /// Without this, the first payload after restart would use `B256::ZERO` as `prev_randao`.
    pub fn with_recovered_commit_qc(mut self, qc: QuorumCertificate) -> Self {
        self.prev_randao_cache = alloy_primitives::keccak256(qc.aggregate_signature.to_bytes());
        self.last_commit_qc = Some(qc);
        self
    }

    /// Seed the build timestamp floor from the authenticated execution head.
    /// A restarted fast local chain can be ahead of wall time; retrying from
    /// wall time alone then rejects every leader until the clock catches up.
    pub fn with_recovered_head_timestamp(mut self, timestamp: u64) -> Self {
        self.last_committed_timestamp = self.last_committed_timestamp.max(timestamp);
        self
    }

    /// Restores the execution-validity guard clock from a v4 snapshot (T1).
    ///
    /// The guard (`execution_validated_head_view`) is process-local while the
    /// consensus view stream and reth's canonical head are persistent. Left at
    /// 0 across restart it disables the stale/same-view refusals for the first
    /// confirmation and pins the post-restart catch-up floor at 0 (re-audit
    /// F1/F2). Startup proves the view belongs to the canonical hash before it
    /// calls this builder; `head_block_hash` itself already came directly from
    /// reth and is never replaced from the snapshot.
    pub fn with_recovered_execution_validated_head(mut self, view: u64) -> Self {
        self.execution_validated_head_view = view;
        self
    }

    /// Installs the admin command receiver for RPC-originated validator reconfig requests.
    pub fn with_admin_rx(
        mut self,
        rx: mpsc::Receiver<crate::consensus_state::AdminCommand>,
    ) -> Self {
        self.admin_rx = Some(rx);
        self
    }

    /// Attaches the MDBX-backed evidence store for persisting per-block consensus evidence.
    pub fn with_evidence_store(mut self, store: Arc<n42_jmt::EvidenceStore>) -> Self {
        self.evidence_store = Some(store);
        self
    }

    pub fn with_tx_pool_bridge(
        mut self,
        tx_import_tx: mpsc::Sender<TxImportBatch>,
        tx_broadcast_rx: mpsc::Receiver<Vec<u8>>,
    ) -> Self {
        self.tx_import_tx = Some(tx_import_tx);
        self.tx_broadcast_rx = Some(tx_broadcast_rx);
        self
    }

    /// Runs the orchestrator event loop. Never returns under normal operation.
    pub async fn run(mut self) {
        info!(
            target: "n42::cl::orchestrator",
            version = env!("CARGO_PKG_VERSION"),
            consensus = "HotStuff-2",
            validators = self.engine.validator_count(),
            view = self.engine.current_view(),
            head = %self.head_block_hash,
            "N42 consensus layer initialized"
        );

        self.initialize_startup_schedule().await;

        // Set validator context for Rotor relay forwarding in network layer
        self.network
            .set_validator_context(self.engine.my_index(), self.engine.validator_count())
            .await;

        loop {
            // Bind this Sleep to the view/deadline from which it was created. The
            // event loop recreates and drops the timer after every selected branch;
            // the checks in the timeout branch are defense-in-depth against a stale
            // timer if that structure changes in the future.
            let timeout_view = self.engine.current_view();
            let timeout = self.engine.pacemaker().timeout_sleep();
            tokio::pin!(timeout);

            let next_build_deadline = self.next_build_at;
            let build_timer = async {
                match next_build_deadline {
                    Some(deadline) => tokio::time::sleep_until(deadline).await,
                    None => std::future::pending().await,
                }
            };
            tokio::pin!(build_timer);

            // TX forward flush timer: flush partial batches every 50ms.
            let tx_buf_has_data = !self.tx_forward_buffer.is_empty();
            let tx_flush_timer = async {
                if tx_buf_has_data {
                    tokio::time::sleep(Duration::from_millis(50)).await
                } else {
                    std::future::pending::<()>().await
                }
            };
            tokio::pin!(tx_flush_timer);

            let vote_resend_deadline = self
                .pending_vote_resend
                .as_ref()
                .map(|pending| pending.next_at);
            let vote_resend_timer = async {
                match vote_resend_deadline {
                    Some(deadline) => tokio::time::sleep_until(deadline).await,
                    None => std::future::pending().await,
                }
            };
            tokio::pin!(vote_resend_timer);

            let sync_request_deadline = self
                .sync_started_at
                .map(|started| started + state_mgmt::sync_request_timeout());
            let sync_request_timer = async {
                match sync_request_deadline {
                    Some(deadline) => tokio::time::sleep_until(deadline).await,
                    None => std::future::pending().await,
                }
            };
            tokio::pin!(sync_request_timer);

            let h2_v4_fetch_deadline = self
                .h2_v4_fetch_requested_at
                .values()
                .map(|(requested_at, _)| *requested_at + H2_V4_FETCH_RETRY_TIMEOUT)
                .min();
            let h2_v4_fetch_timer = async {
                match h2_v4_fetch_deadline {
                    Some(deadline) => tokio::time::sleep_until(deadline).await,
                    None => std::future::pending().await,
                }
            };
            tokio::pin!(h2_v4_fetch_timer);

            // Biased select: consensus-critical channels are checked FIRST.
            // Without biased, tokio randomly permutes branch order on each poll,
            // causing consensus votes to compete with high-frequency TX events.
            // Under 20K+ TPS, this random scheduling delays R1_collect by 500-1000ms.
            tokio::select! {
                biased;

                // === Priority 1: Safety-critical ===
                _ = &mut timeout => {
                    let view = self.engine.current_view();
                    if view != timeout_view || !self.engine.pacemaker().is_timed_out() {
                        debug!(target: "n42::cl::orchestrator", timeout_view, current_view = view,
                            "ignoring stale pacemaker timer");
                        continue;
                    }
                    counter!("n42_view_timeouts_total").increment(1);
                    self.record_timeout_diag_timeout_triggered(view);
                    warn!(target: "n42::cl::orchestrator", view, "pacemaker timeout, initiating view change");
                    if let Err(e) = self.engine.on_timeout() {
                        error!(target: "n42::cl::orchestrator", view, error = %e, "error handling timeout");
                    }
                    // Recovery: if we're still the leader after a repeat timeout and
                    // no build is in progress, schedule a build retry.
                    // This handles the case where FCU returned SYNCING earlier and
                    // the leader couldn't propose, causing a permanent stall.
                    if self.engine.is_current_leader()
                        && !self.leader_disabled
                        && self.next_build_at.is_none()
                        && self.speculative_build_hash.is_none()
                    {
                        info!(target: "n42::cl::orchestrator", view, "leader timeout recovery: scheduling build retry");
                        self.schedule_build_retry();
                    }
                }

                // === Priority 2: Consensus engine outputs (Vote broadcast, ViewChanged, Decide) ===
                output = self.output_rx.recv() => {
                    match output {
                        Some(engine_output) => self.handle_engine_output(engine_output).await,
                        None => {
                            info!(target: "n42::cl::orchestrator", "engine output channel closed, shutting down orchestrator");
                            break;
                        }
                    }
                }

                // Keep the current view's locally signed R1/R2 vote alive when
                // a collector's direct or gossip receive path was transiently lost.
                _ = &mut vote_resend_timer => {
                    self.resend_pending_vote();
                }

                // Recovery deadlines are independent of new consensus/network
                // traffic. A quiet stall must still clear and re-drive all
                // request state at its configured deadline.
                _ = &mut sync_request_timer => {
                    self.retry_expired_sync_request();
                }

                _ = &mut h2_v4_fetch_timer => {
                    self.retry_expired_h2_v4_fetches();
                }

                // === Priority 3: Async finalize-FCU completion ===
                finalize_done = async {
                    if self.finalize_done_rx.is_closed() && self.finalize_done_rx.is_empty() {
                        std::future::pending::<Option<FinalizeDone>>().await
                    } else {
                        self.finalize_done_rx.recv().await
                    }
                } => {
                    if let Some((view, block_hash, commit_qc, finalized)) = finalize_done {
                        self.handle_finalize_done(view, block_hash, commit_qc, finalized).await;
                        self.drive_async_commits().await;
                        self.save_consensus_state();
                    }
                }

                commit_execution_timeout = async {
                    if self.commit_execution_timeout_rx.is_closed()
                        && self.commit_execution_timeout_rx.is_empty()
                    {
                        std::future::pending::<Option<CommitExecutionTimeout>>().await
                    } else {
                        self.commit_execution_timeout_rx.recv().await
                    }
                } => {
                    if let Some((view, block_hash)) = commit_execution_timeout {
                        self.handle_commit_execution_timeout(view, block_hash);
                    }
                }

                // === Priority 4: Consensus network events (high-priority, dedicated channel) ===
                // Consensus messages (votes, proposals, QCs) are routed to a separate channel
                // so they are never queued behind high-volume TX/BlockData events.
                event = async {
                    match self.consensus_event_rx.as_mut() {
                        Some(rx) => rx.recv().await,
                        None => std::future::pending().await,
                    }
                } => {
                    match event {
                        Some(ev) => {
                            let mut events = Vec::with_capacity(CONSENSUS_VOTE_BATCH_MAX);
                            events.push(ev);
                            if let Some(rx) = self.consensus_event_rx.as_mut() {
                                while events.len() < CONSENSUS_VOTE_BATCH_MAX {
                                    match rx.try_recv() {
                                        Ok(event) => events.push(event),
                                        Err(_) => break,
                                    }
                                }
                            }
                            self.handle_consensus_event_batch(events).await;
                        }
                        None => {
                            // Consensus channel closed is not fatal — may be observer mode.
                            self.consensus_event_rx = None;
                            debug!(target: "n42::cl::orchestrator", "consensus event channel closed");
                        }
                    }
                }

                // === Priority 5: Block build completion ===
                payload_ready = async {
                    if self.block_ready_rx.is_closed() && self.block_ready_rx.is_empty() {
                        std::future::pending::<Option<PayloadBuildReady>>().await
                    } else {
                        self.block_ready_rx.recv().await
                    }
                } => {
                    if let Some(ready) = payload_ready {
                        self.handle_payload_build_ready(ready);
                    }
                }

                // === Priority 6: Data network events (TX forward, block data, sync, peers) ===
                // Lower priority than consensus — under high TPS these fire thousands of
                // times per second but should never delay vote/proposal processing.
                event = self.net_event_rx.recv() => {
                    match event {
                        Some(ev) => self.handle_network_event(ev).await,
                        None => {
                            info!(target: "n42::cl::orchestrator", "network event channel closed, shutting down orchestrator");
                            break;
                        }
                    }
                }

                // === Priority 7: Import and build lifecycle ===
                import_result = async {
                    if self.import_done_rx.is_closed() && self.import_done_rx.is_empty() {
                        std::future::pending::<Option<ImportDone>>().await
                    } else {
                        self.import_done_rx.recv().await
                    }
                } => {
                    if let Some((hash, view, outcome, block_ts)) = import_result {
                        self.handle_import_done(hash, view, outcome, block_ts).await;
                        self.drive_async_commits().await;
                        // Background import completion can advance the
                        // execution-validity guard after the commit-time
                        // snapshot was written. Persist the exact new pair now.
                        self.save_consensus_state();
                    }
                }

                eager_done = async {
                    if self.eager_import_done_rx.is_closed() && self.eager_import_done_rx.is_empty() {
                        std::future::pending::<Option<EagerImportDone>>().await
                    } else {
                        self.eager_import_done_rx.recv().await
                    }
                } => {
                    if let Some((hash, block_ts, parent_hash, block_number, has_staking_target, state_diff)) = eager_done {
                        // Pipeline: import complete — record timing.
                        if let Some(timing) = self.pipeline_timings.get_mut(&hash) {
                            timing.import_complete = Some(Instant::now());
                        }
                        self.handle_eager_import_done(hash, block_ts, parent_hash, block_number, has_staking_target, state_diff).await;
                        // A late eager completion may close a committed Case C
                        // and advance the guard outside handle_block_committed.
                        self.save_consensus_state();
                    }
                }

                state_diff_ready = async {
                    if self.state_diff_ready_rx.is_closed() && self.state_diff_ready_rx.is_empty() {
                        std::future::pending::<Option<StateDiffReady>>().await
                    } else {
                        self.state_diff_ready_rx.recv().await
                    }
                } => {
                    if let Some((hash, state_diff)) = state_diff_ready {
                        self.handle_state_diff_ready(hash, state_diff);
                    }
                }

                payload_data = async {
                    if self.leader_payload_rx.is_closed() && self.leader_payload_rx.is_empty() {
                        std::future::pending::<Option<(B256, SharedBlockData)>>().await
                    } else {
                        self.leader_payload_rx.recv().await
                    }
                } => {
                    if let Some((hash, data)) = payload_data {
                        self.handle_leader_payload_feedback(hash, data).await;
                    }
                }

                completed_build = async {
                    if self.build_complete_rx.is_closed() && self.build_complete_rx.is_empty() {
                        std::future::pending::<Option<PayloadBuildContext>>().await
                    } else {
                        self.build_complete_rx.recv().await
                    }
                } => {
                    // Payload resolve task finished (success or failure).
                    // A stale task must never clear a newer view's build guard.
                    if let Some(completed) = completed_build {
                        self.handle_payload_build_complete(completed);
                    }
                }

                // === Priority 8: Slot timing ===
                _ = &mut build_timer => {
                    let slot_ts = self.next_slot_timestamp.take();
                    self.next_build_at = None;

                    if slot_ts.is_none() {
                        // Retry or startup delay: verify we're still the leader before building.
                        if !self.engine.is_current_leader() {
                            debug!(target: "n42::cl::orchestrator", "build timer fired but no longer leader, skipping");
                            continue;
                        }
                        let view = self.engine.current_view();
                        if self.speculative_build_hash.is_some() {
                            debug!(target: "n42::cl::orchestrator", view, "build timer fired but speculative build in progress, skipping");
                            continue;
                        }
                        self.arm_leader_build_timer_as_direct_wait(None);
                        // Check if this is a startup recheck or a regular re-check:
                        // on initial view, we still gate strictly on quorum peers before
                        // attempting first proposal.
                        if view <= 1 {
                            self.engine.pacemaker_mut().reset_for_view(view, 0);
                        }
                        if view <= 1 {
                            info!(
                                target: "n42::cl::orchestrator",
                                "leader build timer reached; checking validator peer quorum"
                            );
                        } else {
                            info!(
                                target: "n42::cl::orchestrator",
                                view,
                                "leader build timer reached; re-checking validator peer quorum"
                            );
                        }
                    } else {
                        info!(target: "n42::cl::orchestrator", slot_timestamp = ?slot_ts, "slot boundary reached, triggering payload build");
                        self.arm_leader_build_timer_as_direct_wait(slot_ts);
                    }

                    self.evaluate_leader_build_wait(slot_ts).await;
                }

                // === Priority 9: TX forwarding (lowest priority) ===
                // Under high load, TX events fire thousands of times per second.
                // Deferring them ensures consensus votes are never delayed by TX buffering.
                tx_data = async {
                    match self.tx_broadcast_rx.as_mut() {
                        Some(rx) => rx.recv().await,
                        None => std::future::pending().await,
                    }
                } => {
                    // TX Forward to Leader: instead of GossipSub broadcast, buffer txs
                    // and forward to the current leader in batches.
                    if let Some(data) = tx_data {
                        self.tx_forward_buffer.push(data);
                    }
                    // Batch-drain up to the configured target before forwarding/importing.
                    if let Some(rx) = self.tx_broadcast_rx.as_mut() {
                        for _ in 1..TX_FORWARD_BATCH_TARGET {
                            match rx.try_recv() {
                                Ok(data) => { self.tx_forward_buffer.push(data); }
                                Err(_) => break,
                            }
                        }
                    }
                    // Flush if buffer is large enough.
                    if self.tx_forward_buffer.len() >= TX_FORWARD_BATCH_TARGET {
                        self.flush_tx_forward_buffer().await;
                    }
                }

                _ = &mut tx_flush_timer => {
                    self.flush_tx_forward_buffer().await;
                }

                // === Priority 10: Admin commands (validator reconfig from RPC) ===
                msg = async {
                    match self.admin_rx.as_mut() {
                        Some(rx) => rx.recv().await,
                        None => std::future::pending().await,
                    }
                } => {
                    if let Some(cmd) = msg {
                        self.handle_admin_command(cmd);
                    }
                }

            }

            // Eagerly drain all pending consensus engine outputs after each iteration.
            // The consensus engine can emit multiple outputs per event (e.g., Vote +
            // ViewChanged). Processing them immediately avoids waiting for the next
            // select! iteration, which may be delayed by lower-priority branches.
            while let Ok(engine_output) = self.output_rx.try_recv() {
                self.handle_engine_output(engine_output).await;
            }
            // A child body can arrive while its direct parent is still inside
            // an asynchronous new_payload/FCU. That child is correctly staged,
            // but no later network event is guaranteed after the parent moves
            // the durable execution head. Re-check after every selected
            // lifecycle event so an execution completion itself releases the
            // now-contiguous authenticated suffix.
            self.release_ready_h2_v4_catchup_blocks().await;
        }

        info!(target: "n42::cl::orchestrator", view = self.engine.current_view(), "orchestrator shutting down, persisting final state");
        self.save_shutdown_state();
    }

    async fn initialize_startup_schedule(&mut self) {
        if !self.engine.is_current_leader() || self.el.is_none() {
            return;
        }

        let warmup_delay = Self::leader_propose_warmup_delay();
        let warmup_delay = if self.quorum_peers_needed() == 0 {
            Duration::ZERO
        } else {
            warmup_delay
        };
        self.begin_leader_build_wait(LeaderBuildWaitMode::Direct, None);
        if warmup_delay.is_zero() {
            info!(
                target: "n42::cl::orchestrator",
                validators = self.engine.validator_count(),
                "leader for view 1, attempting immediate proposal after quorum check"
            );
            self.evaluate_leader_build_wait(None).await;
            return;
        }

        info!(
            target: "n42::cl::orchestrator",
            delay_ms = warmup_delay.as_millis() as u64,
            validators = self.engine.validator_count(),
            needed_quorum_peers = self.quorum_peers_needed(),
            "leader for view 1, waiting for validator quorum (warmup floor)"
        );
        self.leader_build_not_before =
            Some((self.engine.current_view(), Instant::now() + warmup_delay));
        self.schedule_leader_build_recheck(warmup_delay);
        self.engine.pacemaker_mut().extend_deadline(warmup_delay);
    }

    /// Records a pipeline timing entry for a block, with bounded map size.
    fn record_pipeline_timing(&mut self, hash: B256, timing: PipelineTiming) {
        const MAX_PIPELINE_ENTRIES: usize = 32;
        if self.pipeline_timings.len() >= MAX_PIPELINE_ENTRIES {
            // Evict oldest entry (smallest `created` timestamp).
            if let Some(oldest) = self
                .pipeline_timings
                .iter()
                .min_by_key(|(_, t)| t.created)
                .map(|(k, _)| *k)
            {
                self.pipeline_timings.remove(&oldest);
            }
        }
        self.pipeline_timings.insert(hash, timing);
    }

    fn handle_admin_command(&mut self, cmd: crate::consensus_state::AdminCommand) {
        use crate::consensus_state::AdminCommand;
        match cmd {
            AdminCommand::AddValidator { info, reply } => {
                let result = self
                    .engine
                    .propose_add_validator(info)
                    .map_err(|e| e.to_string());
                let _ = reply.send(result);
            }
            AdminCommand::RemoveValidator { address, reply } => {
                let result = self
                    .engine
                    .propose_remove_validator(address)
                    .map_err(|e| e.to_string());
                let _ = reply.send(result);
            }
        }
        // Refresh epoch status so RPC immediately reflects pending changes.
        self.refresh_epoch_status();
    }

    /// Publishes the current epoch/pending/staged state to `SharedConsensusState`
    /// so that `n42_validatorSet` RPC returns up-to-date transition info.
    fn refresh_epoch_status(&self) {
        if let Some(ref state) = self.consensus_state {
            let em = self.engine.epoch_manager();
            let next_count = em.peek_next_set().map_or(0, |s| s.len() as usize);
            state.update_epoch_status(crate::consensus_state::EpochStatus {
                current_epoch: em.current_epoch(),
                pending_changes: em.pending_change_count(),
                staged_next_epoch: em.has_staged_next(),
                next_epoch_validator_count: next_count,
            });
        }
    }

    fn trim_tx_forward_buffer(&mut self, leader_idx: u32, reason: &'static str) {
        if self.tx_forward_buffer.len() > 4096 {
            let excess = self.tx_forward_buffer.len() - 2048;
            self.tx_forward_buffer.drain(..excess);
            counter!("n42_tx_forward_dropped").increment(excess as u64);
            warn!(
                target: "n42::cl::orchestrator",
                leader_idx,
                dropped = excess,
                buffer_len = self.tx_forward_buffer.len(),
                reason,
                "dropped oldest txs from forward buffer"
            );
        }
    }

    /// Broadcasts a consensus message using Rotor relay: send directly to relay nodes,
    /// then always broadcast via GossipSub as safety net.
    fn broadcast_via_rotor(&mut self, msg: n42_primitives::ConsensusMessage) {
        if self.h2_v4_identity.is_some() {
            if let Err(error) = self.broadcast_engine_consensus(msg) {
                error!(target: "n42::interop::h2v4", %error, "H2-v4 proposal broadcast failed");
            }
            return;
        }
        use n42_consensus::rotor::cached_relay_assignment;

        let view = self.engine.current_view();
        let validator_count = self.engine.epoch_manager().current_validator_set().len();
        let leader = self.engine.current_leader_index();
        let assignment = cached_relay_assignment(view, validator_count, leader, 3);

        let mut direct_ok = 0u32;
        let mut direct_fail = 0u32;
        for (relay_idx, _targets) in &assignment.relays {
            if let Some(peer_id) = self.network.validator_peer(*relay_idx) {
                // Fire-and-forget: do NOT await relay sends. Blocking the consensus
                // loop on network I/O causes event starvation under 48K+ load.
                match self.network.send_direct(peer_id, msg.clone()) {
                    Ok(()) => direct_ok += 1,
                    Err(e) => {
                        warn!(
                            target: "n42::cl::rotor",
                            relay = relay_idx,
                            error = %e,
                            "rotor: relay direct send failed"
                        );
                        direct_fail += 1;
                    }
                }
            } else {
                direct_fail += 1;
            }
        }

        // Always broadcast via GossipSub as safety net (non-blocking)
        if let Err(e) = self.network.broadcast_consensus(msg) {
            error!(target: "n42::cl::rotor", error = %e, "rotor: gossipsub fallback failed");
        }

        if direct_ok > 0 {
            counter!("n42_rotor_direct_sends").increment(direct_ok as u64);
        }
        if direct_fail > 0 {
            counter!("n42_rotor_fallback_used").increment(direct_fail as u64);
        }
    }

    fn restore_failed_tx_forward_batch(&mut self, txs: Vec<Vec<u8>>, leader_idx: u32) {
        self.tx_forward_buffer = txs;
        self.trim_tx_forward_buffer(leader_idx, "forward send failure");
    }

    fn should_warn_missing_tx_forward_leader(&mut self, view: u64) -> bool {
        if self.tx_forward_missing_leader_warned_view == Some(view) {
            return false;
        }
        self.tx_forward_missing_leader_warned_view = Some(view);
        true
    }

    /// Flush buffered txs to the current leader via the tx_forward protocol.
    async fn flush_tx_forward_buffer(&mut self) {
        if self.tx_forward_buffer.is_empty() {
            return;
        }

        // N42_DISABLE_TX_FORWARD=1: keep txs in local pool only (for sync ingest benchmarks).
        // Txs are still accepted into the local pool but never forwarded to leader.
        static DISABLE_TX_FORWARD: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
        let disabled = *DISABLE_TX_FORWARD.get_or_init(|| {
            std::env::var("N42_DISABLE_TX_FORWARD")
                .map(|v| v == "1")
                .unwrap_or(false)
        });
        if disabled {
            self.tx_forward_missing_leader_warned_view = None;
            // Feed all buffered txs into local pool and return (no forwarding).
            let txs = std::mem::take(&mut self.tx_forward_buffer);
            if self.tx_import_tx.is_some() {
                self.enqueue_tx_import_batch(txs, "tx forward disabled")
                    .await;
            }
            return;
        }

        let leader_idx = self.engine.current_leader_index();
        let validator_peers = self.network.all_validator_peers();

        // If we are the leader, feed txs directly into the local pool.
        if self.engine.is_current_leader() {
            self.tx_forward_missing_leader_warned_view = None;
            let txs = std::mem::take(&mut self.tx_forward_buffer);
            let count = txs.len();
            if self.tx_import_tx.is_some() {
                self.enqueue_tx_import_batch(txs, "leader local tx import")
                    .await;
            }
            counter!("n42_tx_forward_local").increment(count as u64);
            return;
        }

        // Find the leader's PeerId.
        let leader_peer = validator_peers
            .iter()
            .find(|(idx, _)| *idx == leader_idx)
            .map(|(_, pid)| *pid);

        match leader_peer {
            Some(peer) => {
                self.tx_forward_missing_leader_warned_view = None;
                let txs = std::mem::take(&mut self.tx_forward_buffer);
                let count = txs.len();
                debug!(target: "n42::cl::orchestrator", count, leader_idx, %peer, "flushing tx forward buffer to leader");
                match self.network.forward_tx_batch(peer, txs.clone()) {
                    Ok(()) => {
                        counter!("n42_tx_forward_batches").increment(1);
                        counter!("n42_tx_forward_txs").increment(count as u64);
                    }
                    Err(error) => {
                        self.restore_failed_tx_forward_batch(txs, leader_idx);
                        warn!(
                            target: "n42::cl::orchestrator",
                            leader_idx,
                            %peer,
                            count,
                            error = %error,
                            "failed to forward tx batch to leader"
                        );
                    }
                }
            }
            None => {
                // Leader not connected yet — fall back to keeping in buffer.
                // If buffer grows too large, drop oldest to prevent memory bloat.
                let buf_len = self.tx_forward_buffer.len();
                let view = self.engine.current_view();
                if self.should_warn_missing_tx_forward_leader(view) {
                    warn!(target: "n42::cl::orchestrator", view, leader_idx, buf_len, peers = validator_peers.len(), "leader peer not found for tx forward");
                }
                self.trim_tx_forward_buffer(leader_idx, "leader peer not found");
            }
        }
    }

    async fn handle_consensus_event_batch(&mut self, events: Vec<NetworkEvent>) {
        let events = events
            .into_iter()
            .filter_map(|event| match event {
                NetworkEvent::Gov5H2Message { source, message } => {
                    let Some(identity) = self.h2_v4_identity else {
                        return Some(NetworkEvent::Gov5H2Message { source, message });
                    };
                    let envelope = n42_network::h2_v4::H2V4Envelope {
                        identity,
                        changes_hash: B256::ZERO,
                        message: *message,
                    };
                    match n42_network::consensus_from_h2_v4(envelope) {
                        Ok(message) => {
                            counter!(
                                "n42_h2_v4_participant_received_total",
                                "transport" => "gov5"
                            )
                            .increment(1);
                            Some(NetworkEvent::ConsensusMessage {
                                source,
                                message: Box::new(message),
                            })
                        }
                        Err(error) => {
                            counter!(
                                "n42_h2_v4_participant_rejected_total",
                                "reason" => "gov5_conversion"
                            )
                            .increment(1);
                            warn!(target: "n42::interop::h2v4", %source, %error, "rejected canonical Gov5 participant message");
                            None
                        }
                    }
                }
                NetworkEvent::H2V4Message { source, envelope } => {
                    let Some(identity) = self.h2_v4_identity else {
                        return Some(NetworkEvent::H2V4Message { source, envelope });
                    };
                    if envelope.identity != identity {
                        counter!("n42_h2_v4_participant_rejected_total", "reason" => "identity")
                            .increment(1);
                        return None;
                    }
                    match n42_network::consensus_from_h2_v4(*envelope) {
                        Ok(message) => {
                            counter!("n42_h2_v4_participant_received_total").increment(1);
                            Some(NetworkEvent::ConsensusMessage {
                                source,
                                message: Box::new(message),
                            })
                        }
                        Err(error) => {
                            counter!("n42_h2_v4_participant_rejected_total", "reason" => "conversion")
                                .increment(1);
                            warn!(target: "n42::interop::h2v4", %source, %error, "rejected H2-v4 participant message");
                            None
                        }
                    }
                }
                other => Some(other),
            })
            .collect::<Vec<_>>();
        if events.is_empty() {
            return;
        }
        let current_view = self.engine.current_view();
        let mut positions = Vec::new();
        let mut messages = Vec::new();
        for (position, event) in events.iter().enumerate() {
            let NetworkEvent::ConsensusMessage { message, .. } = event else {
                continue;
            };
            let eligible = matches!(
                message.as_ref(),
                n42_primitives::ConsensusMessage::Vote(vote) if vote.view == current_view
            ) || matches!(
                message.as_ref(),
                n42_primitives::ConsensusMessage::CommitVote(vote) if vote.view == current_view
            );
            if eligible {
                positions.push(position);
                messages.push(message.as_ref().clone());
            }
        }

        if messages.len() < 2 {
            for event in events {
                self.handle_network_event(event).await;
            }
            self.drain_h2_v4_bound_blocks().await;
            return;
        }

        let verify_started = std::time::Instant::now();
        let authenticated = self.engine.authenticate_vote_batch(messages);
        histogram!("n42_consensus_vote_batch_size").record(authenticated.len() as f64);
        histogram!("n42_consensus_vote_batch_verify_ms")
            .record(verify_started.elapsed().as_secs_f64() * 1000.0);

        let mut hints: Vec<Option<Option<AuthenticatedConsensusMessage>>> =
            (0..events.len()).map(|_| None).collect();
        for (position, authenticated) in positions.into_iter().zip(authenticated) {
            hints[position] = Some(authenticated);
        }

        for (event, hint) in events.into_iter().zip(hints) {
            self.handle_network_event_with_auth(event, hint).await;
        }
        self.drain_h2_v4_bound_blocks().await;
    }

    async fn handle_network_event(&mut self, event: NetworkEvent) {
        self.handle_network_event_with_auth(event, None).await;
    }

    async fn handle_network_event_with_auth(
        &mut self,
        event: NetworkEvent,
        preauthenticated: Option<Option<AuthenticatedConsensusMessage>>,
    ) {
        match event {
            NetworkEvent::ConsensusMessage { source, message } => {
                counter!("n42_consensus_messages_received").increment(1);
                use n42_primitives::ConsensusMessage as CM;
                let msg_type = match message.as_ref() {
                    CM::Proposal(_) => "Proposal",
                    CM::Vote(_) => "Vote",
                    CM::CommitVote(_) => "CommitVote",
                    CM::Timeout(_) => "Timeout",
                    CM::NewView(_) => "NewView",
                    CM::Decide(_) => "Decide",
                    _ => "Other",
                };

                // Rate-limit messages that would force the engine into the BLS-heavy
                // QC view-jump path. We bypass Decide / NewView (they own their view
                // logic and are cheaper to verify) and Timeout within the buffer
                // window. Anything else more than FUTURE_VIEW_WINDOW ahead must
                // consume a token from this peer's bucket or be dropped.
                let needs_view_jump = !matches!(message.as_ref(), CM::Decide(_) | CM::NewView(_))
                    && message.view()
                        > self
                            .engine
                            .current_view()
                            .saturating_add(FUTURE_VIEW_WINDOW);
                if needs_view_jump && !self.view_jump_throttle.try_consume(source) {
                    counter!("n42_view_jump_throttled_total").increment(1);
                    debug!(
                        target: "n42::cl::orchestrator",
                        %source,
                        msg_type,
                        msg_view = message.view(),
                        current_view = self.engine.current_view(),
                        "view-jump message rate-limited"
                    );
                    return;
                }

                let authenticated = match preauthenticated {
                    Some(Some(authenticated)) => Some(authenticated),
                    // CommitVote's signature domain includes proposal-derived
                    // validator_changes_hash. Batch verification happens before
                    // earlier events in this drain are dispatched, so a failed
                    // precheck can become valid after an earlier Proposal fills
                    // the cache. Re-run the canonical individual check in that
                    // case; Vote has no mutable domain and can be dropped here.
                    Some(None) if matches!(message.as_ref(), CM::CommitVote(_)) => {
                        counter!("n42_consensus_commit_vote_batch_domain_fallback_total")
                            .increment(1);
                        None
                    }
                    Some(None) => {
                        counter!("n42_consensus_vote_batch_invalid_total").increment(1);
                        debug!(
                            target: "n42::cl::orchestrator",
                            %source,
                            msg_type,
                            "dropping vote rejected by batch signature verification"
                        );
                        return;
                    }
                    None => None,
                };
                let validator_index = authenticated
                    .as_ref()
                    .map(AuthenticatedConsensusMessage::signer)
                    .or_else(|| self.engine.authenticated_signer(message.as_ref()));
                if let Some(validator_index) = validator_index
                    && let Err(error) = self
                        .network
                        .authenticate_validator_peer_reliable(source, validator_index)
                        .await
                {
                    debug!(
                        target: "n42::cl::orchestrator",
                        %source,
                        validator_index,
                        error = %error,
                        "failed to promote authenticated validator peer"
                    );
                }
                // Save the message view before process_event consumes it via *message.
                let msg_view = message.view();
                // A body hash becomes eligible for execution only after the H2
                // state machine has authenticated and accepted the corresponding
                // message. Merely decoding a chain-bound envelope is not
                // authentication: any connected peer can publish one.
                //
                // Bind every QC-carried block as well as a Proposal/Decide's own
                // block. A recovering node can legitimately receive only a
                // far-future Timeout/NewView/PrepareQC first; the verified QC in
                // that message is then its only authenticated ancestry anchor.
                let h2_block_bindings = self.h2_v4_identity.map(|_| {
                    fn bind_qc(
                        bindings: &mut Vec<(alloy_primitives::B256, u64)>,
                        qc: &n42_primitives::QuorumCertificate,
                    ) {
                        if qc.view > 0 && qc.block_hash != alloy_primitives::B256::ZERO {
                            bindings.push((qc.block_hash, qc.view));
                        }
                    }

                    let mut bindings = Vec::with_capacity(3);
                    match message.as_ref() {
                        CM::Proposal(value) => {
                            if validator_index == Some(value.proposer) {
                                bindings.push((value.block_hash, value.view));
                            }
                            bind_qc(&mut bindings, &value.justify_qc);
                            if let Some(qc) = value.prepare_qc.as_ref() {
                                bind_qc(&mut bindings, qc);
                            }
                        }
                        CM::PrepareQC(value) => {
                            bindings.push((value.block_hash, value.view));
                            bind_qc(&mut bindings, &value.qc);
                        }
                        CM::Timeout(value) => bind_qc(&mut bindings, &value.high_qc),
                        CM::NewView(value) => {
                            bind_qc(&mut bindings, &value.timeout_cert.high_qc);
                        }
                        CM::Decide(value) => {
                            bindings.push((value.block_hash, value.view));
                            bind_qc(&mut bindings, &value.commit_qc);
                        }
                        CM::Vote(_) | CM::CommitVote(_) => {}
                    }
                    bindings.sort_unstable();
                    bindings.dedup();
                    bindings
                });
                debug!(target: "n42::cl::orchestrator", msg_type, view = self.engine.current_view(), "processing consensus message");
                let result = match authenticated {
                    Some(authenticated) => self.engine.process_authenticated_message(authenticated),
                    None => self
                        .engine
                        .process_event(n42_consensus::ConsensusEvent::Message(*message)),
                };
                match result {
                    Ok(()) => {
                        for (block_hash, view) in h2_block_bindings.into_iter().flatten() {
                            self.remember_h2_v4_block_view(block_hash, view);
                            if !self.pending_block_data.contains_key(&block_hash)
                                && !self.h2_v4_unbound_blocks.contains_key(&block_hash)
                            {
                                self.request_h2_v4_gov5_block(source, block_hash);
                            }
                        }
                        // Release a body as soon as its authenticating message is
                        // accepted, before later Proposal/QC/Decide events in the
                        // same drained batch can commit descendants ahead of it.
                        self.drain_h2_v4_bound_blocks().await;
                    }
                    Err(e) => {
                        if matches!(e, n42_consensus::N42ConsensusError::SafetyViolation { .. }) {
                            debug!(target: "n42::cl::orchestrator", error = %e, "benign safety check (QC ordering race)");
                        } else {
                            warn!(target: "n42::cl::orchestrator", error = %e, "error processing consensus message");
                            // Bitmap length mismatch means the peer used a different epoch's
                            // validator set to sign the QC/TC — our epoch state has diverged.
                            // Trigger sync so we can recover the missing epoch transition.
                            let is_bitmap_mismatch = matches!(
                                &e,
                                n42_consensus::N42ConsensusError::InvalidQC { reason, .. }
                                    if reason.contains("bitmap length mismatch")
                            ) || matches!(
                                &e,
                                n42_consensus::N42ConsensusError::InvalidTC { reason, .. }
                                    if reason.contains("bitmap length mismatch")
                            );
                            if is_bitmap_mismatch {
                                let local_view = self.engine.current_view();
                                warn!(
                                    target: "n42::cl::orchestrator",
                                    current_view = local_view,
                                    msg_view,
                                    "epoch state divergence detected (bitmap mismatch) — triggering sync"
                                );
                                // Sync from two epochs back up to the message's view so we
                                // capture the validator-change block that caused the mismatch.
                                // Using msg_view (not local_view) as the target is critical:
                                // when local_view=0 and msg_view=45, initiate_sync(0,0) would
                                // produce an invalid from_view=1 > to_view=0 request that the
                                // peer rejects silently, leaving the node permanently stuck.
                                let epoch_len = self.engine.epoch_manager().epoch_length().max(1);
                                let from = local_view.saturating_sub(epoch_len * 2);
                                let target = msg_view.max(local_view);
                                self.initiate_sync(from, target);
                            }
                        }
                    }
                }
            }
            NetworkEvent::PeerConnected(peer_id) => {
                info!(target: "n42::cl::orchestrator", %peer_id, "consensus peer connected");
                self.connected_peers.insert(peer_id);
                gauge!("n42_connected_peers").set(self.connected_peers.len() as f64);

                // A restart can recover a far-newer locked/commit QC while its
                // execution head is intentionally still behind. No fresh
                // Proposal/Decide is guaranteed to arrive immediately (the
                // recovering validator may itself be the current leader), so
                // seed authenticated ancestry fetches directly from the
                // persisted certificates as soon as a Gov5 peer is available.
                if self.h2_v4_identity.is_some() {
                    let recovery_anchors = [
                        self.engine.locked_qc().clone(),
                        self.engine.last_committed_qc().clone(),
                    ];
                    for qc in recovery_anchors {
                        if qc.view == 0
                            || qc.block_hash == B256::ZERO
                            || qc.block_hash == self.head_block_hash
                        {
                            continue;
                        }
                        self.remember_h2_v4_block_view(qc.block_hash, qc.view);
                        self.request_h2_v4_gov5_block(peer_id, qc.block_hash);
                    }
                }

                if self.pending_leader_build_mode_for_current_view().is_some() {
                    let slot_timestamp = self.next_slot_timestamp;
                    self.evaluate_leader_build_wait(slot_timestamp).await;
                }
            }
            NetworkEvent::PeerDisconnected(peer_id) => {
                warn!(target: "n42::cl::orchestrator", %peer_id, "consensus peer disconnected");
                self.connected_peers.remove(&peer_id);
                self.view_jump_throttle.forget(&peer_id);
                gauge!("n42_connected_peers").set(self.connected_peers.len() as f64);

                if self.pending_leader_build_mode_for_current_view().is_some() {
                    self.schedule_leader_build_recheck(Self::leader_quorum_recheck_delay());
                }
            }
            NetworkEvent::BlockAnnouncement { source, data } => {
                tracing::debug!(target: "n42::cl::orchestrator", %source, bytes = data.len(), "received block data broadcast");
                self.handle_block_data(data).await;
            }
            NetworkEvent::Gov5Block { source, rlp } if self.h2_v4_identity.is_some() => {
                self.handle_h2_v4_gov5_block(source, rlp, None).await;
            }
            NetworkEvent::Gov5BlockFetched {
                source,
                requested_hash,
                rlp,
            } if self.h2_v4_identity.is_some() => {
                self.handle_h2_v4_gov5_block(source, rlp, Some(requested_hash))
                    .await;
            }
            NetworkEvent::Gov5BlockFetchFailed {
                source,
                block_hash,
                error,
                permanent,
            } if self.h2_v4_identity.is_some() => {
                self.h2_v4_fetch_requested_at.remove(&block_hash);
                if permanent {
                    // A verdict about content the hash commits to: every peer
                    // would serve bytes that decode the same way, so rotating
                    // the fan-out only repeats it.
                    warn!(
                        target: "n42::interop::h2v4",
                        %source,
                        %block_hash,
                        %error,
                        "gov5 block rejected on content; retiring the fetch"
                    );
                    counter!("n42_gov5_block_rejected_permanent_total").increment(1);
                    self.h2_v4_fetch_failed_peers.remove(&block_hash);
                    self.remember_h2_v4_fetch_fulfilled(block_hash, Instant::now());
                    return;
                }
                warn!(target: "n42::interop::h2v4", %source, %block_hash, %error, "H2-authenticated gov5 block fetch failed");
                let now = Instant::now();
                let attempted = {
                    let entry = self
                        .h2_v4_fetch_failed_peers
                        .entry(block_hash)
                        .or_insert_with(|| (now, HashSet::new()));
                    if now.duration_since(entry.0) >= H2_V4_FETCH_RETRY_ROUND {
                        entry.0 = now;
                        entry.1.clear();
                    }
                    entry.1.insert(source);
                    entry.1.clone()
                };
                while self.h2_v4_fetch_failed_peers.len() > 2048 {
                    self.h2_v4_fetch_failed_peers.pop_first();
                }
                let mut retry_peer = self
                    .connected_peers
                    .iter()
                    .copied()
                    .find(|peer| !attempted.contains(peer));
                if retry_peer.is_none() {
                    if let Some(entry) = self.h2_v4_fetch_failed_peers.get_mut(&block_hash) {
                        entry.0 = now;
                        entry.1.clear();
                    }
                    retry_peer = self.connected_peers.iter().copied().next();
                }
                if let Some(retry_peer) = retry_peer {
                    counter!("n42_h2_v4_block_fetch_retries_total").increment(1);
                    debug!(
                        target: "n42::interop::h2v4",
                        failed_peer = %source,
                        %retry_peer,
                        %block_hash,
                        attempted = attempted.len(),
                        "retrying authenticated Gov5 block fetch with another peer"
                    );
                    self.request_h2_v4_gov5_block(retry_peer, block_hash);
                } else {
                    warn!(
                        target: "n42::interop::h2v4",
                        %block_hash,
                        attempted = attempted.len(),
                        "authenticated Gov5 block fetch exhausted connected peers for this retry round"
                    );
                }
            }
            NetworkEvent::TransactionReceived { source: _, data } => {
                self.enqueue_tx_import(data, "p2p transaction received")
                    .await;
            }
            NetworkEvent::TxForwardReceived { source: _, txs } => {
                // Leader receives forwarded txs from validators — feed into local pool.
                let count = txs.len();
                self.enqueue_tx_import_batch(txs, "validator tx forward received")
                    .await;
                counter!("n42_tx_forward_imported").increment(count as u64);
            }
            NetworkEvent::TxForwardCreditUpdate { .. } => {
                // Reserved for future credit-based flow control.
            }
            NetworkEvent::SyncRequest {
                peer,
                request_id,
                request,
            } => {
                self.handle_sync_request(peer, request_id, request).await;
            }
            NetworkEvent::SyncResponse { peer, response } => {
                self.handle_sync_response(peer, response).await;
            }
            NetworkEvent::SyncRequestFailed {
                peer,
                error,
                unsupported_protocol,
            } => {
                if unsupported_protocol {
                    warn!(target: "n42::cl::orchestrator", %peer, %error, "peer does not speak N42 state-sync");
                } else {
                    warn!(target: "n42::cl::orchestrator", %peer, %error, "sync request failed");
                }
                if self.sync_requested_peers.remove(&peer) && self.sync_requested_peers.is_empty() {
                    self.sync_in_flight = false;
                    self.sync_started_at = None;
                    self.sync_request_range = None;
                }
            }
            NetworkEvent::BlobSidecarReceived { source: _, data } => {
                self.handle_blob_sidecar(data);
            }
            _ => {
                // Verification receipts are handled by dedicated subsystems.
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use alloy_consensus::{
        Block, BlockBody, Header, TxEnvelope, proofs::calculate_transaction_root,
    };
    use alloy_primitives::{Address, B256, Bloom, Bytes, U256};
    use alloy_rpc_types_engine::{
        ExecutionData, ExecutionPayload, ExecutionPayloadSidecar, ExecutionPayloadV1,
        ForkchoiceState, ForkchoiceUpdated, PayloadAttributes, PayloadId, PayloadStatus,
        PayloadStatusEnum,
    };
    use libp2p::identity::Keypair;
    use metrics_util::debugging::{DebugValue, DebuggingRecorder};
    use n42_chainspec::ValidatorInfo;
    use n42_consensus::{ConsensusEngine, EpochManager, ValidatorSet};
    use n42_network::{NetworkCommand, NetworkHandle};
    use n42_primitives::consensus::ValidatorChange;
    use n42_primitives::{
        BlsSecretKey, ConsensusMessage, Proposal, QuorumCertificate, TimeoutMessage, Vote,
    };
    use std::collections::{HashMap, HashSet};
    use std::sync::{Arc, Mutex, RwLock};
    use std::time::Duration;

    fn test_gov5_block_rlp(parent_hash: B256, number: u64, view: u64) -> (B256, Vec<u8>) {
        let mut extra_data = Vec::with_capacity(12);
        extra_data.extend_from_slice(b"N42H");
        extra_data.extend_from_slice(&view.to_le_bytes());
        let block = Block::<TxEnvelope> {
            header: Header {
                parent_hash,
                ommers_hash: B256::ZERO,
                transactions_root: calculate_transaction_root::<TxEnvelope>(&[]),
                number,
                base_fee_per_gas: Some(0),
                extra_data: extra_data.into(),
                ..Default::default()
            },
            body: BlockBody::default(),
        };
        let block_hash = block.header.hash_slow();
        let execution = ExecutionData::from_block_unchecked(block_hash, &block);
        let rlp =
            n42_network::encode_gov5_block_rlp(&execution).expect("test Gov5 block must encode");
        (block_hash, rlp)
    }

    #[derive(Clone, Default)]
    struct MockConsensusNetwork {
        peers: Arc<RwLock<HashMap<u32, n42_network::PeerId>>>,
        broadcasts: Arc<Mutex<Vec<n42_primitives::ConsensusMessage>>>,
        h2_v4_broadcasts: Arc<Mutex<Vec<n42_network::h2_v4::H2V4Envelope>>>,
        direct_messages: Arc<Mutex<Vec<(n42_network::PeerId, n42_primitives::ConsensusMessage)>>>,
        cancelled_gov5_fetches: Arc<Mutex<Vec<B256>>>,
    }

    impl MockConsensusNetwork {
        fn with_peers(peers: Vec<(u32, n42_network::PeerId)>) -> Self {
            let peer_map = peers.into_iter().collect::<HashMap<_, _>>();
            Self {
                peers: Arc::new(RwLock::new(peer_map)),
                ..Self::default()
            }
        }

        fn broadcasts(&self) -> Vec<n42_primitives::ConsensusMessage> {
            self.broadcasts
                .lock()
                .expect("mock broadcasts lock")
                .clone()
        }

        fn direct_messages(&self) -> Vec<(n42_network::PeerId, n42_primitives::ConsensusMessage)> {
            self.direct_messages
                .lock()
                .expect("mock direct messages lock")
                .clone()
        }

        fn h2_v4_broadcasts(&self) -> Vec<n42_network::h2_v4::H2V4Envelope> {
            self.h2_v4_broadcasts
                .lock()
                .expect("mock H2-v4 broadcasts lock")
                .clone()
        }
    }

    #[derive(Clone)]
    struct MockExecutionLayer {
        new_payload_statuses: Arc<Mutex<VecDeque<PayloadStatusEnum>>>,
        fcu_statuses: Arc<Mutex<VecDeque<PayloadStatusEnum>>>,
        build_parents: Arc<Mutex<Vec<B256>>>,
        build_forkchoices: Arc<Mutex<Vec<(B256, B256, B256)>>>,
        /// Every attribute-less forkchoiceUpdated head - the canonical-writer
        /// audit trail (import paths must NEVER appear here).
        fcu_heads: Arc<Mutex<Vec<B256>>>,
        /// Every new_payload block hash.
        new_payload_hashes: Arc<Mutex<Vec<B256>>>,
    }

    impl MockExecutionLayer {
        fn new(new_payload_status: PayloadStatusEnum, fcu_status: PayloadStatusEnum) -> Self {
            Self {
                new_payload_statuses: Arc::new(Mutex::new(VecDeque::from([new_payload_status]))),
                fcu_statuses: Arc::new(Mutex::new(VecDeque::from([fcu_status]))),
                build_parents: Arc::new(Mutex::new(Vec::new())),
                build_forkchoices: Arc::new(Mutex::new(Vec::new())),
                fcu_heads: Arc::new(Mutex::new(Vec::new())),
                new_payload_hashes: Arc::new(Mutex::new(Vec::new())),
            }
        }

        fn with_fcu_statuses(
            new_payload_status: PayloadStatusEnum,
            fcu_statuses: impl IntoIterator<Item = PayloadStatusEnum>,
        ) -> Self {
            let fcu_statuses = fcu_statuses.into_iter().collect::<VecDeque<_>>();
            assert!(
                !fcu_statuses.is_empty(),
                "at least one FCU status is required"
            );
            Self {
                new_payload_statuses: Arc::new(Mutex::new(VecDeque::from([new_payload_status]))),
                fcu_statuses: Arc::new(Mutex::new(fcu_statuses)),
                build_parents: Arc::new(Mutex::new(Vec::new())),
                build_forkchoices: Arc::new(Mutex::new(Vec::new())),
                fcu_heads: Arc::new(Mutex::new(Vec::new())),
                new_payload_hashes: Arc::new(Mutex::new(Vec::new())),
            }
        }

        fn with_new_payload_statuses(
            new_payload_statuses: impl IntoIterator<Item = PayloadStatusEnum>,
            fcu_status: PayloadStatusEnum,
        ) -> Self {
            let new_payload_statuses = new_payload_statuses.into_iter().collect::<VecDeque<_>>();
            assert!(
                !new_payload_statuses.is_empty(),
                "at least one new-payload status is required"
            );
            Self {
                new_payload_statuses: Arc::new(Mutex::new(new_payload_statuses)),
                fcu_statuses: Arc::new(Mutex::new(VecDeque::from([fcu_status]))),
                build_parents: Arc::new(Mutex::new(Vec::new())),
                build_forkchoices: Arc::new(Mutex::new(Vec::new())),
                fcu_heads: Arc::new(Mutex::new(Vec::new())),
                new_payload_hashes: Arc::new(Mutex::new(Vec::new())),
            }
        }

        fn fcu_heads(&self) -> Vec<B256> {
            self.fcu_heads
                .lock()
                .expect("mock execution-layer lock")
                .clone()
        }

        fn new_payload_hashes(&self) -> Vec<B256> {
            self.new_payload_hashes
                .lock()
                .expect("mock execution-layer lock")
                .clone()
        }

        fn build_parents(&self) -> Vec<B256> {
            self.build_parents
                .lock()
                .expect("mock execution-layer lock")
                .clone()
        }

        fn build_forkchoices(&self) -> Vec<(B256, B256, B256)> {
            self.build_forkchoices
                .lock()
                .expect("mock execution-layer lock")
                .clone()
        }
    }

    #[async_trait::async_trait]
    impl ExecutionLayer for MockExecutionLayer {
        async fn new_payload(
            &self,
            payload: ExecutionData,
        ) -> Result<PayloadStatus, crate::el::ElError> {
            self.new_payload_hashes
                .lock()
                .expect("mock execution-layer lock")
                .push(payload.payload.block_hash());
            let mut statuses = self
                .new_payload_statuses
                .lock()
                .expect("mock execution-layer lock");
            let status = if statuses.len() > 1 {
                statuses.pop_front().expect("non-empty status queue")
            } else {
                statuses.front().expect("non-empty status queue").clone()
            };
            Ok(PayloadStatus::from_status(status))
        }

        async fn fork_choice_updated(
            &self,
            state: ForkchoiceState,
        ) -> Result<ForkchoiceUpdated, crate::el::ElError> {
            self.fcu_heads
                .lock()
                .expect("mock execution-layer lock")
                .push(state.head_block_hash);
            let mut statuses = self.fcu_statuses.lock().expect("mock execution-layer lock");
            let status = if statuses.len() > 1 {
                statuses.pop_front().expect("non-empty FCU status queue")
            } else {
                statuses
                    .front()
                    .expect("non-empty FCU status queue")
                    .clone()
            };
            Ok(ForkchoiceUpdated::from_status(status))
        }

        async fn fork_choice_updated_with_attrs(
            &self,
            state: ForkchoiceState,
            _attrs: PayloadAttributes,
        ) -> Result<ForkchoiceUpdated, crate::el::ElError> {
            self.build_forkchoices
                .lock()
                .expect("mock execution-layer lock")
                .push((
                    state.head_block_hash,
                    state.safe_block_hash,
                    state.finalized_block_hash,
                ));
            self.build_parents
                .lock()
                .expect("mock execution-layer lock")
                .push(state.head_block_hash);
            Ok(ForkchoiceUpdated::from_status(PayloadStatusEnum::Valid))
        }

        async fn resolve_payload(
            &self,
            _id: PayloadId,
            _kind: crate::el::ResolveKind,
        ) -> Option<Result<crate::el::BuiltBlock, crate::el::ElError>> {
            None
        }
    }

    #[derive(Default)]
    struct MockExecutionOutputCache {
        active: Mutex<HashSet<B256>>,
        injected: Mutex<Vec<B256>>,
        evicted: Mutex<Vec<B256>>,
    }

    impl MockExecutionOutputCache {
        fn contains(&self, hash: B256) -> bool {
            self.active.lock().expect("mock cache lock").contains(&hash)
        }

        fn evicted(&self) -> Vec<B256> {
            self.evicted.lock().expect("mock cache lock").clone()
        }
    }

    impl crate::exec_cache::ExecutionOutputCache for MockExecutionOutputCache {
        fn take_serialized(&self, _hash: B256) -> Option<Vec<u8>> {
            None
        }

        fn inject(&self, hash: B256, _compressed: &[u8], _source: &'static str) -> bool {
            self.active.lock().expect("mock cache lock").insert(hash);
            self.injected.lock().expect("mock cache lock").push(hash);
            true
        }

        fn evict(&self, hash: B256) {
            self.active.lock().expect("mock cache lock").remove(&hash);
            self.evicted.lock().expect("mock cache lock").push(hash);
        }
    }

    fn test_execution_data_at_number(
        parent_hash: B256,
        block_hash: B256,
        block_number: u64,
    ) -> ExecutionData {
        ExecutionData::new(
            ExecutionPayload::V1(ExecutionPayloadV1 {
                parent_hash,
                fee_recipient: Address::ZERO,
                state_root: B256::ZERO,
                receipts_root: B256::ZERO,
                logs_bloom: Bloom::ZERO,
                prev_randao: B256::ZERO,
                block_number,
                gas_limit: 30_000_000,
                gas_used: 0,
                timestamp: 1,
                extra_data: Bytes::new(),
                base_fee_per_gas: U256::from(1),
                block_hash,
                transactions: Vec::new(),
            }),
            ExecutionPayloadSidecar::none(),
        )
    }

    fn test_execution_data(parent_hash: B256, block_hash: B256) -> ExecutionData {
        test_execution_data_at_number(parent_hash, block_hash, 1)
    }

    #[test]
    fn binary_execution_payload_round_trips_raw_transactions() {
        let mut execution = test_execution_data(B256::repeat_byte(0x11), B256::repeat_byte(0x22));
        execution
            .payload
            .transactions_mut()
            .extend([Bytes::from(vec![0xab; 119]), Bytes::from(vec![0xcd; 257])]);
        let legacy_json = serde_json::to_vec(&execution).expect("serialize legacy JSON payload");

        let encoded = encode_execution_payload(&mut execution).expect("encode binary payload");
        assert_eq!(encoded.format, "binary-v1");
        assert!(encoded.bytes.len() < legacy_json.len());
        assert_eq!(execution.payload.transactions().len(), 2);
        assert_eq!(encoded.transaction_bytes, 376);

        let decoded = decode_execution_payload(&encoded.bytes).expect("decode binary payload");
        assert_eq!(
            serde_json::to_vec(&decoded).expect("serialize decoded payload"),
            legacy_json
        );
    }

    #[test]
    fn owned_binary_decoder_slices_the_received_allocation() {
        let mut execution = test_execution_data(B256::repeat_byte(0x23), B256::repeat_byte(0x45));
        execution
            .payload
            .transactions_mut()
            .extend([Bytes::from(vec![0xab; 119]), Bytes::from(vec![0xcd; 257])]);
        let encoded = encode_execution_payload(&mut execution).expect("encode binary payload");
        let allocation_start = encoded.bytes.as_ptr() as usize;
        let allocation_end = allocation_start + encoded.bytes.len();

        let decoded =
            decode_execution_payload_owned(encoded.bytes).expect("decode owned binary payload");
        assert_eq!(
            decoded.payload.transactions(),
            execution.payload.transactions()
        );
        for transaction in decoded.payload.transactions() {
            let transaction_start = transaction.as_ptr() as usize;
            let transaction_end = transaction_start + transaction.len();
            assert!(transaction_start >= allocation_start);
            assert!(transaction_end <= allocation_end);
        }
    }

    #[test]
    fn execution_payload_decoder_accepts_legacy_json() {
        let execution = test_execution_data(B256::repeat_byte(0x33), B256::repeat_byte(0x44));
        let legacy_json = serde_json::to_vec(&execution).expect("serialize legacy JSON payload");

        let decoded = decode_execution_payload(&legacy_json).expect("decode legacy JSON payload");
        assert_eq!(decoded.block_hash(), execution.block_hash());
        assert_eq!(decoded.parent_hash(), execution.parent_hash());
    }

    #[test]
    fn binary_execution_payload_rejects_truncation_and_trailing_bytes() {
        let mut execution = test_execution_data(B256::repeat_byte(0x55), B256::repeat_byte(0x66));
        execution
            .payload
            .transactions_mut()
            .push(Bytes::from(vec![0xef; 32]));
        let encoded = encode_execution_payload(&mut execution).expect("encode binary payload");

        assert!(decode_execution_payload(&encoded.bytes[..encoded.bytes.len() - 1]).is_err());
        let mut trailing = encoded.bytes;
        trailing.push(0);
        assert!(decode_execution_payload(&trailing).is_err());
    }

    #[test]
    fn staking_target_prefilter_scans_raw_transaction_bytes() {
        let mut execution = test_execution_data(B256::repeat_byte(0x77), B256::repeat_byte(0x88));
        execution
            .payload
            .transactions_mut()
            .push(Bytes::from(vec![0; 64]));
        assert!(!execution_might_contain_staking_target(&execution));

        let mut staking_transaction = vec![0xaa; 7];
        staking_transaction.extend_from_slice(&STAKING_TARGET_RLP);
        staking_transaction.extend_from_slice(&[0xbb; 9]);
        execution.payload.transactions_mut()[0] = Bytes::from(staking_transaction);
        assert!(execution_might_contain_staking_target(&execution));
    }

    fn test_block_data(parent_hash: B256, block_hash: B256, view: u64) -> Vec<u8> {
        let payload_json = serde_json::to_vec(&test_execution_data(parent_hash, block_hash))
            .expect("serialize test execution data");
        bincode::serialize(&BlockDataBroadcast {
            block_hash,
            view,
            payload_json,
            timestamp: 1,
            execution_output: None,
            leader_ready_unix_ms: 0,
        })
        .expect("serialize test block broadcast")
    }

    fn test_block_data_at_number(
        parent_hash: B256,
        block_hash: B256,
        view: u64,
        block_number: u64,
    ) -> Vec<u8> {
        let payload_json = serde_json::to_vec(&test_execution_data_at_number(
            parent_hash,
            block_hash,
            block_number,
        ))
        .expect("serialize test execution data");
        bincode::serialize(&BlockDataBroadcast {
            block_hash,
            view,
            payload_json,
            timestamp: 1,
            execution_output: None,
            leader_ready_unix_ms: 0,
        })
        .expect("serialize test block broadcast")
    }

    fn test_commit_qc(view: u64, block_hash: B256) -> QuorumCertificate {
        let key = test_key(0x11);
        let message =
            n42_consensus::protocol::quorum::commit_signing_message(view, &block_hash, &B256::ZERO);
        let signature = key.sign(&message);
        let aggregate_signature = n42_primitives::bls::AggregateSignature::aggregate(&[&signature])
            .expect("single test signature aggregates");
        let mut signers = QuorumCertificate::genesis().signers;
        signers.push(true);
        QuorumCertificate {
            view,
            block_hash,
            aggregate_signature,
            signers,
        }
    }

    fn test_block_data_with_empty_execution(
        parent_hash: B256,
        block_hash: B256,
        view: u64,
    ) -> Vec<u8> {
        test_block_data_with_empty_execution_at_number(parent_hash, block_hash, view, 1)
    }

    fn test_block_data_with_empty_execution_at_number(
        parent_hash: B256,
        block_hash: B256,
        view: u64,
        block_number: u64,
    ) -> Vec<u8> {
        let payload_json = serde_json::to_vec(&test_execution_data_at_number(
            parent_hash,
            block_hash,
            block_number,
        ))
        .expect("serialize test execution data");
        let compact = CompactBlockExecution {
            bundle_state: Default::default(),
            receipts: Vec::new(),
            requests: Default::default(),
            gas_used: 0,
            blob_gas_used: 0,
            senders: Vec::new(),
            transactions_root: None,
        };
        let execution_json = serde_json::to_vec(&compact).expect("serialize compact execution");
        let execution_output =
            zstd::bulk::compress(&execution_json, 3).expect("compress compact execution");
        bincode::serialize(&BlockDataBroadcast {
            block_hash,
            view,
            payload_json,
            timestamp: 1,
            execution_output: Some(execution_output),
            leader_ready_unix_ms: 0,
        })
        .expect("serialize test block broadcast")
    }

    #[async_trait::async_trait]
    impl ConsensusNetwork for MockConsensusNetwork {
        fn broadcast_consensus(
            &self,
            msg: n42_primitives::ConsensusMessage,
        ) -> Result<(), n42_network::NetworkError> {
            self.broadcasts
                .lock()
                .expect("mock broadcasts lock")
                .push(msg);
            Ok(())
        }

        fn broadcast_h2_v4(
            &self,
            envelope: n42_network::h2_v4::H2V4Envelope,
        ) -> Result<(), n42_network::NetworkError> {
            self.h2_v4_broadcasts
                .lock()
                .expect("mock H2-v4 broadcasts lock")
                .push(envelope);
            Ok(())
        }

        fn validator_peer(&self, index: u32) -> Option<n42_network::PeerId> {
            self.peers
                .read()
                .expect("mock peers lock")
                .get(&index)
                .copied()
        }

        fn send_direct(
            &self,
            peer: n42_network::PeerId,
            msg: n42_primitives::ConsensusMessage,
        ) -> Result<(), n42_network::NetworkError> {
            self.direct_messages
                .lock()
                .expect("mock direct messages lock")
                .push((peer, msg));
            Ok(())
        }

        fn all_validator_peers(&self) -> Vec<(u32, n42_network::PeerId)> {
            self.peers
                .read()
                .expect("mock peers lock")
                .iter()
                .map(|(index, peer_id)| (*index, *peer_id))
                .collect()
        }

        fn forward_tx_batch(
            &self,
            _peer: n42_network::PeerId,
            _txs: Vec<Vec<u8>>,
        ) -> Result<(), n42_network::NetworkError> {
            Ok(())
        }

        fn request_sync(
            &self,
            _peer: n42_network::PeerId,
            _request: n42_network::BlockSyncRequest,
        ) -> Result<(), n42_network::NetworkError> {
            Ok(())
        }

        fn request_gov5_block_by_hash(
            &self,
            _peer: n42_network::PeerId,
            _block_hash: B256,
        ) -> Result<(), n42_network::NetworkError> {
            Ok(())
        }

        async fn cancel_gov5_block_fetch_reliable(
            &self,
            block_hash: B256,
        ) -> Result<(), n42_network::NetworkError> {
            self.cancelled_gov5_fetches
                .lock()
                .expect("mock cancelled Gov5 fetches lock")
                .push(block_hash);
            Ok(())
        }

        fn broadcast_blob_sidecar(&self, _data: Vec<u8>) -> Result<(), n42_network::NetworkError> {
            Ok(())
        }

        async fn announce_block_reliable(
            &self,
            _data: Vec<u8>,
        ) -> Result<(), n42_network::NetworkError> {
            Ok(())
        }

        async fn broadcast_gov5_block_reliable(
            &self,
            _rlp: Vec<u8>,
        ) -> Result<(), n42_network::NetworkError> {
            Ok(())
        }

        async fn send_block_direct_reliable(
            &self,
            _peer: n42_network::PeerId,
            _data: Arc<Vec<u8>>,
        ) -> Result<(), n42_network::NetworkError> {
            Ok(())
        }

        async fn send_sync_response_reliable(
            &self,
            _request_id: u64,
            _response: n42_network::BlockSyncResponse,
        ) -> Result<(), n42_network::NetworkError> {
            Ok(())
        }

        async fn authenticate_validator_peer_reliable(
            &self,
            _peer_id: n42_network::PeerId,
            _validator_index: u32,
        ) -> Result<(), n42_network::NetworkError> {
            Ok(())
        }

        async fn replace_expected_validator_peers_reliable(
            &self,
            peers: HashMap<u32, n42_network::PeerId>,
        ) -> Result<(), n42_network::NetworkError> {
            *self.peers.write().expect("mock peers lock") = peers;
            Ok(())
        }

        async fn set_validator_context(&self, _my_index: u32, _validator_count: u32) {}
    }

    fn test_key(seed: u8) -> BlsSecretKey {
        BlsSecretKey::key_gen(&[seed; 32]).expect("deterministic test key should be valid")
    }

    fn make_test_engine_with_validator_count(
        count: u8,
        my_index: u8,
    ) -> (ConsensusEngine, mpsc::Receiver<EngineOutput>) {
        let fault_tolerance = u32::from(count.saturating_sub(1)) / 3;
        make_test_engine_with_fault_tolerance(count, my_index, fault_tolerance)
    }

    fn make_test_engine_with_fault_tolerance(
        count: u8,
        my_index: u8,
        fault_tolerance: u32,
    ) -> (ConsensusEngine, mpsc::Receiver<EngineOutput>) {
        assert!(my_index < count);
        let keys: Vec<_> = (0..count).map(test_key).collect();
        let validators = keys
            .iter()
            .enumerate()
            .map(|(idx, key)| ValidatorInfo {
                address: Address::with_last_byte(idx as u8),
                bls_public_key: key.public_key(),
                p2p_peer_id: None,
            })
            .collect::<Vec<_>>();
        let (output_tx, output_rx) = mpsc::channel(1024);

        let engine = ConsensusEngine::new(
            my_index as u32,
            keys[my_index as usize].clone(),
            ValidatorSet::new(&validators, fault_tolerance),
            60000,
            120000,
            output_tx,
        );
        (engine, output_rx)
    }

    fn make_test_engine() -> (ConsensusEngine, mpsc::Receiver<EngineOutput>) {
        let sk = test_key(0x11);
        let pk = sk.public_key();

        let validator_info = ValidatorInfo {
            address: Address::with_last_byte(1),
            bls_public_key: pk,
            p2p_peer_id: None,
        };

        let vs = ValidatorSet::new(&[validator_info], 0);
        let (output_tx, output_rx) = mpsc::channel(1024);

        let engine = ConsensusEngine::new(0, sk, vs, 60000, 120000, output_tx);
        (engine, output_rx)
    }

    fn make_test_engine_locked_on(
        locked_hash: B256,
    ) -> (ConsensusEngine, mpsc::Receiver<EngineOutput>) {
        let sk = test_key(0x21);
        let validator_info = ValidatorInfo {
            address: Address::with_last_byte(1),
            bls_public_key: sk.public_key(),
            p2p_peer_id: None,
        };
        let validator_set = ValidatorSet::new(&[validator_info], 0);
        let (output_tx, output_rx) = mpsc::channel(1024);
        let mut locked_qc = QuorumCertificate::genesis();
        locked_qc.view = 1;
        locked_qc.block_hash = locked_hash;
        let engine = ConsensusEngine::with_recovered_state(
            0,
            sk,
            EpochManager::new(validator_set),
            60_000,
            120_000,
            output_tx,
            2,
            locked_qc,
            QuorumCertificate::genesis(),
            0,
            0,
        );
        (engine, output_rx)
    }

    /// Returns (handle, normal_cmd_rx, priority_cmd_rx).
    fn make_test_network() -> (
        NetworkHandle,
        mpsc::Receiver<NetworkCommand>,
        mpsc::Receiver<NetworkCommand>,
    ) {
        let (cmd_tx, cmd_rx) = mpsc::channel(8);
        let (ptx, prx) = mpsc::channel(8);
        (NetworkHandle::new(cmd_tx, ptx), cmd_rx, prx)
    }

    #[test]
    fn test_orchestrator_construction() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let _ = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
    }

    #[test]
    fn test_engine_initial_state() {
        let (engine, _output_rx) = make_test_engine();
        assert_eq!(engine.current_view(), 1, "initial view should be 1");
        assert!(
            engine.is_current_leader(),
            "single validator should be leader"
        );
    }

    #[tokio::test]
    async fn test_handle_engine_output_broadcast() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, mut cmd_rx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);

        let sk = test_key(0x12);
        let sig = sk.sign(b"test");
        let vote = Vote {
            view: 1,
            block_hash: B256::repeat_byte(0xAA),
            voter: 0,
            signature: sig,
        };

        orch.handle_engine_output(EngineOutput::BroadcastMessage(ConsensusMessage::Vote(vote)))
            .await;

        let cmd = cmd_rx.try_recv().expect("should receive a command");
        assert!(
            matches!(cmd, NetworkCommand::BroadcastConsensus(_)),
            "should be a BroadcastConsensus command"
        );
    }

    #[tokio::test]
    async fn h2_v4_participant_routes_engine_output_only_to_h2_topic() {
        let (engine, output_rx) = make_test_engine();
        let network = Arc::new(MockConsensusNetwork::default());
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let identity = n42_network::h2_v4::H2V4ChainIdentity {
            chain_id: 42,
            genesis_hash: B256::repeat_byte(0x42),
        };
        let mut orch = ConsensusService::new(engine, network.clone(), net_event_rx, output_rx)
            .with_h2_v4_participant(identity);
        let vote = Vote {
            view: 1,
            block_hash: B256::repeat_byte(0xAA),
            voter: 0,
            signature: test_key(0x11).sign_h2_v4(b"test"),
        };

        orch.handle_engine_output(EngineOutput::BroadcastMessage(ConsensusMessage::Vote(vote)))
            .await;

        assert!(network.broadcasts().is_empty());
        let envelopes = network.h2_v4_broadcasts();
        assert_eq!(envelopes.len(), 1);
        assert_eq!(envelopes[0].identity, identity);
        assert_eq!(envelopes[0].changes_hash, B256::ZERO);
        assert!(matches!(
            envelopes[0].message,
            n42_network::h2_wire::H2Message::Vote(_)
        ));
    }

    #[tokio::test]
    async fn h2_v4_rejects_body_binding_before_proposal_authentication() {
        let (engine, output_rx) = make_test_engine();
        let network = Arc::new(MockConsensusNetwork::default());
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let identity = n42_network::h2_v4::H2V4ChainIdentity {
            chain_id: 42,
            genesis_hash: B256::repeat_byte(0x42),
        };
        let mut orch = ConsensusService::new(engine, network, net_event_rx, output_rx)
            .with_h2_v4_participant(identity);
        let block_hash = B256::repeat_byte(0xA5);
        let proposal = ConsensusMessage::Proposal(Proposal {
            view: 1,
            block_hash,
            justify_qc: QuorumCertificate::genesis(),
            proposer: 0,
            signature: test_key(0x77).sign_h2_v4(b"forged proposal"),
            prepare_qc: None,
            tx_root_hash: Some(B256::ZERO),
            validator_changes: None,
        });
        let envelope = n42_network::consensus_to_h2_v4(identity, &proposal).unwrap();
        let source = Keypair::generate_ed25519().public().to_peer_id();

        orch.handle_consensus_event_batch(vec![NetworkEvent::H2V4Message {
            source,
            envelope: Box::new(envelope),
        }])
        .await;

        assert!(!orch.h2_v4_block_views.contains_key(&block_hash));
    }

    #[tokio::test]
    async fn test_timeout_rebroadcast_directly_reaches_reconnected_validators() {
        let (engine, output_rx) = make_test_engine_with_validator_count(3, 0);
        let peers = (0..3u32)
            .map(|idx| {
                let keypair = Keypair::generate_ed25519();
                (idx, keypair.public().to_peer_id())
            })
            .collect::<Vec<_>>();
        let network = Arc::new(MockConsensusNetwork::with_peers(peers.clone()));
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, network.clone(), net_event_rx, output_rx);

        let view = 1;
        let timeout = TimeoutMessage {
            view,
            high_qc: QuorumCertificate::genesis(),
            sender: 0,
            signature: test_key(0).sign(&n42_consensus::protocol::quorum::timeout_signing_message(
                view,
            )),
        };

        orch.handle_engine_output(EngineOutput::BroadcastMessage(ConsensusMessage::Timeout(
            timeout,
        )))
        .await;

        let direct = network.direct_messages();
        assert_eq!(
            direct.len(),
            2,
            "timeout must use direct delivery to every peer except self"
        );
        assert!(
            direct
                .iter()
                .all(|(_, msg)| matches!(msg, ConsensusMessage::Timeout(_)))
        );
        assert!(direct.iter().all(|(peer, _)| *peer != peers[0].1));
        assert_eq!(
            network.broadcasts().len(),
            1,
            "GossipSub remains the fanout fallback"
        );
    }

    #[tokio::test]
    async fn test_consensus_event_batch_forms_qc_and_drops_bad_vote() {
        let (mut engine, output_rx) = make_test_engine_with_validator_count(4, 1);
        let block_hash = B256::repeat_byte(0xB7);
        engine
            .process_event(n42_consensus::ConsensusEvent::BlockReady(block_hash, None))
            .expect("leader should initialize the vote collector");

        let peers = (0..4u32)
            .map(|idx| {
                let keypair = Keypair::generate_ed25519();
                (idx, keypair.public().to_peer_id())
            })
            .collect::<Vec<_>>();
        let network = Arc::new(MockConsensusNetwork::with_peers(peers.clone()));
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, network, net_event_rx, output_rx);
        let signing_message = n42_consensus::protocol::quorum::signing_message(1, &block_hash);

        let events = [(0u32, 0u8), (2, 2), (3, 0)]
            .into_iter()
            .map(|(voter, signing_key)| NetworkEvent::ConsensusMessage {
                source: peers[voter as usize].1,
                message: Box::new(ConsensusMessage::Vote(Vote {
                    view: 1,
                    block_hash,
                    voter,
                    signature: test_key(signing_key).sign(&signing_message),
                })),
            })
            .collect();

        orch.handle_consensus_event_batch(events).await;

        assert!(
            std::iter::from_fn(|| orch.output_rx.try_recv().ok()).any(|output| matches!(
                output,
                EngineOutput::BroadcastMessage(ConsensusMessage::PrepareQC(_))
            ))
        );
    }

    #[tokio::test]
    async fn test_handle_engine_output_send_to_validator() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, mut cmd_rx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);

        let sk = test_key(0x13);
        let sig = sk.sign(b"test");
        let vote = Vote {
            view: 1,
            block_hash: B256::repeat_byte(0xBB),
            voter: 0,
            signature: sig,
        };

        orch.handle_engine_output(EngineOutput::SendToValidator(
            0,
            ConsensusMessage::Vote(vote),
        ))
        .await;

        let cmd = cmd_rx.try_recv().expect("should receive a command");
        assert!(
            matches!(cmd, NetworkCommand::BroadcastConsensus(_)),
            "SendToValidator should fallback to BroadcastConsensus"
        );
    }

    #[tokio::test]
    async fn test_current_view_vote_is_resent_directly_until_view_changes() {
        let (engine, output_rx) = make_test_engine_with_validator_count(3, 0);
        let collector = n42_network::PeerId::random();
        let network = MockConsensusNetwork::with_peers(vec![(1, collector)]);
        let network_probe = network.clone();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);

        let vote = Vote {
            view: 1,
            block_hash: B256::repeat_byte(0xBC),
            voter: 0,
            signature: test_key(0).sign(b"vote-resend"),
        };
        orch.handle_engine_output(EngineOutput::SendToValidator(
            1,
            ConsensusMessage::Vote(vote),
        ))
        .await;

        assert_eq!(network_probe.direct_messages().len(), 1);
        assert_eq!(network_probe.broadcasts().len(), 1);
        orch.resend_pending_vote();
        assert_eq!(
            network_probe.direct_messages().len(),
            2,
            "the collector should receive the exact signed vote again"
        );
        assert_eq!(
            network_probe.broadcasts().len(),
            1,
            "successful direct resend should not add gossip traffic"
        );

        orch.pending_vote_resend
            .as_mut()
            .expect("vote should remain pending")
            .view = 0;
        orch.resend_pending_vote();
        assert!(orch.pending_vote_resend.is_none());
        assert_eq!(network_probe.direct_messages().len(), 2);
    }

    #[tokio::test]
    async fn test_handle_engine_output_execute_block() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.handle_engine_output(EngineOutput::ExecuteBlock(B256::repeat_byte(0xCC)))
            .await;
    }

    #[tokio::test]
    async fn test_commit_without_execution_confirmation_does_not_advance_head() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);

        let commit_qc = QuorumCertificate::genesis();
        orch.handle_engine_output(EngineOutput::BlockCommitted {
            view: 1,
            block_hash: B256::repeat_byte(0xDD),
            commit_qc,
            validator_changes: None,
        })
        .await;

        assert_eq!(
            orch.head_block_hash,
            B256::ZERO,
            "agreement alone must not advance the execution head"
        );
        assert_eq!(orch.committed_block_count, 1);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn committed_invalid_payload_preserves_validated_head_and_build_parent() {
        let recorder = DebuggingRecorder::new();
        let snapshotter = recorder.snapshotter();
        let _recorder_guard = metrics::set_default_local_recorder(&recorder);

        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let previous_head = B256::repeat_byte(0x11);
        let bad_hash = B256::repeat_byte(0xDD);
        let view = 1;
        let mock_el = Arc::new(MockExecutionLayer::new(
            PayloadStatusEnum::Invalid {
                validation_error: "stale nonce".to_string(),
            },
            PayloadStatusEnum::Syncing,
        ));
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.el = Some(mock_el.clone());
        orch.head_block_hash = previous_head;
        orch.async_finalize_fcu = false;
        orch.pending_block_data.insert(
            bad_hash,
            test_block_data(previous_head, bad_hash, view).into(),
        );

        orch.handle_engine_output(EngineOutput::BlockCommitted {
            view,
            block_hash: bad_hash,
            commit_qc: QuorumCertificate::genesis(),
            validator_changes: None,
        })
        .await;

        assert_eq!(orch.committed_block_count, 1, "QC agreement still advances");
        assert_eq!(orch.head_block_hash, previous_head);
        orch.handle_commit_execution_timeout(view, bad_hash);

        let (hash, imported_view, outcome, block_ts) =
            tokio::time::timeout(Duration::from_secs(2), orch.import_done_rx.recv())
                .await
                .expect("background import should finish")
                .expect("background import channel should remain open");
        assert_eq!((hash, imported_view), (bad_hash, view));
        assert_eq!(
            outcome,
            ImportOutcome::Invalid,
            "mock new_payload Invalid must reject the block"
        );
        orch.handle_import_done(hash, imported_view, outcome, block_ts)
            .await;

        assert_eq!(
            orch.head_block_hash, previous_head,
            "committed invalid block must not pin the local execution head"
        );
        let metric_value =
            snapshotter
                .snapshot()
                .into_vec()
                .into_iter()
                .find_map(|(key, _, _, value)| {
                    (key.key().name() == "n42_committed_block_unexecutable_total").then_some(value)
                });
        assert_eq!(metric_value, Some(DebugValue::Counter(1)));

        orch.do_trigger_payload_build(None).await;
        assert_eq!(mock_el.build_parents(), vec![previous_head]);
        assert!(
            !mock_el.build_parents().contains(&bad_hash),
            "no payload build may use the unexecutable committed hash as parent"
        );
    }

    /// S3 acceptance: when consensus is locked on A but reth's last validated
    /// head is the same-height sibling B, the leader must request a payload on
    /// A. A sibling B must not be advertised as A's safe/finalized ancestor.
    #[tokio::test]
    async fn leader_build_uses_locked_qc_parent_over_local_execution_sibling() {
        let locked_parent = B256::repeat_byte(0xA1);
        let execution_sibling = B256::repeat_byte(0xB2);
        let (engine, output_rx) = make_test_engine_locked_on(locked_parent);
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mock_el = Arc::new(MockExecutionLayer::new(
            PayloadStatusEnum::Valid,
            PayloadStatusEnum::Valid,
        ));
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.el = Some(mock_el.clone());
        orch.head_block_hash = execution_sibling;

        orch.do_trigger_payload_build(None).await;

        assert_eq!(mock_el.build_parents(), vec![locked_parent]);
        assert_eq!(
            mock_el.build_forkchoices(),
            vec![(locked_parent, B256::ZERO, B256::ZERO)],
            "LockedQC must drive FCU head without claiming sibling B as its safe/finalized ancestor"
        );
    }

    #[test]
    fn payload_ready_is_bound_to_captured_locked_qc_context() {
        let locked_parent = B256::repeat_byte(0xA1);
        let wrong_parent = B256::repeat_byte(0xB2);
        let child = B256::repeat_byte(0xC3);
        let (engine, output_rx) = make_test_engine_locked_on(locked_parent);
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        let stale_context = PayloadBuildContext {
            view: 2,
            parent_hash: wrong_parent,
        };
        orch.building_on_parent = Some(stale_context);
        orch.build_triggered_at = Some(Instant::now());

        assert!(
            !orch.handle_payload_build_ready(PayloadBuildReady {
                context: stale_context,
                block_hash: child,
            }),
            "a payload from a sibling parent must not enter consensus"
        );
        assert!(
            orch.output_rx.try_recv().is_err(),
            "no proposal may be emitted"
        );
        assert!(
            orch.next_build_at.is_some(),
            "the leader must retry on LockedQC"
        );

        let locked_context = PayloadBuildContext {
            view: 2,
            parent_hash: locked_parent,
        };
        orch.building_on_parent = Some(locked_context);
        orch.build_triggered_at = Some(Instant::now());
        assert!(orch.handle_payload_build_ready(PayloadBuildReady {
            context: locked_context,
            block_hash: child,
        }));

        let proposal = match orch.output_rx.try_recv().expect("proposal output") {
            EngineOutput::BroadcastMessage(ConsensusMessage::Proposal(proposal)) => proposal,
            output => panic!("expected Proposal, got {output:?}"),
        };
        assert_eq!(proposal.view, locked_context.view);
        assert_eq!(proposal.block_hash, child);
        assert_eq!(proposal.justify_qc.block_hash, locked_parent);
    }

    #[test]
    fn stale_build_completion_cannot_clear_new_view_guard() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        let old_context = PayloadBuildContext {
            view: 7,
            parent_hash: B256::repeat_byte(0x71),
        };
        let new_context = PayloadBuildContext {
            view: 8,
            parent_hash: B256::repeat_byte(0x82),
        };
        orch.building_on_parent = Some(new_context);
        orch.build_triggered_at = Some(Instant::now());

        assert!(!orch.handle_payload_build_complete(old_context));
        assert_eq!(orch.building_on_parent, Some(new_context));
        assert!(orch.build_triggered_at.is_some());
        assert!(orch.handle_payload_build_complete(new_context));
        assert!(orch.building_on_parent.is_none());
        assert!(orch.build_triggered_at.is_none());
    }

    #[tokio::test(flavor = "current_thread")]
    async fn committed_syncing_payload_requests_missing_execution_ancestors() {
        let (engine, output_rx) = make_test_engine();
        let (network, mut cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let peer = n42_network::PeerId::random();
        let previous_head = B256::repeat_byte(0x11);
        let waiting_hash = B256::repeat_byte(0x22);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.connected_peers.insert(peer);
        orch.head_block_hash = previous_head;
        orch.committed_blocks.push_back(CommittedBlock {
            view: 1,
            block_hash: waiting_hash,
            commit_qc: QuorumCertificate::genesis(),
            payload: Vec::new(),
            payload_len: 0,
            block_data: None,
            validator_changes: None,
            execution_lineage: Vec::new(),
        });
        orch.pending_sidecar_diffs.insert(
            1,
            (
                waiting_hash,
                n42_execution::state_diff::StateDiff::default(),
            ),
        );

        orch.handle_import_done(waiting_hash, 1, ImportOutcome::Syncing, 0)
            .await;

        assert_eq!(orch.head_block_hash, previous_head);
        assert!(
            orch.pending_sidecar_diffs.contains_key(&1),
            "a retryable missing-parent result must preserve the staged sidecar diff"
        );
        let command = tokio::time::timeout(Duration::from_secs(1), cmd_rx.recv())
            .await
            .expect("catch-up sync command should be sent")
            .expect("network command channel should remain open");
        match command {
            NetworkCommand::RequestSync {
                peer: target,
                request,
            } => {
                assert_eq!(target, peer);
                assert_eq!(request.from_view, 1);
                assert_eq!(request.to_view, 1);
                assert_eq!(request.local_committed_view, 0);
            }
            other => panic!("unexpected network command: {other:?}"),
        }
    }

    #[tokio::test]
    async fn committed_valid_fcu_advances_execution_head() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let previous_head = B256::repeat_byte(0x22);
        let valid_hash = B256::repeat_byte(0xEE);
        let mock_el = Arc::new(MockExecutionLayer::new(
            PayloadStatusEnum::Valid,
            PayloadStatusEnum::Valid,
        ));
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.el = Some(mock_el);
        orch.head_block_hash = previous_head;
        orch.async_finalize_fcu = false;

        orch.handle_engine_output(EngineOutput::BlockCommitted {
            view: 1,
            block_hash: valid_hash,
            commit_qc: QuorumCertificate::genesis(),
            validator_changes: None,
        })
        .await;

        assert_eq!(orch.committed_block_count, 1);
        assert_eq!(orch.head_block_hash, previous_head);
        orch.handle_eager_import_done(valid_hash, 1, previous_head, 1, false, None)
            .await;
        assert_eq!(orch.head_block_hash, valid_hash);
        assert_eq!(orch.execution_validated_head_view, 1);
    }

    #[tokio::test]
    async fn eager_valid_before_commit_advances_head_only_after_commit() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let previous_head = B256::repeat_byte(0x33);
        let eager_hash = B256::repeat_byte(0xEF);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.head_block_hash = previous_head;

        orch.handle_eager_import_done(eager_hash, 1, previous_head, 1, false, None)
            .await;
        assert_eq!(
            orch.head_block_hash, previous_head,
            "speculative eager validity must not move head before commit"
        );

        orch.handle_engine_output(EngineOutput::BlockCommitted {
            view: 1,
            block_hash: eager_hash,
            commit_qc: QuorumCertificate::genesis(),
            validator_changes: None,
        })
        .await;

        assert_eq!(orch.head_block_hash, eager_hash);
        assert_eq!(orch.execution_validated_head_view, 1);
        assert!(orch.eager_execution_validated.is_empty());
    }

    #[tokio::test]
    async fn queued_eager_validity_drained_during_finalize_advances_head() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let previous_head = B256::repeat_byte(0x34);
        let eager_hash = B256::repeat_byte(0xF0);
        let mock_el = Arc::new(MockExecutionLayer::with_fcu_statuses(
            PayloadStatusEnum::Valid,
            [PayloadStatusEnum::Syncing, PayloadStatusEnum::Valid],
        ));
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.el = Some(mock_el);
        orch.head_block_hash = previous_head;
        orch.async_finalize_fcu = false;
        orch.eager_import_done_tx
            .send((eager_hash, 1, previous_head, 1, false, None))
            .await
            .expect("queue eager completion");

        orch.handle_engine_output(EngineOutput::BlockCommitted {
            view: 1,
            block_hash: eager_hash,
            commit_qc: QuorumCertificate::genesis(),
            validator_changes: None,
        })
        .await;

        assert_eq!(orch.head_block_hash, eager_hash);
        assert_eq!(orch.execution_validated_head_view, 1);
        assert!(orch.eager_execution_validated.is_empty());
    }

    #[test]
    fn stale_execution_completion_cannot_regress_head() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        let newer_hash = B256::repeat_byte(0x44);

        orch.advance_execution_validated_head(2, newer_hash, "test newer completion");
        orch.advance_execution_validated_head(1, B256::repeat_byte(0x45), "test stale completion");

        assert_eq!(orch.head_block_hash, newer_hash);
        assert_eq!(orch.execution_validated_head_view, 2);
    }

    #[tokio::test]
    async fn test_late_recovered_validator_changes_patch_sync_cache() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);

        let block_hash = B256::repeat_byte(0xA5);
        orch.store_committed_block(15, block_hash, QuorumCertificate::genesis(), None, &[]);

        orch.handle_engine_output(EngineOutput::CommittedBlockValidatorChangesRecovered {
            view: 15,
            block_hash,
            validator_changes: vec![ValidatorChange::Add {
                address: Address::with_last_byte(0x04),
                bls_public_key: test_key(0x44).public_key(),
                p2p_peer_id: None,
            }],
        })
        .await;

        assert_eq!(orch.committed_blocks.len(), 1);
        assert!(orch.committed_blocks[0].validator_changes.is_some());
        assert_eq!(
            orch.committed_blocks[0]
                .validator_changes
                .as_ref()
                .expect("validator changes should be patched")
                .len(),
            1
        );
    }

    #[tokio::test]
    async fn test_handle_engine_output_view_changed() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.handle_engine_output(EngineOutput::ViewChanged { new_view: 5 })
            .await;
    }

    #[test]
    fn attaching_epoch_schedule_pre_stages_first_rotation() {
        let current_key = test_key(0x31);
        let current = ValidatorInfo {
            address: Address::with_last_byte(0x31),
            bls_public_key: current_key.public_key(),
            p2p_peer_id: None,
        };
        let next_validators = vec![
            current.clone(),
            ValidatorInfo {
                address: Address::with_last_byte(0x32),
                bls_public_key: test_key(0x32).public_key(),
                p2p_peer_id: None,
            },
        ];
        let dir = tempfile::tempdir().unwrap();
        let schedule_path = dir.path().join("epoch_schedule.json");
        let json = serde_json::json!([{
            "start_epoch": 1,
            "validators": next_validators,
            "fault_tolerance": 0,
        }]);
        std::fs::write(&schedule_path, serde_json::to_vec(&json).unwrap()).unwrap();
        let schedule = EpochSchedule::load(&schedule_path)
            .unwrap()
            .expect("schedule should load");

        let (output_tx, output_rx) = mpsc::channel(64);
        let engine = ConsensusEngine::with_epoch_manager(
            0,
            current_key,
            EpochManager::with_epoch_length(ValidatorSet::new(&[current], 0), 30),
            60_000,
            120_000,
            output_tx,
        );
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx)
            .with_epoch_schedule(schedule);

        assert!(orch.engine.epoch_manager().has_staged_next());
        assert_eq!(
            orch.engine
                .epoch_manager()
                .peek_next_set()
                .expect("epoch 1 should be staged")
                .len(),
            2
        );
    }

    #[tokio::test]
    async fn test_epoch_transition_refreshes_expected_validator_peers() {
        let (engine, output_rx) = make_test_engine();
        let (network, mut cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);

        let peer0 = Keypair::generate_ed25519().public().to_peer_id();
        let peer1 = Keypair::generate_ed25519().public().to_peer_id();
        let next_validators = vec![
            ValidatorInfo {
                address: Address::with_last_byte(0x10),
                bls_public_key: test_key(0x20).public_key(),
                p2p_peer_id: Some(peer0.to_string()),
            },
            ValidatorInfo {
                address: Address::with_last_byte(0x11),
                bls_public_key: test_key(0x21).public_key(),
                p2p_peer_id: Some(peer1.to_string()),
            },
        ];
        orch.engine
            .epoch_manager_mut()
            .stage_next_epoch(&next_validators, 0)
            .unwrap();
        assert!(orch.engine.epoch_manager_mut().advance_epoch());

        orch.handle_engine_output(EngineOutput::EpochTransition {
            new_epoch: 1,
            validator_count: 2,
        })
        .await;

        match cmd_rx.try_recv().expect("expected network refresh command") {
            NetworkCommand::ReplaceExpectedValidatorPeers { peers } => {
                assert_eq!(peers.get(&0), Some(&peer0));
                assert_eq!(peers.get(&1), Some(&peer1));
            }
            other => panic!("expected ReplaceExpectedValidatorPeers, got {other:?}"),
        }
    }

    #[tokio::test]
    async fn test_epoch_transition_clears_expected_validator_peers_when_strict_binding_missing() {
        let (engine, output_rx) = make_test_engine();
        let (network, mut cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx)
            .with_allow_deterministic_validator_peers(false);

        let next_validators = vec![
            ValidatorInfo {
                address: Address::with_last_byte(0x20),
                bls_public_key: test_key(0x22).public_key(),
                p2p_peer_id: None,
            },
            ValidatorInfo {
                address: Address::with_last_byte(0x21),
                bls_public_key: test_key(0x23).public_key(),
                p2p_peer_id: None,
            },
        ];
        orch.engine
            .epoch_manager_mut()
            .stage_next_epoch(&next_validators, 0)
            .unwrap();
        assert!(orch.engine.epoch_manager_mut().advance_epoch());

        orch.handle_engine_output(EngineOutput::EpochTransition {
            new_epoch: 1,
            validator_count: 2,
        })
        .await;

        match cmd_rx.try_recv().expect("expected network refresh command") {
            NetworkCommand::ReplaceExpectedValidatorPeers { peers } => {
                assert!(peers.is_empty());
            }
            other => panic!("expected ReplaceExpectedValidatorPeers, got {other:?}"),
        }
    }

    #[tokio::test]
    async fn test_orchestrator_exits_on_net_event_channel_close() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (net_event_tx, net_event_rx) = mpsc::channel::<NetworkEvent>(8192);
        let orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        drop(net_event_tx);

        let result = tokio::time::timeout(Duration::from_secs(5), orch.run()).await;
        assert!(
            result.is_ok(),
            "orchestrator should exit when network event channel is closed"
        );
    }

    #[tokio::test]
    async fn test_orchestrator_processes_peer_events() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (net_event_tx, net_event_rx) = mpsc::channel::<NetworkEvent>(8192);
        let orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);

        let peer_id = libp2p::PeerId::random();
        net_event_tx
            .try_send(NetworkEvent::PeerConnected(peer_id))
            .unwrap();
        drop(net_event_tx);

        let result = tokio::time::timeout(Duration::from_secs(5), orch.run()).await;
        assert!(
            result.is_ok(),
            "orchestrator should exit after processing events"
        );
    }

    fn make_test_orchestrator_with_state(
        state: Option<Arc<SharedConsensusState>>,
    ) -> ConsensusService {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.consensus_state = state;
        orch
    }

    #[test]
    fn pending_and_recent_block_caches_share_the_same_allocation() {
        let mut orch = make_test_orchestrator_with_state(None);
        let parent_hash = B256::repeat_byte(0x31);
        let block_hash = B256::repeat_byte(0x32);
        let data = Arc::new(test_block_data(parent_hash, block_hash, 2));

        assert!(orch.cache_pending_block_data(block_hash, Arc::clone(&data), &[block_hash]));

        let pending = Arc::clone(
            orch.pending_block_data
                .get(&block_hash)
                .expect("block is retained for execution"),
        );
        let recent = Arc::clone(
            &orch
                .recent_block_data
                .back()
                .expect("block is retained for lineage")
                .block_data,
        );
        assert!(Arc::ptr_eq(&data, &pending));
        assert!(Arc::ptr_eq(&pending, &recent));

        let expected_payload = bincode::deserialize::<BlockDataBroadcast>(data.as_slice())
            .expect("test block data decodes")
            .payload_json;
        orch.store_committed_block(2, block_hash, QuorumCertificate::genesis(), None, &[]);
        let committed = orch.committed_blocks.back().expect("commit ring entry");
        assert!(
            committed.payload.is_empty(),
            "hot path must not copy payload"
        );
        assert!(Arc::ptr_eq(
            &pending,
            committed.block_data.as_ref().expect("shared envelope")
        ));
        assert_eq!(committed.retained_payload(), expected_payload);
    }

    #[test]
    fn test_cache_pending_block_data_preserves_protected_hash_when_full() {
        let mut orch = make_test_orchestrator_with_state(None);
        let protected_hash = B256::repeat_byte(0x00);
        for byte in 0..super::execution_bridge::MAX_PENDING_BLOCK_DATA {
            let hash = B256::repeat_byte(byte as u8);
            orch.pending_block_data
                .insert(hash, vec![byte as u8].into());
        }

        let incoming_hash = B256::repeat_byte(0xff);
        assert!(orch.cache_pending_block_data(incoming_hash, vec![0xff], &[protected_hash]));

        assert_eq!(
            orch.pending_block_data.len(),
            super::execution_bridge::MAX_PENDING_BLOCK_DATA
        );
        assert!(orch.pending_block_data.contains_key(&protected_hash));
        assert!(orch.pending_block_data.contains_key(&incoming_hash));
        assert!(
            !orch
                .pending_block_data
                .contains_key(&B256::repeat_byte(0x01))
        );
    }

    #[test]
    fn test_leader_payload_drain_preserves_finalizing_hash_when_full() {
        let mut orch = make_test_orchestrator_with_state(None);
        for byte in 1..=super::execution_bridge::MAX_PENDING_BLOCK_DATA {
            let hash = B256::repeat_byte(byte as u8);
            orch.pending_block_data
                .insert(hash, vec![byte as u8].into());
        }

        let finalizing_hash = B256::repeat_byte(0x00);
        let later_hash = B256::repeat_byte(0xff);
        orch.leader_payload_tx
            .try_send((finalizing_hash, b"target".to_vec().into()))
            .expect("leader payload channel should accept target");
        orch.leader_payload_tx
            .try_send((later_hash, b"later".to_vec().into()))
            .expect("leader payload channel should accept later payload");

        orch.drain_leader_payload_rx(&[finalizing_hash]);

        assert_eq!(
            orch.pending_block_data
                .get(&finalizing_hash)
                .map(|data| data.as_slice()),
            Some(&b"target"[..])
        );
        assert_eq!(
            orch.pending_block_data.len(),
            super::execution_bridge::MAX_PENDING_BLOCK_DATA
        );
        assert!(orch.pending_block_data.contains_key(&later_hash));
        assert!(
            !orch
                .pending_block_data
                .contains_key(&B256::repeat_byte(0x01))
        );
    }

    #[test]
    fn leader_payload_drain_backfills_committed_sync_payload() {
        let mut orch = make_test_orchestrator_with_state(None);
        let parent_hash = B256::repeat_byte(0x31);
        let block_hash = B256::repeat_byte(0x32);
        let data = test_block_data(parent_hash, block_hash, 2);
        let expected_payload = bincode::deserialize::<BlockDataBroadcast>(&data)
            .expect("test broadcast decodes")
            .payload_json;
        orch.committed_blocks.push_back(CommittedBlock {
            view: 2,
            block_hash,
            commit_qc: QuorumCertificate::genesis(),
            payload: Vec::new(),
            payload_len: 0,
            block_data: None,
            validator_changes: None,
            execution_lineage: Vec::new(),
        });
        orch.leader_payload_tx
            .try_send((block_hash, data.into()))
            .expect("leader payload channel should accept block");

        orch.drain_leader_payload_rx(&[block_hash]);

        assert_eq!(
            orch.committed_blocks[0].retained_payload(),
            expected_payload
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn committed_child_uses_execution_number_when_ancestor_payload_is_missing() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let durable_head = B256::repeat_byte(0x53);
        let missing_parent = B256::repeat_byte(0x54);
        let committed_hash = B256::repeat_byte(0x55);
        let data = test_block_data_at_number(missing_parent, committed_hash, 145, 145);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.head_block_hash = durable_head;
        orch.committed_block_count = 143;
        assert!(orch.cache_pending_block_data(committed_hash, data, &[committed_hash]));

        orch.handle_block_committed(
            145,
            committed_hash,
            test_commit_qc(145, committed_hash),
            None,
        )
        .await;

        assert_eq!(
            orch.committed_block_count, 145,
            "the child payload reveals the real execution height even before its parent is recovered"
        );
        assert_eq!(orch.head_block_hash, durable_head);
        assert_eq!(orch.committed_blocks.len(), 1);
        assert_eq!(
            orch.committed_blocks[0].execution_lineage.len(),
            0,
            "an incomplete raw ancestry is not retained as a trusted recovery lineage"
        );
    }

    #[tokio::test]
    async fn test_block_committed_updates_shared_state() {
        let vs = ValidatorSet::new(&[], 0);
        let state = Arc::new(SharedConsensusState::new(vs));
        let mut orch = make_test_orchestrator_with_state(Some(state.clone()));

        assert!(
            state.load_committed_qc().is_none(),
            "should start with no QC"
        );

        let commit_qc = QuorumCertificate::genesis();
        orch.handle_engine_output(EngineOutput::BlockCommitted {
            view: 1,
            block_hash: B256::repeat_byte(0xEE),
            commit_qc,
            validator_changes: None,
        })
        .await;

        assert!(
            state.load_committed_qc().is_some(),
            "should have QC after commit"
        );
    }

    #[tokio::test]
    async fn committed_waits_for_execution_ready_before_finalized_fcu() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mock_el = Arc::new(MockExecutionLayer::new(
            PayloadStatusEnum::Valid,
            PayloadStatusEnum::Valid,
        ));
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.el = Some(mock_el.clone());
        orch.async_finalize_fcu = false;
        let block_hash = B256::repeat_byte(0xc1);

        orch.handle_block_committed(1, block_hash, test_commit_qc(1, block_hash), None)
            .await;

        assert!(mock_el.fcu_heads().is_empty());
        assert_eq!(
            orch.async_commit_states.get(&1).map(|state| state.stage),
            Some(AsyncCommitStage::Committed)
        );

        orch.handle_eager_import_done(block_hash, 1, B256::ZERO, 1, false, None)
            .await;

        assert_eq!(mock_el.fcu_heads(), vec![block_hash]);
        assert_eq!(
            orch.async_commit_states.get(&1).map(|state| state.stage),
            Some(AsyncCommitStage::Finalized)
        );
    }

    #[tokio::test]
    async fn execution_ready_children_finalize_in_commit_order() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mock_el = Arc::new(MockExecutionLayer::new(
            PayloadStatusEnum::Valid,
            PayloadStatusEnum::Valid,
        ));
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.el = Some(mock_el.clone());
        orch.async_finalize_fcu = false;
        let first = B256::repeat_byte(0xd1);
        let second = B256::repeat_byte(0xd2);
        orch.handle_block_committed(1, first, test_commit_qc(1, first), None)
            .await;
        orch.handle_block_committed(2, second, test_commit_qc(2, second), None)
            .await;

        orch.handle_eager_import_done(second, 2, first, 2, false, None)
            .await;
        assert!(mock_el.fcu_heads().is_empty());

        orch.handle_eager_import_done(first, 1, B256::ZERO, 1, false, None)
            .await;
        assert_eq!(mock_el.fcu_heads(), vec![first, second]);
    }

    #[tokio::test]
    async fn execution_ready_marks_every_view_reusing_the_same_block() {
        let mut orch = make_test_orchestrator_with_state(None);
        let block_hash = B256::repeat_byte(0xd3);
        orch.handle_block_committed(1, block_hash, test_commit_qc(1, block_hash), None)
            .await;
        orch.handle_block_committed(2, block_hash, test_commit_qc(2, block_hash), None)
            .await;

        orch.handle_eager_import_done(block_hash, 1, B256::ZERO, 1, false, None)
            .await;

        assert!(orch.async_commit_states.values().all(|state| {
            state.block_hash != block_hash || state.stage == AsyncCommitStage::Finalized
        }));
    }

    #[tokio::test]
    async fn test_block_ready_channel() {
        let mut orch = make_test_orchestrator_with_state(None);
        let block_ready_tx = orch.block_ready_tx.clone();

        let test_hash = B256::repeat_byte(0xFF);
        let ready = PayloadBuildReady {
            context: PayloadBuildContext {
                view: 7,
                parent_hash: B256::repeat_byte(0xEE),
            },
            block_hash: test_hash,
        };
        block_ready_tx.send(ready).await.unwrap();

        let received = orch.block_ready_rx.try_recv();
        assert!(received.is_ok(), "should receive BlockReady context");
        assert_eq!(received.unwrap(), ready);
    }

    #[test]
    fn test_restore_failed_tx_forward_batch_preserves_recent_suffix() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);

        let txs: Vec<Vec<u8>> = (0..5000)
            .map(|i| vec![(i & 0xff) as u8, ((i >> 8) & 0xff) as u8])
            .collect();
        let expected_tail = txs[2952..].to_vec();

        orch.restore_failed_tx_forward_batch(txs, 1);

        assert_eq!(orch.tx_forward_buffer.len(), 2048);
        assert_eq!(orch.tx_forward_buffer, expected_tail);
    }

    #[test]
    fn test_missing_tx_forward_leader_warns_once_per_view() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);

        assert!(orch.should_warn_missing_tx_forward_leader(41));
        assert!(!orch.should_warn_missing_tx_forward_leader(41));
        assert!(orch.should_warn_missing_tx_forward_leader(42));
        assert!(!orch.should_warn_missing_tx_forward_leader(42));
    }

    #[tokio::test]
    async fn test_sync_timeout_resets_in_flight() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);

        orch.connected_peers.insert(libp2p::PeerId::random());
        orch.sync_in_flight = true;
        orch.sync_started_at =
            Some(Instant::now() - state_mgmt::sync_request_timeout() - Duration::from_secs(1));

        orch.initiate_sync(1, 10);

        assert!(orch.sync_in_flight, "new sync request should be in flight");
        let started = orch.sync_started_at.expect("sync_started_at should be set");
        assert!(
            started.elapsed() < Duration::from_secs(2),
            "sync_started_at should be recent after timeout reset"
        );
    }

    #[tokio::test]
    async fn independent_sync_deadline_refans_out_the_original_range() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        let peers = [libp2p::PeerId::random(), libp2p::PeerId::random()];
        orch.connected_peers.extend(peers);
        orch.sync_in_flight = true;
        orch.sync_started_at =
            Some(Instant::now() - state_mgmt::sync_request_timeout() - Duration::from_secs(1));
        orch.sync_request_range = Some((41, 47));
        orch.sync_requested_peers.insert(peers[0]);

        orch.retry_expired_sync_request();

        assert!(orch.sync_in_flight);
        assert_eq!(orch.sync_request_range, Some((41, 47)));
        assert_eq!(orch.sync_requested_peers, peers.into_iter().collect());
        assert!(
            orch.sync_started_at
                .expect("replacement request has a deadline")
                .elapsed()
                < Duration::from_secs(2)
        );
    }

    fn test_h2_identity() -> n42_network::h2_v4::H2V4ChainIdentity {
        n42_network::h2_v4::H2V4ChainIdentity {
            chain_id: 42,
            genesis_hash: B256::repeat_byte(0x42),
        }
    }

    /// A block-data envelope is unauthenticated bincode: `block_hash` is a
    /// self-declared field, and nothing has checked it against the payload by
    /// the time `handle_block_data` returns. Retiring a Gov5 fetch on it would
    /// let anyone who can reach this port cancel an in-flight ancestry fetch —
    /// and suppress re-requests for 30s — by gossiping a forged envelope
    /// carrying the victim's target hash.
    #[tokio::test]
    async fn forged_block_data_envelope_cannot_retire_a_gov5_fetch() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, mut prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx)
            .with_h2_v4_participant(test_h2_identity());
        let target_hash = B256::repeat_byte(0xa6);
        let peer = libp2p::PeerId::random();
        orch.h2_v4_fetch_requested_at
            .insert(target_hash, (Instant::now(), peer));

        // The envelope names the hash the victim is fetching. Its payload is
        // never validated against that claim on this path.
        orch.handle_block_data(test_block_data(B256::ZERO, target_hash, 1))
            .await;

        assert!(
            orch.h2_v4_fetch_requested_at.contains_key(&target_hash),
            "an unauthenticated envelope must not cancel a live fetch"
        );
        assert!(
            prx.try_recv().is_err(),
            "no cancellation command may be derived from a claimed hash"
        );
    }

    /// Retirement moves to the eager-import completion callback: reth only
    /// reaches it after accepting that exact payload, so the hash is proven
    /// rather than claimed. Both the local tracker and the shared network-layer
    /// request are retired there, including a fetch owned by the other
    /// orchestrator sharing this network service.
    #[tokio::test]
    async fn validated_import_retires_concurrent_gov5_hash_fetch() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, mut prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx)
            .with_h2_v4_participant(test_h2_identity());
        let block_hash = B256::repeat_byte(0xa6);
        let peer = libp2p::PeerId::random();
        orch.h2_v4_fetch_requested_at
            .insert(block_hash, (Instant::now(), peer));

        orch.handle_eager_import_done(block_hash, 1, B256::ZERO, 1, false, None)
            .await;

        assert!(!orch.h2_v4_fetch_requested_at.contains_key(&block_hash));
        assert!(matches!(
            prx.try_recv().expect("cross-path cancellation command"),
            NetworkCommand::CancelGov5BlockFetch { block_hash: hash }
                if hash == block_hash
        ));
    }

    #[tokio::test]
    async fn validated_import_retires_fetch_owned_by_other_consumer() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, mut prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx)
            .with_h2_v4_participant(test_h2_identity());
        let block_hash = B256::repeat_byte(0xa7);

        assert!(!orch.h2_v4_fetch_requested_at.contains_key(&block_hash));
        orch.handle_eager_import_done(block_hash, 1, B256::ZERO, 1, false, None)
            .await;

        assert!(matches!(
            prx.try_recv().expect("shared fetch cancellation command"),
            NetworkCommand::CancelGov5BlockFetch { block_hash: hash }
                if hash == block_hash
        ));
    }

    /// Native mode never fetches bodies from Gov5, so it must not pay for the
    /// tombstone write or the network command on every block.
    #[tokio::test]
    async fn native_mode_import_does_not_touch_gov5_fetch_state() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, mut prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        let block_hash = B256::repeat_byte(0xa9);

        orch.handle_eager_import_done(block_hash, 1, B256::ZERO, 1, false, None)
            .await;

        assert!(prx.try_recv().is_err());
    }

    #[tokio::test]
    async fn fulfilled_block_cannot_rearm_a_local_h2_fetch_deadline() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, mut prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx)
            .with_h2_v4_participant(test_h2_identity());
        let block_hash = B256::repeat_byte(0xa8);
        let peer = libp2p::PeerId::random();

        orch.handle_eager_import_done(block_hash, 1, B256::ZERO, 1, false, None)
            .await;
        assert!(matches!(
            prx.try_recv().expect("body delivery cancellation command"),
            NetworkCommand::CancelGov5BlockFetch { block_hash: hash }
                if hash == block_hash
        ));

        // A duplicate proposal/QC can be queued behind the body and ask for
        // the same hash after it has already advanced out of the head slot.
        orch.request_h2_v4_gov5_block(peer, block_hash);

        assert!(!orch.h2_v4_fetch_requested_at.contains_key(&block_hash));
        assert!(
            prx.try_recv().is_err(),
            "a recently fulfilled hash must not queue another request"
        );

        // Also fail closed if an already-queued command managed to create a
        // local deadline just before the fulfillment tombstone was observed.
        orch.connected_peers.insert(peer);
        orch.h2_v4_fetch_requested_at.insert(
            block_hash,
            (
                Instant::now() - H2_V4_FETCH_RETRY_TIMEOUT - Duration::from_secs(1),
                peer,
            ),
        );
        orch.retry_expired_h2_v4_fetches();

        assert!(!orch.h2_v4_fetch_requested_at.contains_key(&block_hash));
        assert!(
            prx.try_recv().is_err(),
            "a fulfilled hash must not be retried from a stale local deadline"
        );
    }

    #[tokio::test]
    async fn expired_h2_block_fetch_rotates_without_a_network_failure_event() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, mut prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        let peers = [
            libp2p::PeerId::random(),
            libp2p::PeerId::random(),
            libp2p::PeerId::random(),
        ];
        let block_hash = B256::repeat_byte(0xa7);
        orch.connected_peers.extend(peers);

        orch.request_h2_v4_gov5_block(peers[0], block_hash);
        let first = prx.try_recv().expect("initial fetch command");
        assert!(matches!(
            first,
            NetworkCommand::RequestGov5BlockByHash { peer, block_hash: hash }
                if peer == peers[0] && hash == block_hash
        ));
        orch.h2_v4_fetch_requested_at.insert(
            block_hash,
            (
                Instant::now() - H2_V4_FETCH_RETRY_TIMEOUT - Duration::from_secs(1),
                peers[0],
            ),
        );

        orch.retry_expired_h2_v4_fetches();

        let retry = prx.try_recv().expect("deadline retry command");
        let NetworkCommand::RequestGov5BlockByHash {
            peer: second_peer,
            block_hash: second_hash,
        } = retry
        else {
            panic!("expected block fetch retry command")
        };
        assert_ne!(second_peer, peers[0]);
        assert_eq!(second_hash, block_hash);
        assert_eq!(
            orch.h2_v4_fetch_requested_at
                .get(&block_hash)
                .map(|(_, peer)| *peer),
            Some(second_peer)
        );

        orch.h2_v4_fetch_requested_at.insert(
            block_hash,
            (
                Instant::now() - H2_V4_FETCH_RETRY_TIMEOUT - Duration::from_secs(1),
                second_peer,
            ),
        );
        orch.retry_expired_h2_v4_fetches();
        let third = prx.try_recv().expect("second deadline retry command");
        assert!(matches!(
            third,
            NetworkCommand::RequestGov5BlockByHash { peer, block_hash: hash }
                if peer != peers[0] && peer != second_peer && hash == block_hash
        ));
    }

    #[tokio::test]
    async fn staged_h2_parent_does_not_start_an_overlapping_ancestry_walk() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, mut prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        let peer = libp2p::PeerId::random();
        let staged_hash = B256::repeat_byte(0xa8);
        let staged_height = 42;
        orch.h2_v4_block_numbers.insert(staged_hash, staged_height);
        orch.h2_v4_catchup_blocks
            .insert(staged_height, (peer, vec![0x42], 43));

        orch.request_h2_v4_gov5_block(peer, staged_hash);

        assert!(
            prx.try_recv().is_err(),
            "an already-staged hash must not recursively walk the same ancestry"
        );
        assert!(!orch.h2_v4_fetch_requested_at.contains_key(&staged_hash));
    }

    #[tokio::test]
    async fn expired_state_sync_yields_to_execution_catchup_fanout() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        let peers = [libp2p::PeerId::random(), libp2p::PeerId::random()];
        orch.connected_peers.extend(peers);

        orch.sync_in_flight = true;
        orch.sync_started_at =
            Some(Instant::now() - state_mgmt::sync_request_timeout() - Duration::from_secs(1));
        orch.sync_request_range = Some((88, 89));
        orch.sync_requested_peers.insert(peers[0]);

        orch.initiate_execution_catchup_sync(86, 116);

        assert!(orch.sync_in_flight, "catch-up request should be in flight");
        assert_eq!(orch.sync_request_range, Some((87, 116)));
        assert_eq!(
            orch.sync_requested_peers,
            peers.into_iter().collect(),
            "execution catch-up must replace the stale request and fan out"
        );
        let started = orch.sync_started_at.expect("sync_started_at should be set");
        assert!(
            started.elapsed() < Duration::from_secs(2),
            "sync_started_at should belong to the replacement request"
        );
    }

    // === gov5 execution pull (devlog-142 stall follow-up) ===

    /// Both network channels: `RequestSync` travels on the ordinary command
    /// channel, `RequestGov5BlockByHash` on the priority channel.
    struct TestNetworkRx {
        cmd_rx: mpsc::Receiver<NetworkCommand>,
        prx: mpsc::Receiver<NetworkCommand>,
    }

    fn gov5_lag_orchestrator(
        gov5: bool,
    ) -> (ConsensusService, TestNetworkRx, libp2p::PeerId, B256) {
        let (engine, output_rx) = make_test_engine();
        let (network, cmd_rx, prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        if gov5 {
            orch = orch.with_h2_v4_participant(test_h2_identity());
        }
        let peer = libp2p::PeerId::random();
        orch.connected_peers.insert(peer);
        // Execution validated view 10 at head 0xAA; the fleet committed view 12
        // whose body never reached this member (`pending_data=false`).
        orch.execution_validated_head_view = 10;
        orch.head_block_hash = B256::repeat_byte(0xAA);
        orch.head_block_number = 13_562_197;
        let committed_hash = B256::repeat_byte(0xC1);
        orch.async_commit_states.insert(
            12,
            AsyncCommitState {
                view: 12,
                block_hash: committed_hash,
                commit_qc: QuorumCertificate::genesis(),
                stage: AsyncCommitStage::Committed,
                finalize_in_flight: false,
                committed_at: Instant::now(),
            },
        );
        (orch, TestNetworkRx { cmd_rx, prx }, peer, committed_hash)
    }

    fn drain_commands(rx: &mut TestNetworkRx) -> Vec<NetworkCommand> {
        let mut out = Vec::new();
        while let Ok(command) = rx.cmd_rx.try_recv() {
            out.push(command);
        }
        while let Ok(command) = rx.prx.try_recv() {
            out.push(command);
        }
        out
    }

    fn counter_value(
        snapshotter: &metrics_util::debugging::Snapshotter,
        name: &str,
        label: (&str, &str),
    ) -> u64 {
        snapshotter
            .snapshot()
            .into_vec()
            .into_iter()
            .find_map(|(key, _, _, value)| {
                let key = key.key();
                (key.name() == name
                    && key
                        .labels()
                        .any(|l| l.key() == label.0 && l.value() == label.1))
                .then_some(match value {
                    DebugValue::Counter(count) => count,
                    _ => 0,
                })
            })
            .unwrap_or(0)
    }

    /// The commit-execution deadline (the trigger seen in the 06:27 stall)
    /// must pull the committed block by hash from a gov5 peer, not fan out an
    /// N42 state-sync that no gov5 member answers.
    #[tokio::test(flavor = "current_thread")]
    async fn gov5_execution_lag_pulls_by_hash_and_never_requests_state_sync() {
        let recorder = DebuggingRecorder::new();
        let snapshotter = recorder.snapshotter();
        let _recorder_guard = metrics::set_default_local_recorder(&recorder);
        let (mut orch, mut cmd_rx, peer, committed_hash) = gov5_lag_orchestrator(true);

        orch.handle_commit_execution_timeout(12, committed_hash);

        assert!(
            !orch.sync_in_flight,
            "gov5 members must never own an N42 state-sync request"
        );
        assert!(orch.sync_requested_peers.is_empty());
        assert!(
            orch.h2_v4_fetch_requested_at.contains_key(&committed_hash),
            "the committed block is tracked as an authenticated gov5 fetch"
        );
        let commands = drain_commands(&mut cmd_rx);
        assert_eq!(commands.len(), 1, "exactly one pull: {commands:?}");
        match &commands[0] {
            NetworkCommand::RequestGov5BlockByHash {
                peer: requested_peer,
                block_hash,
            } => {
                assert_eq!(*requested_peer, peer);
                assert_eq!(*block_hash, committed_hash);
            }
            other => panic!("expected a gov5 block-by-hash pull, got {other:?}"),
        }
        assert_eq!(
            counter_value(
                &snapshotter,
                "n42_gov5_execution_pull_started_total",
                ("reason", "execution_catchup"),
            ),
            1
        );
    }

    /// Without the gov5 profile the pre-existing recovery is untouched: the
    /// deadline fans out the N42 execution catch-up request.
    #[tokio::test(flavor = "current_thread")]
    async fn standard_profile_execution_lag_still_uses_state_sync() {
        let (mut orch, mut cmd_rx, _peer, committed_hash) = gov5_lag_orchestrator(false);

        orch.handle_commit_execution_timeout(12, committed_hash);

        assert!(
            orch.sync_in_flight,
            "standard profile keeps the state-sync fan-out"
        );
        assert!(orch.h2_v4_fetch_requested_at.is_empty());
        let commands = drain_commands(&mut cmd_rx);
        assert!(
            matches!(commands.as_slice(), [NetworkCommand::RequestSync { .. }]),
            "expected one state-sync request, got {commands:?}"
        );
    }

    /// Every sync entry point (execution catch-up, state sync, the per-view
    /// re-arm) converges on one outstanding pull per target hash.
    #[tokio::test(flavor = "current_thread")]
    async fn gov5_execution_pull_is_not_duplicated_while_in_flight() {
        let (mut orch, mut cmd_rx, _peer, committed_hash) = gov5_lag_orchestrator(true);

        assert!(orch.initiate_gov5_execution_pull("execution_catchup"));
        orch.initiate_execution_catchup_sync(10, 12);
        orch.initiate_sync(10, 12);
        assert!(
            orch.initiate_gov5_execution_pull("state_sync"),
            "still in flight"
        );
        orch.rearm_gov5_execution_pull();
        orch.handle_view_changed(13).await;

        assert!(!orch.sync_in_flight);
        assert_eq!(orch.h2_v4_fetch_requested_at.len(), 1);
        assert_eq!(
            orch.gov5_execution_pull_rounds, 1,
            "one peer draw for one pull"
        );
        let commands = drain_commands(&mut cmd_rx);
        let pulls = commands
            .iter()
            .filter(|command| {
                matches!(
                    command,
                    NetworkCommand::RequestGov5BlockByHash { block_hash, .. } if *block_hash == committed_hash
                )
            })
            .count();
        assert_eq!(
            pulls, 1,
            "one network pull for one in-flight target: {commands:?}"
        );
        assert!(
            !commands
                .iter()
                .any(|command| matches!(command, NetworkCommand::RequestSync { .. })),
            "no state-sync under the gov5 profile: {commands:?}"
        );
    }

    /// The pull targets the newest authenticated block above the execution
    /// head (its ancestry walk covers everything below it), and nothing is
    /// pulled once execution has caught up.
    #[tokio::test(flavor = "current_thread")]
    async fn gov5_execution_pull_targets_newest_authenticated_block_and_stops_when_caught_up() {
        let (mut orch, mut cmd_rx, _peer, committed_hash) = gov5_lag_orchestrator(true);
        let newer_hash = B256::repeat_byte(0xC5);
        orch.h2_v4_block_views.insert(newer_hash, 15);
        // Parent sentinels (view 0) are never a target.
        orch.h2_v4_block_views.insert(B256::repeat_byte(0xC4), 0);
        assert_eq!(orch.gov5_execution_pull_target(), Some((newer_hash, 15)));

        orch.initiate_execution_catchup_sync(10, 15);
        let commands = drain_commands(&mut cmd_rx);
        assert!(
            matches!(
                commands.as_slice(),
                [NetworkCommand::RequestGov5BlockByHash { block_hash, .. }] if *block_hash == newer_hash
            ),
            "newest authenticated block is pulled: {commands:?}"
        );
        assert!(!orch.h2_v4_fetch_requested_at.contains_key(&committed_hash));

        // Execution reaches the fleet's head: nothing above it, no pull.
        orch.h2_v4_fetch_requested_at.clear();
        orch.execution_validated_head_view = 15;
        assert_eq!(orch.gov5_execution_pull_target(), None);
        orch.gov5_execution_pull_last_at = None;
        assert!(!orch.initiate_gov5_execution_pull("execution_catchup"));
        orch.rearm_gov5_execution_pull();
        assert!(drain_commands(&mut cmd_rx).is_empty());
    }

    /// A pull whose fetch retired without moving the execution head is
    /// re-issued on a later view change, throttled to one per fetch deadline
    /// and rotated to the next peer.
    #[tokio::test(flavor = "current_thread")]
    async fn gov5_execution_pull_rearms_on_view_change_after_the_fetch_retired() {
        let (mut orch, mut cmd_rx, first_peer, committed_hash) = gov5_lag_orchestrator(true);
        let second_peer = libp2p::PeerId::random();
        orch.connected_peers.insert(second_peer);

        orch.handle_commit_execution_timeout(12, committed_hash);
        let first = drain_commands(&mut cmd_rx);
        assert_eq!(first.len(), 1);

        // The fetch retired (deadline retry exhausted / body discarded) but
        // execution is still behind; within the throttle nothing happens.
        orch.h2_v4_fetch_requested_at.clear();
        orch.handle_view_changed(13).await;
        assert!(
            drain_commands(&mut cmd_rx).is_empty(),
            "throttled inside the fetch deadline"
        );

        orch.gov5_execution_pull_last_at =
            Some(Instant::now() - H2_V4_FETCH_RETRY_TIMEOUT - Duration::from_millis(1));
        orch.handle_view_changed(14).await;
        let second = drain_commands(&mut cmd_rx);
        let peers_used: Vec<_> = first
            .iter()
            .chain(second.iter())
            .filter_map(|command| match command {
                NetworkCommand::RequestGov5BlockByHash { peer, block_hash }
                    if *block_hash == committed_hash =>
                {
                    Some(*peer)
                }
                _ => None,
            })
            .collect();
        assert_eq!(peers_used.len(), 2, "re-armed exactly once: {second:?}");
        assert_ne!(
            peers_used[0], peers_used[1],
            "the re-arm rotates to the other peer"
        );
        assert!(peers_used.contains(&first_peer) && peers_used.contains(&second_peer));
        assert!(!orch.sync_in_flight);
    }

    #[test]
    fn executed_h2_history_cannot_exhaust_the_bounded_catchup_suffix() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        let peer = n42_network::PeerId::random();

        for height in 1..=2048 {
            orch.h2_v4_catchup_blocks
                .insert(height, (peer, vec![height as u8], height));
        }
        orch.h2_v4_catchup_active = true;
        orch.head_block_number = 1600;
        orch.prune_executed_h2_v4_catchup_history();

        assert_eq!(orch.h2_v4_catchup_blocks.len(), 448);
        assert_eq!(orch.h2_v4_last_pruned_head_block_number, Some(1600));
        assert_eq!(
            orch.h2_v4_catchup_blocks
                .first_key_value()
                .map(|(height, _)| *height),
            Some(1601)
        );
        assert!(orch.h2_v4_catchup_active);

        orch.h2_v4_catchup_blocks
            .insert(1500, (peer, vec![0xff], 1500));
        orch.prune_executed_h2_v4_catchup_history();
        assert!(!orch.h2_v4_catchup_blocks.contains_key(&1500));

        orch.head_block_number = 2048;
        orch.prune_executed_h2_v4_catchup_history();
        assert!(orch.h2_v4_catchup_blocks.is_empty());
        assert!(!orch.h2_v4_catchup_active);
    }

    #[test]
    fn h2_catchup_buffer_keeps_the_conservative_default() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx)
            .with_h2_v4_catchup_buffer_blocks(DEFAULT_H2_V4_CATCHUP_BUFFER_BLOCKS);
        let peer = n42_network::PeerId::random();

        for height in 1..=DEFAULT_H2_V4_CATCHUP_BUFFER_BLOCKS {
            orch.h2_v4_catchup_blocks
                .insert(height as u64, (peer, vec![height as u8], height as u64));
        }

        assert!(!orch.stage_h2_v4_catchup_block(peer, vec![0xff], 2049, 3049, true));
        assert_eq!(
            orch.h2_v4_catchup_blocks.len(),
            DEFAULT_H2_V4_CATCHUP_BUFFER_BLOCKS
        );
    }

    #[test]
    fn h2_catchup_buffer_can_be_explicitly_expanded_but_remains_hard_capped() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx)
            .with_h2_v4_catchup_buffer_blocks(4096);
        let peer = n42_network::PeerId::random();

        for height in 1..=DEFAULT_H2_V4_CATCHUP_BUFFER_BLOCKS {
            orch.h2_v4_catchup_blocks
                .insert(height as u64, (peer, vec![height as u8], height as u64));
        }

        assert!(orch.stage_h2_v4_catchup_block(peer, vec![0xff], 2049, 3049, true));
        assert_eq!(orch.h2_v4_catchup_blocks.len(), 2049);
        assert_eq!(
            orch.h2_v4_catchup_blocks
                .get(&2049)
                .map(|(_, _, authenticated_view)| *authenticated_view),
            Some(3049)
        );

        orch = orch.with_h2_v4_catchup_buffer_blocks(usize::MAX);
        assert_eq!(
            orch.h2_v4_catchup_buffer_blocks,
            MAX_H2_V4_CATCHUP_BUFFER_BLOCKS
        );
    }

    #[test]
    fn long_h2_catchup_retains_views_after_live_binding_eviction() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx)
            .with_h2_v4_catchup_buffer_blocks(4096);
        let source = n42_network::PeerId::random();
        let mut parent = B256::repeat_byte(0x61);
        orch.head_block_hash = parent;

        for height in 1..=2049_u64 {
            let view = height + 100;
            let (hash, rlp) = test_gov5_block_rlp(parent, height, view);
            orch.h2_v4_catchup_blocks
                .insert(height, (source, rlp, view));
            orch.remember_h2_v4_block_view(hash, view);
            parent = hash;
        }
        orch.h2_v4_catchup_active = true;

        assert_eq!(orch.h2_v4_block_views.len(), 2048);
        assert_eq!(
            orch.ready_h2_v4_catchup_heights(),
            Some((1..=2049).collect())
        );
        assert_eq!(
            orch.h2_v4_catchup_blocks
                .get(&1)
                .map(|(_, _, authenticated_view)| *authenticated_view),
            Some(101)
        );
    }

    #[test]
    fn bound_h2_bodies_are_released_in_execution_height_order() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        let source = n42_network::PeerId::random();
        let mut parent = B256::repeat_byte(0x70);
        let mut expected = Vec::new();

        for (height, view) in [(101, 201), (102, 202), (103, 203)] {
            let (hash, rlp) = test_gov5_block_rlp(parent, height, view);
            orch.h2_v4_unbound_blocks.insert(hash, (source, rlp));
            orch.h2_v4_block_views.insert(hash, view);
            expected.push(hash);
            parent = hash;
        }

        assert_eq!(
            orch.ready_h2_v4_bound_blocks_in_height_order(),
            expected,
            "a hash-keyed body cache must still release canonical ancestry by height"
        );
    }

    #[test]
    fn full_h2_binding_cache_evicts_oldest_not_new_low_hash() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        let mut oldest = B256::ZERO;

        for index in 0..2048_u64 {
            let mut bytes = [0xf0; 32];
            bytes[24..].copy_from_slice(&index.to_be_bytes());
            let hash = B256::from(bytes);
            if index == 0 {
                oldest = hash;
            }
            orch.remember_h2_v4_block_view(hash, index + 1);
        }

        let live_low_hash = B256::repeat_byte(0x05);
        orch.remember_h2_v4_block_view(live_low_hash, 4096);

        assert_eq!(orch.h2_v4_block_views.len(), 2048);
        assert!(
            orch.h2_v4_block_views.contains_key(&live_low_hash),
            "a newly authenticated low-valued hash must not evict itself"
        );
        assert!(
            !orch.h2_v4_block_views.contains_key(&oldest),
            "capacity eviction must remove the oldest binding"
        );
        let mut second_bytes = [0xf0; 32];
        second_bytes[24..].copy_from_slice(&1_u64.to_be_bytes());
        assert_eq!(
            orch.h2_v4_block_view_order.front().copied(),
            Some(B256::from(second_bytes))
        );
        assert_eq!(
            orch.h2_v4_block_view_order.back().copied(),
            Some(live_low_hash)
        );
    }

    #[test]
    fn direct_h2_successor_is_staged_before_a_later_child_activates_catchup() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        let source = n42_network::PeerId::random();
        orch.head_block_number = 100;

        assert!(orch.stage_h2_v4_catchup_block(source, vec![0x01], 101, 201, false));
        assert!(!orch.h2_v4_catchup_active);
        assert!(orch.stage_h2_v4_catchup_block(source, vec![0x02], 102, 202, true));
        assert!(orch.h2_v4_catchup_active);
        assert_eq!(
            orch.h2_v4_catchup_blocks
                .keys()
                .copied()
                .collect::<Vec<_>>(),
            vec![101, 102],
            "the first missing parent must remain available when its child reveals the gap"
        );

        orch.head_block_number = 101;
        orch.prune_executed_h2_v4_catchup_history();
        assert_eq!(
            orch.h2_v4_catchup_blocks
                .keys()
                .copied()
                .collect::<Vec<_>>(),
            vec![102]
        );
    }

    #[test]
    fn staged_h2_successor_becomes_releasable_when_async_parent_advances_head() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        let source = n42_network::PeerId::random();
        let old_head = B256::repeat_byte(0x60);
        let (parent_hash, _parent_rlp) = test_gov5_block_rlp(old_head, 101, 201);
        let (successor_hash, successor_rlp) = test_gov5_block_rlp(parent_hash, 102, 202);
        orch.head_block_hash = old_head;
        orch.head_block_number = 100;
        orch.remember_h2_v4_block_view(successor_hash, 202);

        assert!(orch.stage_h2_v4_catchup_block(source, successor_rlp, 102, 202, true));
        assert_eq!(
            orch.ready_h2_v4_catchup_heights(),
            None,
            "the successor must wait while its parent is still executing"
        );

        // This models the asynchronous parent new_payload/FCU completion that
        // previously left the already-buffered successor stranded forever.
        orch.head_block_hash = parent_hash;
        orch.head_block_number = 101;
        orch.prune_executed_h2_v4_catchup_history();

        assert_eq!(
            orch.ready_h2_v4_catchup_heights(),
            Some(vec![102]),
            "moving the durable head to the parent must release the staged successor"
        );
    }

    #[test]
    fn test_prev_randao_from_commit_qc() {
        use alloy_primitives::keccak256;

        // No commit QC → B256::ZERO
        let none_qc: Option<&QuorumCertificate> = None;
        let randao = none_qc
            .map(|qc| keccak256(qc.aggregate_signature.to_bytes()))
            .unwrap_or(B256::ZERO);
        assert_eq!(randao, B256::ZERO);

        // With commit QC → deterministic non-zero
        let qc = QuorumCertificate::genesis();
        let r1 = keccak256(qc.aggregate_signature.to_bytes());
        let r2 = keccak256(qc.aggregate_signature.to_bytes());
        assert_eq!(r1, r2, "must be deterministic");
    }

    #[test]
    fn test_with_recovered_commit_qc_restores_prev_randao() {
        use alloy_primitives::keccak256;

        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);

        // Before recovery: prev_randao_cache is ZERO
        assert_eq!(orch.prev_randao_cache, B256::ZERO);

        // After recovery: prev_randao_cache matches QC hash
        let qc = QuorumCertificate::genesis();
        let expected = keccak256(qc.aggregate_signature.to_bytes());
        let orch = orch.with_recovered_commit_qc(qc);
        assert_eq!(orch.prev_randao_cache, expected);
        assert!(orch.last_commit_qc.is_some());
    }

    #[test]
    fn recovered_head_timestamp_keeps_first_build_above_durable_parent() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx)
            .with_recovered_head_timestamp(2_000_000_000);
        let attrs = orch.build_payload_attributes(Some(1_900_000_000), B256::ZERO);
        assert_eq!(attrs.timestamp, 2_000_000_001);
        let mut orch = orch.with_recovered_head_timestamp(1);
        assert_eq!(
            orch.build_payload_attributes(Some(1), B256::ZERO).timestamp,
            2_000_000_001
        );
    }

    #[test]
    fn test_connected_validator_peer_count() {
        let (engine, output_rx) = make_test_engine_with_validator_count(2, 0);
        let mock_peers = vec![
            (0u32, Keypair::generate_ed25519().public().to_peer_id()),
            (1u32, Keypair::generate_ed25519().public().to_peer_id()),
        ];
        let network = Arc::new(MockConsensusNetwork::with_peers(mock_peers.clone()));
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, network, net_event_rx, output_rx);

        let non_validator = Keypair::generate_ed25519().public().to_peer_id();
        orch.connected_peers.insert(non_validator);
        orch.connected_peers.insert(mock_peers[0].1);
        orch.connected_peers.insert(mock_peers[1].1);

        assert_eq!(orch.connected_validator_peer_count(), 2);
    }

    #[test]
    fn test_has_quorum_peers() {
        let (engine, output_rx) = make_test_engine_with_validator_count(7, 1);
        let mock_peers = (0..7)
            .map(|idx| {
                (
                    idx as u32,
                    Keypair::generate_ed25519().public().to_peer_id(),
                )
            })
            .collect::<Vec<_>>();
        let network = Arc::new(MockConsensusNetwork::with_peers(mock_peers.clone()));
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, network, net_event_rx, output_rx);

        orch.connected_peers.insert(mock_peers[0].1);
        orch.connected_peers.insert(mock_peers[1].1);
        orch.connected_peers.insert(mock_peers[2].1);

        assert!(!orch.has_quorum_peers());
        orch.connected_peers.insert(mock_peers[4].1);
        assert!(orch.has_quorum_peers());
    }

    #[test]
    fn test_quorum_peers_needed_uses_engine_quorum() {
        let (engine, output_rx) = make_test_engine_with_fault_tolerance(7, 1, 1);
        let mock_peers = (0..7)
            .map(|idx| {
                (
                    idx as u32,
                    Keypair::generate_ed25519().public().to_peer_id(),
                )
            })
            .collect::<Vec<_>>();
        let network = Arc::new(MockConsensusNetwork::with_peers(mock_peers.clone()));
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, network, net_event_rx, output_rx);

        assert_eq!(orch.quorum_peers_needed(), 5);
        for (_, peer_id) in mock_peers.iter().take(4) {
            orch.connected_peers.insert(*peer_id);
        }
        assert!(!orch.has_quorum_peers());
        orch.connected_peers.insert(mock_peers[4].1);
        assert!(orch.has_quorum_peers());
    }

    #[test]
    fn test_quorum_peers_needed_single_validator() {
        let (engine, output_rx) = make_test_engine_with_validator_count(1, 0);
        let network = Arc::new(MockConsensusNetwork::default());
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let orch = ConsensusService::new(engine, network, net_event_rx, output_rx);
        assert_eq!(orch.quorum_peers_needed(), 0);
        assert!(orch.has_quorum_peers());
    }

    #[test]
    fn test_quorum_peers_needed_zero_fault_multi_validator() {
        let (engine, output_rx) = make_test_engine_with_fault_tolerance(3, 1, 0);
        let network = Arc::new(MockConsensusNetwork::default());
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let orch = ConsensusService::new(engine, network, net_event_rx, output_rx);
        assert_eq!(orch.quorum_peers_needed(), 2);
        assert!(!orch.has_quorum_peers());
    }

    #[tokio::test]
    async fn test_startup_leader_gate_waits_for_validator_quorum() {
        let (engine, output_rx) = make_test_engine_with_validator_count(7, 1);
        let mock_peers = (0..7)
            .map(|idx| {
                (
                    idx as u32,
                    Keypair::generate_ed25519().public().to_peer_id(),
                )
            })
            .collect::<Vec<_>>();
        let network = Arc::new(MockConsensusNetwork::with_peers(mock_peers.clone()));
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, network, net_event_rx, output_rx);

        orch.begin_leader_build_wait(LeaderBuildWaitMode::Direct, None);

        for idx in 0..3 {
            orch.handle_network_event(NetworkEvent::PeerConnected(mock_peers[idx as usize].1))
                .await;
            assert!(orch.leader_build_waiting_view.is_some());
        }
        orch.handle_network_event(NetworkEvent::PeerConnected(mock_peers[3].1))
            .await;
        assert!(orch.leader_build_waiting_view.is_none());
    }

    #[tokio::test]
    async fn test_startup_leader_gate_honors_warmup_floor_after_quorum() {
        let (engine, output_rx) = make_test_engine_with_validator_count(7, 1);
        let mock_peers = (0..7)
            .map(|idx| {
                (
                    idx as u32,
                    Keypair::generate_ed25519().public().to_peer_id(),
                )
            })
            .collect::<Vec<_>>();
        let network = Arc::new(MockConsensusNetwork::with_peers(mock_peers.clone()));
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, network, net_event_rx, output_rx);
        let view = orch.engine.current_view();

        orch.begin_leader_build_wait(LeaderBuildWaitMode::Direct, None);
        orch.leader_build_not_before = Some((view, Instant::now() + Duration::from_secs(60)));

        for (_, peer_id) in mock_peers.iter().take(4) {
            orch.handle_network_event(NetworkEvent::PeerConnected(*peer_id))
                .await;
        }

        assert_eq!(
            orch.leader_build_waiting_view,
            Some((view, LeaderBuildWaitMode::Direct))
        );
        assert!(orch.leader_build_not_before.is_some());
        assert!(orch.next_build_at.is_some());

        orch.leader_build_not_before = Some((view, Instant::now()));
        orch.evaluate_leader_build_wait(None).await;

        assert!(orch.leader_build_waiting_view.is_none());
        assert!(orch.leader_build_not_before.is_none());
    }

    #[test]
    fn test_leader_build_timer_rearms_direct_wait_after_scheduled_gate_clears() {
        let (engine, output_rx) = make_test_engine_with_validator_count(7, 1);
        let network = Arc::new(MockConsensusNetwork::default());
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, network, net_event_rx, output_rx);

        assert!(orch.leader_build_waiting_view.is_none());

        orch.arm_leader_build_timer_as_direct_wait(Some(12345));

        assert_eq!(
            orch.leader_build_waiting_view,
            Some((orch.engine.current_view(), LeaderBuildWaitMode::Direct))
        );
        assert_eq!(orch.next_slot_timestamp, Some(12345));
    }

    #[test]
    fn test_leader_build_timer_preserves_existing_wait_mode() {
        let (engine, output_rx) = make_test_engine_with_validator_count(7, 1);
        let network = Arc::new(MockConsensusNetwork::default());
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, network, net_event_rx, output_rx);

        orch.begin_leader_build_wait(LeaderBuildWaitMode::Scheduled, None);
        orch.arm_leader_build_timer_as_direct_wait(None);

        assert_eq!(
            orch.leader_build_waiting_view,
            Some((orch.engine.current_view(), LeaderBuildWaitMode::Scheduled))
        );
    }

    /// Counting StateSink: records every applied diff (Task 2 spy).
    struct SpyStateSink {
        applies: Arc<Mutex<Vec<usize>>>, // account counts per apply
    }

    impl SpyStateSink {
        fn new() -> (Arc<Self>, Arc<Mutex<Vec<usize>>>) {
            let applies = Arc::new(Mutex::new(Vec::new()));
            (
                Arc::new(Self {
                    applies: Arc::clone(&applies),
                }),
                applies,
            )
        }
    }

    impl crate::sinks::StateSink for SpyStateSink {
        fn apply_diff(
            &self,
            _block_hash: B256,
            diff: &n42_execution::state_diff::StateDiff,
        ) -> Result<(u64, B256), String> {
            self.applies.lock().expect("spy sink lock").push(diff.len());
            Ok((1, B256::repeat_byte(0xAB)))
        }
    }

    async fn drain_spawned_tasks() {
        // The sidecar worker runs the sink on spawn_blocking; yield until
        // the pool has run it.
        for _ in 0..20 {
            tokio::task::yield_now().await;
        }
        tokio::time::sleep(Duration::from_millis(50)).await;
    }

    /// Task 2: a committed block whose execution reth REJECTS must never reach
    /// the sidecar state trees; the rejected diff is discarded, and the sink
    /// records zero applies.
    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn sidecar_diff_withheld_when_execution_rejected() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let previous_head = B256::repeat_byte(0x11);
        let bad_hash = B256::repeat_byte(0xDD);
        let mock_el = Arc::new(MockExecutionLayer::new(
            PayloadStatusEnum::Invalid {
                validation_error: "stale nonce".to_string(),
            },
            PayloadStatusEnum::Syncing,
        ));
        let (sink, applies) = SpyStateSink::new();
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.el = Some(mock_el);
        orch.jmt = Some(sink);
        orch.head_block_hash = previous_head;
        orch.async_finalize_fcu = false;
        orch.pending_block_data
            .insert(bad_hash, test_block_data(previous_head, bad_hash, 1).into());
        // The broadcast fixture carries no execution output, so stage the diff
        // directly - the staging/flush timing is what this test pins down.
        orch.pending_sidecar_diffs.insert(
            1,
            (bad_hash, n42_execution::state_diff::StateDiff::default()),
        );

        orch.handle_engine_output(EngineOutput::BlockCommitted {
            view: 1,
            block_hash: bad_hash,
            commit_qc: QuorumCertificate::genesis(),
            validator_changes: None,
        })
        .await;
        orch.handle_commit_execution_timeout(1, bad_hash);
        let (hash, view, outcome, ts) =
            tokio::time::timeout(Duration::from_secs(2), orch.import_done_rx.recv())
                .await
                .expect("bg import finishes")
                .expect("channel open");
        assert_eq!(outcome, ImportOutcome::Invalid);
        orch.handle_import_done(hash, view, outcome, ts).await;
        drain_spawned_tasks().await;

        assert!(
            applies.lock().unwrap().is_empty(),
            "sidecar sink must not see a diff for an execution-rejected block"
        );
        assert!(
            orch.pending_sidecar_diffs.is_empty(),
            "a rejected block's staged diff must be discarded"
        );
    }

    /// Task 2 happy path: once execution IS confirmed (head advances to the
    /// block), the staged diff is applied exactly once.
    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn sidecar_diff_applied_once_after_confirmation() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let good_hash = B256::repeat_byte(0x22);
        let (sink, applies) = SpyStateSink::new();
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.jmt = Some(sink);
        orch.pending_sidecar_diffs.insert(
            1,
            (good_hash, n42_execution::state_diff::StateDiff::default()),
        );

        orch.advance_execution_validated_head(1, good_hash, "test confirmation");
        drain_spawned_tasks().await;
        assert_eq!(
            applies.lock().unwrap().len(),
            1,
            "confirmed block applies its staged diff exactly once"
        );
        assert!(orch.pending_sidecar_diffs.is_empty());

        // A second confirmation of the same hash is a no-op (diff consumed).
        orch.advance_execution_validated_head(1, good_hash, "duplicate confirmation");
        drain_spawned_tasks().await;
        assert_eq!(applies.lock().unwrap().len(), 1);
    }

    /// F8: a missing committed diff is an ordering barrier. A later confirmed
    /// diff waits, then both apply in order once late BlockData repairs the gap.
    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn sidecar_missing_diff_pauses_and_late_block_data_recovers_in_order() {
        use n42_execution::state_diff::{AccountChangeType, AccountDiff, StateDiff};

        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let (sink, applies) = SpyStateSink::new();
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.jmt = Some(sink);

        let parent = B256::repeat_byte(0x30);
        let missing_hash = B256::repeat_byte(0x31);
        let later_hash = B256::repeat_byte(0x32);
        orch.missing_sidecar_diffs.insert(1, missing_hash);
        let mut later_diff = StateDiff::default();
        for index in 0..2u8 {
            later_diff.accounts.insert(
                Address::with_last_byte(index + 1),
                AccountDiff {
                    change_type: AccountChangeType::Created,
                    balance: None,
                    nonce: None,
                    code_change: None,
                    storage: BTreeMap::new(),
                },
            );
        }
        orch.pending_sidecar_diffs
            .insert(2, (later_hash, later_diff));

        orch.advance_execution_validated_head(1, missing_hash, "confirm missing diff hash");
        orch.advance_execution_validated_head(2, later_hash, "confirm across missing diff");
        drain_spawned_tasks().await;
        assert!(
            applies.lock().unwrap().is_empty(),
            "view 2 must not apply across the missing view 1 diff"
        );
        assert!(orch.pending_sidecar_diffs.contains_key(&2));

        let late_data = test_block_data_with_empty_execution(parent, missing_hash, 1);
        orch.cache_pending_block_data(missing_hash, late_data, &[missing_hash]);
        drain_spawned_tasks().await;

        assert_eq!(
            *applies.lock().unwrap(),
            vec![0, 2],
            "recovered view 1 must apply before the already-confirmed view 2"
        );
        assert!(orch.missing_sidecar_diffs.is_empty());
        assert!(orch.pending_sidecar_diffs.is_empty());
    }

    #[test]
    fn asynchronous_state_diff_completion_closes_committed_gap() {
        use n42_execution::state_diff::StateDiff;

        let mut orch = make_test_orchestrator_with_state(None);
        let parent = B256::repeat_byte(0x41);
        let block_hash = B256::repeat_byte(0x42);
        let data = test_block_data(parent, block_hash, 7);
        assert!(orch.cache_pending_block_data(block_hash, data, &[block_hash]));
        orch.missing_sidecar_diffs.insert(7, block_hash);

        orch.handle_state_diff_ready(block_hash, StateDiff::default());

        assert!(!orch.missing_sidecar_diffs.contains_key(&7));
        assert_eq!(
            orch.pending_sidecar_diffs.get(&7).map(|entry| entry.0),
            Some(block_hash)
        );
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn sidecar_diffs_apply_in_committed_view_order() {
        use n42_execution::state_diff::{AccountChangeType, AccountDiff, StateDiff};

        fn diff_with_accounts(count: u8) -> StateDiff {
            let mut diff = StateDiff::default();
            for index in 0..count {
                diff.accounts.insert(
                    Address::with_last_byte(index + 1),
                    AccountDiff {
                        change_type: AccountChangeType::Modified,
                        balance: None,
                        nonce: None,
                        code_change: None,
                        storage: BTreeMap::new(),
                    },
                );
            }
            diff
        }

        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let (sink, applies) = SpyStateSink::new();
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.jmt = Some(sink);
        let first_hash = B256::repeat_byte(0x23);
        let second_hash = B256::repeat_byte(0x24);
        orch.pending_sidecar_diffs
            .insert(1, (first_hash, diff_with_accounts(1)));
        orch.pending_sidecar_diffs
            .insert(2, (second_hash, diff_with_accounts(2)));

        // The later completion arrives first, but cannot authorize the staged
        // earlier hash by itself. Once the exact earlier completion arrives,
        // the worker applies both diffs in view order without regressing head.
        orch.advance_execution_validated_head(2, second_hash, "later confirmation first");
        assert!(applies.lock().unwrap().is_empty());
        orch.advance_execution_validated_head(1, first_hash, "earlier confirmation observed late");
        drain_spawned_tasks().await;

        assert_eq!(*applies.lock().unwrap(), vec![1, 2]);
        assert!(orch.pending_sidecar_diffs.is_empty());
        assert!(orch.sidecar_apply_queue.lock().unwrap().is_empty());
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn sidecar_flush_rejects_diff_for_noncanonical_hash_at_view() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let (sink, applies) = SpyStateSink::new();
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.jmt = Some(sink);
        let forged_hash = B256::repeat_byte(0x81);
        let canonical_hash = B256::repeat_byte(0x82);
        orch.pending_sidecar_diffs.insert(
            1,
            (forged_hash, n42_execution::state_diff::StateDiff::default()),
        );

        orch.advance_execution_validated_head(1, canonical_hash, "canonical import");
        drain_spawned_tasks().await;

        assert!(applies.lock().unwrap().is_empty());
        assert!(!orch.pending_sidecar_diffs.contains_key(&1));
        assert_eq!(orch.missing_sidecar_diffs.get(&1), Some(&canonical_hash));
    }

    /// F7 defense-in-depth: if an out-of-order entry ever reaches the apply
    /// queue, the single FIFO worker skips it rather than applying a lower view
    /// after a higher one (which would diverge the append-ordered root).
    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn sidecar_worker_skips_out_of_order_apply_across_worker_restarts() {
        use n42_execution::state_diff::{AccountChangeType, AccountDiff, StateDiff};

        fn diff_with_accounts(count: u8) -> StateDiff {
            let mut diff = StateDiff::default();
            for index in 0..count {
                diff.accounts.insert(
                    Address::with_last_byte(index + 1),
                    AccountDiff {
                        change_type: AccountChangeType::Modified,
                        balance: None,
                        nonce: None,
                        code_change: None,
                        storage: BTreeMap::new(),
                    },
                );
            }
            diff
        }

        // NB: the worker runs on spawn_blocking (a separate thread), so a
        // thread-local metrics recorder would not see its counter — the
        // observable `applies` order below is the assertion that matters.
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let (sink, applies) = SpyStateSink::new();
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.jmt = Some(sink);
        let hash = B256::repeat_byte(0x25);

        // First worker lifetime: normally apply view 2, then let the queue drain
        // and the worker exit.
        orch.pending_sidecar_diffs
            .insert(2, (hash, diff_with_accounts(2)));
        orch.advance_execution_validated_head(2, hash, "confirm view 2");
        drain_spawned_tasks().await;
        assert_eq!(*applies.lock().unwrap(), vec![2]);

        // Second worker lifetime: inject stale view 1 before normally-confirmed
        // view 3. A worker-local last-view variable would reset to zero here and
        // incorrectly apply [1, 3]; the shared high-water mark must skip 1.
        orch.sidecar_apply_queue
            .lock()
            .unwrap()
            .push_back((1, hash, diff_with_accounts(1)));
        orch.pending_sidecar_diffs
            .insert(3, (hash, diff_with_accounts(3)));
        orch.advance_execution_validated_head(3, hash, "confirm view 3");
        drain_spawned_tasks().await;

        assert_eq!(
            *applies.lock().unwrap(),
            vec![2, 3],
            "the out-of-order lower view must be skipped, not applied"
        );
    }

    /// Task 3: a stale pending finalization whose block the committed ring
    /// still holds re-drives the import LOCALLY - no sync round-trip for data
    /// this node already has.
    #[tokio::test]
    async fn stale_pending_finalization_redrives_from_committed_broadcast() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let head = B256::repeat_byte(0x31);
        let committed_hash = B256::repeat_byte(0x44);
        let raw = test_block_data(head, committed_hash, 3);
        let mock_el = Arc::new(MockExecutionLayer::new(
            PayloadStatusEnum::Valid,
            PayloadStatusEnum::Valid,
        ));
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.el = Some(mock_el.clone());
        orch.pending_block_data.insert(committed_hash, raw.into());
        orch.store_committed_block(3, committed_hash, QuorumCertificate::genesis(), None, &[]);
        orch.defer_finalization(3, committed_hash, QuorumCertificate::genesis());
        orch.pending_block_data.clear(); // the eviction that used to force a sync

        orch.handle_view_changed(6).await; // 3 views past the pending one

        assert!(
            orch.pending_finalization.is_none(),
            "stale pending finalization is consumed"
        );
        assert!(
            !orch.sync_in_flight,
            "locally retained broadcast must not fall back to sync"
        );
        let (hash, view, outcome, _ts) =
            tokio::time::timeout(Duration::from_secs(2), orch.import_done_rx.recv())
                .await
                .expect("local re-drive import completes")
                .expect("channel open");
        assert_eq!((hash, view), (committed_hash, 3));
        assert_eq!(
            outcome,
            ImportOutcome::Valid,
            "the retained broadcast re-imports successfully"
        );
        assert_eq!(
            mock_el.new_payload_hashes(),
            vec![committed_hash],
            "the re-drive imports the retained broadcast through new_payload"
        );
        // The block IS committed - the re-driven import legitimately finishes
        // with the commit-authorized fork-choice update (Case B semantics).
        assert_eq!(mock_el.fcu_heads(), vec![committed_hash]);
    }

    /// Task 3 fallback: with no retained broadcast the stale finalization
    /// still goes to sync (the pre-existing behavior).
    #[tokio::test]
    async fn stale_pending_finalization_without_payload_falls_back_to_sync() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let committed_hash = B256::repeat_byte(0x55);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.connected_peers.insert(n42_network::PeerId::random());
        orch.defer_finalization(3, committed_hash, QuorumCertificate::genesis());

        orch.handle_view_changed(6).await;

        assert!(orch.pending_finalization.is_none());
        assert!(
            orch.sync_in_flight,
            "no local data -> sync is the only recovery"
        );
        assert!(!orch.bg_import_hashes.contains(&committed_hash));
    }

    /// Task 5: import paths must NEVER move reth fork choice - the
    /// single-canonical-writer invariant. Passive block data import and the
    /// commit-driven finalize are driven back to back; only the finalize may
    /// produce an attribute-less FCU.
    #[tokio::test]
    async fn import_paths_never_issue_fcu() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let head = B256::repeat_byte(0x61);
        let block_hash = B256::repeat_byte(0x62);
        let mock_el = Arc::new(MockExecutionLayer::new(
            PayloadStatusEnum::Valid,
            PayloadStatusEnum::Valid,
        ));
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.el = Some(mock_el.clone());
        orch.head_block_hash = head;
        orch.async_finalize_fcu = false;

        // Passive path: block data arrives from the network.
        orch.handle_block_data(test_block_data(head, block_hash, 1))
            .await;
        assert!(
            mock_el.fcu_heads().is_empty(),
            "passive block-data import must not call forkchoiceUpdated"
        );

        // Commit-driven finalize is the ONLY canonical writer.
        orch.finalize_committed_block(1, block_hash, QuorumCertificate::genesis())
            .await;
        assert!(
            !mock_el.fcu_heads().is_empty(),
            "finalize is expected to move the fork choice"
        );
        assert_eq!(mock_el.fcu_heads(), vec![block_hash]);
    }

    // ─────────────────────────────────────────────────────────────────────
    // Restart-boundary hardening (PR #21 re-audit T1-T4)
    // ─────────────────────────────────────────────────────────────────────

    /// T2 unit: the FCU-suppression predicate refuses only backward or
    /// sideways moves; a strictly-newer view, an idempotent re-import of the
    /// same head, and the view-0 restart/genesis seed are all admissible.
    #[test]
    fn import_would_regress_head_is_backward_or_sideways_only() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        let head = B256::repeat_byte(0x22);
        orch.execution_validated_head_view = 5;
        orch.head_block_hash = head;

        assert!(
            orch.import_would_regress_head(4, B256::repeat_byte(0x33)),
            "strictly older view regresses"
        );
        assert!(
            orch.import_would_regress_head(5, B256::repeat_byte(0x33)),
            "same view, different hash is a sideways regress"
        );
        assert!(
            !orch.import_would_regress_head(5, head),
            "same view, same head is idempotent, not a regress"
        );
        assert!(
            !orch.import_would_regress_head(6, B256::repeat_byte(0x33)),
            "strictly newer view is forward"
        );

        // View 0 is the restart/genesis seed: the same-view conflict is exempt
        // so the very first advance can seed the head.
        orch.execution_validated_head_view = 0;
        assert!(!orch.import_would_regress_head(0, B256::repeat_byte(0x77)));
    }

    /// T2b core (F1): a stale block reth would accept as `Valid`, imported at a
    /// view at or below the execution-validated head, must NOT move reth fork
    /// choice backward. The guard fires ahead of the FCU side effect.
    #[tokio::test(flavor = "current_thread")]
    async fn sync_import_below_validated_head_issues_no_backward_fcu() {
        let recorder = DebuggingRecorder::new();
        let snapshotter = recorder.snapshotter();
        let _recorder_guard = metrics::set_default_local_recorder(&recorder);

        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let head = B256::repeat_byte(0x50);
        let old_hash = B256::repeat_byte(0x40);
        let mock = Arc::new(MockExecutionLayer::new(
            PayloadStatusEnum::Valid,
            PayloadStatusEnum::Valid,
        ));
        let el: Arc<dyn ExecutionLayer> = mock.clone();
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.el = Some(el);
        orch.head_block_hash = head;
        orch.execution_validated_head_view = 10;

        let broadcast = BlockDataBroadcast {
            block_hash: old_hash,
            view: 5,
            payload_json: serde_json::to_vec(&test_execution_data(head, old_hash)).unwrap(),
            timestamp: 0,
            execution_output: None,
            leader_ready_unix_ms: 0,
        };
        let _ = orch.import_and_notify(broadcast).await;

        assert!(
            mock.fcu_heads().is_empty(),
            "an import below the validated head must not fork-choice-update reth backward"
        );
        assert_eq!(
            orch.head_block_hash, head,
            "the execution-validated head must not regress"
        );
        let skipped =
            snapshotter
                .snapshot()
                .into_vec()
                .into_iter()
                .find_map(|(key, _, _, value)| {
                    (key.key().name() == "n42_import_fcu_skipped_backward_total").then_some(value)
                });
        assert_eq!(skipped, Some(DebugValue::Counter(1)));
    }

    /// T2a: a sync response block outside the requested `[from_view, to_view]`
    /// range is dropped before QC verification and never counted.
    #[tokio::test(flavor = "current_thread")]
    async fn sync_response_drops_blocks_outside_requested_range() {
        let recorder = DebuggingRecorder::new();
        let snapshotter = recorder.snapshotter();
        let _recorder_guard = metrics::set_default_local_recorder(&recorder);

        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let peer = n42_network::PeerId::random();
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.sync_request_range = Some((10, 20));
        orch.sync_requested_peers.insert(peer);
        let before = orch.committed_block_count;

        let response = n42_network::BlockSyncResponse {
            blocks: vec![n42_network::SyncBlock {
                view: 5, // below the requested [10, 20]
                block_hash: B256::repeat_byte(0x33),
                commit_qc: QuorumCertificate::genesis(),
                payload: vec![1, 2, 3], // non-empty so it is not skipped as empty
                validator_changes: None,
            }],
            peer_committed_view: 5,
            execution_lineage: Vec::new(),
        };
        orch.handle_sync_response(peer, response).await;

        assert_eq!(
            orch.committed_block_count, before,
            "an out-of-range block must not be counted"
        );
        let dropped =
            snapshotter
                .snapshot()
                .into_vec()
                .into_iter()
                .find_map(|(key, _, _, value)| {
                    (key.key().name() == "n42_sync_blocks_out_of_range_total").then_some(value)
                });
        assert_eq!(dropped, Some(DebugValue::Counter(1)));
    }

    #[test]
    fn sync_qc_rejects_old_committee_signing_future_view() {
        let (mut engine, output_rx) = make_test_engine_with_validator_count(4, 0);
        let old_keys: Vec<_> = (0..4).map(test_key).collect();
        let old_set = engine.epoch_manager().current_validator_set().clone();
        *engine.epoch_manager_mut() = EpochManager::with_epoch_length(old_set.clone(), 10);

        let next_infos = (0..5)
            .map(|i| {
                let key = test_key(0x80 + i);
                ValidatorInfo {
                    address: Address::with_last_byte(0x80 + i),
                    bls_public_key: key.public_key(),
                    p2p_peer_id: None,
                }
            })
            .collect::<Vec<_>>();
        engine
            .epoch_manager_mut()
            .stage_next_epoch(&next_infos, 1)
            .unwrap();
        assert!(engine.epoch_manager_mut().advance_epoch());

        let block_hash = B256::repeat_byte(0xA9);
        let message =
            n42_consensus::protocol::quorum::commit_signing_message(11, &block_hash, &B256::ZERO);
        let signatures = old_keys[..3]
            .iter()
            .map(|key| key.sign(&message))
            .collect::<Vec<_>>();
        let signature_refs = signatures.iter().collect::<Vec<_>>();
        let aggregate_signature =
            n42_primitives::bls::AggregateSignature::aggregate(&signature_refs).unwrap();
        let mut signers = QuorumCertificate::genesis().signers;
        signers.resize(4, false);
        for index in 0..3 {
            signers.set(index, true);
        }
        let commit_qc = QuorumCertificate {
            view: 11,
            block_hash,
            aggregate_signature,
            signers,
        };

        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let service = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        let block = n42_network::SyncBlock {
            view: 11,
            block_hash,
            commit_qc,
            payload: vec![1],
            validator_changes: None,
        };

        assert!(
            !service.verify_sync_block_qc(&block),
            "a cryptographically valid old committee is not authorized at the future view"
        );
    }

    /// A CommitQC child can finalize a prepared execution ancestor that has no
    /// CommitQC of its own. Restart recovery must import both raw payloads in
    /// parent order, preserve their compact outputs for later peers, advance
    /// the real execution block number, and apply both Twig/QMDB sidecars.
    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn sync_recovers_prepared_ancestor_execution_lineage() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let peer = n42_network::PeerId::random();
        let durable_head = B256::repeat_byte(0x43);
        let prepared_hash = B256::repeat_byte(0x44);
        let committed_hash = B256::repeat_byte(0x45);
        let prepared_data =
            test_block_data_with_empty_execution_at_number(durable_head, prepared_hash, 2, 144);
        let committed_data =
            test_block_data_with_empty_execution_at_number(prepared_hash, committed_hash, 3, 145);
        let committed_broadcast: BlockDataBroadcast =
            bincode::deserialize(&committed_data).expect("test broadcast decodes");
        let mock = Arc::new(MockExecutionLayer::with_fcu_statuses(
            PayloadStatusEnum::Valid,
            [PayloadStatusEnum::Valid, PayloadStatusEnum::Valid],
        ));
        let el: Arc<dyn ExecutionLayer> = mock.clone();
        let (twig, applies) = SpyStateSink::new();
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx)
            .with_twig(twig);
        orch.el = Some(el);
        orch.head_block_hash = durable_head;
        orch.execution_validated_head_view = 1;
        orch.committed_block_count = 143;
        orch.sync_in_flight = true;
        orch.sync_started_at = Some(Instant::now());
        orch.sync_request_range = Some((2, 3));
        orch.sync_requested_peers.insert(peer);

        orch.handle_sync_response(
            peer,
            n42_network::BlockSyncResponse {
                blocks: vec![n42_network::SyncBlock {
                    view: 3,
                    block_hash: committed_hash,
                    commit_qc: test_commit_qc(3, committed_hash),
                    payload: committed_broadcast.payload_json.clone(),
                    validator_changes: None,
                }],
                peer_committed_view: 3,
                execution_lineage: vec![
                    n42_network::SyncPayload {
                        view: 2,
                        block_hash: prepared_hash,
                        block_data: prepared_data,
                    },
                    n42_network::SyncPayload {
                        view: 3,
                        block_hash: committed_hash,
                        block_data: committed_data,
                    },
                ],
            },
        )
        .await;
        drain_spawned_tasks().await;

        assert_eq!(
            mock.new_payload_hashes(),
            vec![prepared_hash, committed_hash],
            "reth receives the prepared ancestor before its CommitQC child"
        );
        assert_eq!(mock.fcu_heads(), vec![prepared_hash, committed_hash]);
        assert_eq!(orch.head_block_hash, committed_hash);
        assert_eq!(orch.execution_validated_head_view, 3);
        assert_eq!(
            orch.committed_block_count, 145,
            "metadata follows the execution payload number, not CommitQC count"
        );
        let retained = orch
            .committed_blocks
            .back()
            .expect("synced committed block retained");
        assert_eq!(retained.execution_lineage.len(), 2);
        assert_eq!(retained.execution_lineage[0].block_hash, prepared_hash);
        assert_eq!(retained.execution_lineage[1].block_hash, committed_hash);
        assert_eq!(
            applies.lock().expect("spy sink lock").len(),
            2,
            "both execution StateDiffs reach the binary-tree sidecar"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn sync_does_not_trust_raw_lineage_that_misses_exact_head() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let peer = n42_network::PeerId::random();
        let exact_head = B256::repeat_byte(0x63);
        let foreign_parent = B256::repeat_byte(0x99);
        let prepared_hash = B256::repeat_byte(0x64);
        let committed_hash = B256::repeat_byte(0x65);
        let prepared_data = test_block_data_at_number(foreign_parent, prepared_hash, 2, 144);
        let committed_data = test_block_data_at_number(prepared_hash, committed_hash, 3, 145);
        let committed_broadcast: BlockDataBroadcast =
            bincode::deserialize(&committed_data).expect("test broadcast decodes");
        let mock = Arc::new(MockExecutionLayer::new(
            PayloadStatusEnum::Syncing,
            PayloadStatusEnum::Valid,
        ));
        let el: Arc<dyn ExecutionLayer> = mock.clone();
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.el = Some(el);
        orch.head_block_hash = exact_head;
        orch.execution_validated_head_view = 1;
        orch.committed_block_count = 143;
        orch.sync_in_flight = true;
        orch.sync_started_at = Some(Instant::now());
        orch.sync_request_range = Some((2, 3));
        orch.sync_requested_peers.insert(peer);

        orch.handle_sync_response(
            peer,
            n42_network::BlockSyncResponse {
                blocks: vec![n42_network::SyncBlock {
                    view: 3,
                    block_hash: committed_hash,
                    commit_qc: test_commit_qc(3, committed_hash),
                    payload: committed_broadcast.payload_json,
                    validator_changes: None,
                }],
                peer_committed_view: 3,
                execution_lineage: vec![
                    n42_network::SyncPayload {
                        view: 2,
                        block_hash: prepared_hash,
                        block_data: prepared_data,
                    },
                    n42_network::SyncPayload {
                        view: 3,
                        block_hash: committed_hash,
                        block_data: committed_data,
                    },
                ],
            },
        )
        .await;

        assert_eq!(
            mock.new_payload_hashes(),
            vec![committed_hash],
            "the foreign prepared payload and its cached output are never submitted"
        );
        assert!(mock.fcu_heads().is_empty());
        assert_eq!(orch.head_block_hash, exact_head);
        assert_eq!(orch.execution_validated_head_view, 1);
        assert_eq!(orch.syncing_blocks.len(), 1);
        assert!(
            orch.committed_blocks
                .back()
                .expect("QC metadata remains recoverable")
                .execution_lineage
                .is_empty(),
            "an unproven raw lineage must not enter the sync-serving ring"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn unsolicited_sync_response_cannot_cancel_active_request() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let expected_peer = n42_network::PeerId::random();
        let unexpected_peer = n42_network::PeerId::random();
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.sync_in_flight = true;
        orch.sync_started_at = Some(Instant::now());
        orch.sync_request_range = Some((10, 20));
        orch.sync_requested_peers.insert(expected_peer);

        orch.handle_sync_response(
            unexpected_peer,
            n42_network::BlockSyncResponse {
                blocks: Vec::new(),
                peer_committed_view: 20,
                execution_lineage: Vec::new(),
            },
        )
        .await;

        assert!(orch.sync_in_flight, "the real request must remain active");
        assert_eq!(orch.sync_request_range, Some((10, 20)));
        assert!(orch.sync_requested_peers.contains(&expected_peer));
    }

    /// T3 (F2): restart recovery seeds the execution floor from a view/hash pair
    /// proven against reth's canonical head. Catch-up must preserve that floor.
    #[tokio::test(flavor = "current_thread")]
    async fn post_restart_catchup_floor_uses_recovered_execution_view() {
        let (engine, output_rx) = make_test_engine();
        let (network, mut cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let peer = n42_network::PeerId::random();
        let waiting = B256::repeat_byte(0x22);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.connected_peers.insert(peer);
        orch.head_block_hash = B256::repeat_byte(0x11);
        orch = orch.with_recovered_execution_validated_head(100);

        let mut recovered = QuorumCertificate::genesis();
        recovered.view = 100;
        orch.last_commit_qc = Some(recovered);
        orch.committed_blocks.push_back(CommittedBlock {
            view: 105,
            block_hash: waiting,
            commit_qc: QuorumCertificate::genesis(),
            payload: Vec::new(),
            payload_len: 0,
            block_data: None,
            validator_changes: None,
            execution_lineage: Vec::new(),
        });

        orch.handle_import_done(waiting, 105, ImportOutcome::Syncing, 0)
            .await;

        let command = tokio::time::timeout(Duration::from_secs(1), cmd_rx.recv())
            .await
            .expect("a catch-up sync command should be sent")
            .expect("network command channel should remain open");
        match command {
            NetworkCommand::RequestSync { request, .. } => {
                assert_eq!(
                    request.from_view, 101,
                    "floor derives from the recovered committed view (100), not 1"
                );
            }
            other => panic!("unexpected network command: {other:?}"),
        }
    }

    /// A joining validator may receive a Decide for a descendant before it has
    /// any ancestor payloads. Its newly learned commit view is not an execution
    /// floor: catch-up must start after genesis so the missing lineage is not
    /// skipped.
    #[tokio::test(flavor = "current_thread")]
    async fn fresh_joiner_catchup_does_not_use_learned_commit_view_as_floor() {
        let (engine, output_rx) = make_test_engine();
        let (network, mut cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let peer = n42_network::PeerId::random();
        let waiting = B256::repeat_byte(0x32);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.connected_peers.insert(peer);
        orch.head_block_hash = B256::repeat_byte(0x31);
        orch.execution_validated_head_view = 0;

        let mut learned = QuorumCertificate::genesis();
        learned.view = 3;
        orch.last_commit_qc = Some(learned);
        orch.committed_blocks.push_back(CommittedBlock {
            view: 3,
            block_hash: waiting,
            commit_qc: QuorumCertificate::genesis(),
            payload: Vec::new(),
            payload_len: 0,
            block_data: None,
            validator_changes: None,
            execution_lineage: Vec::new(),
        });

        orch.handle_import_done(waiting, 3, ImportOutcome::Syncing, 0)
            .await;

        let command = tokio::time::timeout(Duration::from_secs(1), cmd_rx.recv())
            .await
            .expect("a catch-up sync command should be sent")
            .expect("network command channel should remain open");
        match command {
            NetworkCommand::RequestSync { request, .. } => {
                assert_eq!(
                    request.from_view, 1,
                    "a fresh joiner must request ancestors after its execution floor"
                );
            }
            other => panic!("unexpected network command: {other:?}"),
        }
    }

    /// T4 (F3): `Accepted` from `new_payload` means the payload was stored for a
    /// side chain WITHOUT execution. It must not advance the head nor flush the
    /// staged sidecar diff; the block is queued for retry.
    #[tokio::test(flavor = "current_thread")]
    async fn accepted_new_payload_is_not_execution_validity() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let head = B256::repeat_byte(0x11);
        let block = B256::repeat_byte(0x22);
        let mock = Arc::new(MockExecutionLayer::new(
            PayloadStatusEnum::Accepted,
            PayloadStatusEnum::Accepted,
        ));
        let el: Arc<dyn ExecutionLayer> = mock.clone();
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.el = Some(el);
        orch.head_block_hash = head;
        orch.execution_validated_head_view = 0;
        orch.pending_sidecar_diffs
            .insert(3, (block, n42_execution::state_diff::StateDiff::default()));

        let broadcast = BlockDataBroadcast {
            block_hash: block,
            view: 3,
            payload_json: serde_json::to_vec(&test_execution_data(head, block)).unwrap(),
            timestamp: 0,
            execution_output: None,
            leader_ready_unix_ms: 0,
        };
        let _ = orch.import_and_notify(broadcast).await;

        assert_eq!(
            orch.head_block_hash, head,
            "Accepted (stored, not executed) must not advance the head"
        );
        assert_eq!(orch.execution_validated_head_view, 0);
        assert!(
            mock.fcu_heads().is_empty(),
            "Accepted must not fork-choice-update reth"
        );
        assert!(
            orch.pending_sidecar_diffs.contains_key(&3),
            "the staged sidecar diff must not be flushed for an unexecuted block"
        );
        assert!(
            !orch.syncing_blocks.is_empty(),
            "Accepted is queued for retry, exactly like Syncing"
        );
    }

    /// A `Valid` new-payload response is insufficient when the following FCU
    /// says `Accepted`: reth has executed the payload but has not accepted it as
    /// the requested canonical/finalized head.
    #[tokio::test(flavor = "current_thread")]
    async fn accepted_fcu_does_not_advance_execution_head() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let head = B256::repeat_byte(0x11);
        let block = B256::repeat_byte(0x22);
        let mock = Arc::new(MockExecutionLayer::new(
            PayloadStatusEnum::Valid,
            PayloadStatusEnum::Accepted,
        ));
        let el: Arc<dyn ExecutionLayer> = mock.clone();
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.el = Some(el);
        orch.head_block_hash = head;
        orch.execution_validated_head_view = 1;

        let _ = orch
            .import_and_notify(BlockDataBroadcast {
                block_hash: block,
                view: 2,
                payload_json: serde_json::to_vec(&test_execution_data(head, block)).unwrap(),
                timestamp: 0,
                execution_output: None,
                leader_ready_unix_ms: 0,
            })
            .await;

        assert_eq!(orch.head_block_hash, head);
        assert_eq!(orch.execution_validated_head_view, 1);
        assert_eq!(mock.fcu_heads(), vec![block]);
        assert_eq!(orch.syncing_blocks.len(), 1, "the FCU is retried later");
    }

    #[tokio::test(flavor = "current_thread")]
    async fn invalid_payload_is_cached_and_second_sync_arrival_skips_engine() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let parent = B256::repeat_byte(0x31);
        let bad_hash = B256::repeat_byte(0x32);
        let mock = Arc::new(MockExecutionLayer::new(
            PayloadStatusEnum::Invalid {
                validation_error: "state root mismatch".to_owned(),
            },
            PayloadStatusEnum::Valid,
        ));
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.el = Some(mock.clone());

        for expected_submission in [false, false] {
            let broadcast = bincode::deserialize(&test_block_data(parent, bad_hash, 1))
                .expect("test broadcast decodes");
            assert_eq!(orch.import_and_notify(broadcast).await, expected_submission);
        }

        assert_eq!(
            mock.new_payload_hashes(),
            vec![bad_hash],
            "the cached second arrival must not reach new_payload"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn declared_hash_poison_is_evicted_and_honest_block_can_follow() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let parent = B256::repeat_byte(0x71);
        let honest_hash = B256::repeat_byte(0x72);
        let mock = Arc::new(MockExecutionLayer::with_new_payload_statuses(
            [
                PayloadStatusEnum::Invalid {
                    validation_error: format!(
                        "block hash mismatch: want {}, got {}",
                        B256::repeat_byte(0x73),
                        honest_hash
                    ),
                },
                PayloadStatusEnum::Valid,
            ],
            PayloadStatusEnum::Valid,
        ));
        let cache = Arc::new(MockExecutionOutputCache::default());
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx)
            .with_exec_output_cache(cache.clone());
        orch.el = Some(mock.clone());
        orch.head_block_hash = parent;

        let forged = BlockDataBroadcast {
            block_hash: honest_hash,
            view: 1,
            // The envelope and payload both declare the honest hash so the
            // pre-submit field check passes, while the payload contents differ
            // from the honest arrival below. Reth is what recomputes the hash.
            payload_json: serde_json::to_vec(&test_execution_data_at_number(
                parent,
                honest_hash,
                999,
            ))
            .unwrap(),
            timestamp: 1,
            // The mock cache deliberately accepts arbitrary bytes: this models
            // a peer-supplied bundle keyed by the honest block's declared hash.
            execution_output: Some(vec![0xFA, 0xCE]),
            leader_ready_unix_ms: 0,
        };
        assert!(!orch.import_and_notify(forged).await);
        assert_eq!(cache.evicted(), vec![honest_hash]);
        assert!(!cache.contains(honest_hash));
        assert!(
            !orch.bad_blocks.should_skip(honest_hash, "test"),
            "a recomputed-hash mismatch must not blacklist the declared honest hash"
        );

        let honest = BlockDataBroadcast {
            block_hash: honest_hash,
            view: 1,
            payload_json: serde_json::to_vec(&test_execution_data(parent, honest_hash)).unwrap(),
            timestamp: 1,
            execution_output: None,
            leader_ready_unix_ms: 0,
        };
        assert!(orch.import_and_notify(honest).await);
        assert_eq!(orch.head_block_hash, honest_hash);
        assert_eq!(mock.new_payload_hashes(), vec![honest_hash, honest_hash]);
    }

    /// HIGH-1: the payload itself can honestly declare `H` while an
    /// unauthenticated peer substitutes only the compact execution output. In
    /// production reth then reports a state-root mismatch. That verdict is
    /// about the injected bytes, not block `H`, so the cache must be evicted
    /// without blacklisting `H`; a later honest compact-free arrival must run.
    #[tokio::test(flavor = "current_thread")]
    async fn forged_compact_output_does_not_blacklist_honest_hash() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let parent = B256::repeat_byte(0x74);
        let honest_hash = B256::repeat_byte(0x75);
        let mock = Arc::new(MockExecutionLayer::with_new_payload_statuses(
            [
                PayloadStatusEnum::Invalid {
                    validation_error: "state root mismatch from compact output".to_owned(),
                },
                PayloadStatusEnum::Valid,
            ],
            PayloadStatusEnum::Valid,
        ));
        let cache = Arc::new(MockExecutionOutputCache::default());
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx)
            .with_exec_output_cache(cache.clone());
        orch.el = Some(mock.clone());
        orch.head_block_hash = parent;

        let forged_compact = BlockDataBroadcast {
            block_hash: honest_hash,
            view: 1,
            // This payload is the honest block and passes the envelope hash
            // check. Only its independently carried compact bytes are forged.
            payload_json: serde_json::to_vec(&test_execution_data(parent, honest_hash)).unwrap(),
            timestamp: 1,
            execution_output: Some(vec![0xBA, 0xD0, 0x00, 0x01]),
            leader_ready_unix_ms: 0,
        };
        assert!(!orch.import_and_notify(forged_compact).await);
        assert_eq!(cache.evicted(), vec![honest_hash]);
        assert!(!cache.contains(honest_hash));
        assert!(
            !orch.bad_blocks.should_skip(honest_hash, "test"),
            "state-root failure after compact injection must not blacklist H"
        );

        let honest = BlockDataBroadcast {
            block_hash: honest_hash,
            view: 1,
            payload_json: serde_json::to_vec(&test_execution_data(parent, honest_hash)).unwrap(),
            timestamp: 1,
            execution_output: None,
            leader_ready_unix_ms: 0,
        };
        assert!(orch.import_and_notify(honest).await);
        assert_eq!(orch.head_block_hash, honest_hash);
        assert_eq!(mock.new_payload_hashes(), vec![honest_hash, honest_hash]);
    }

    /// HIGH-1 observer/committed path: Case-B background import must apply the
    /// same no-blacklist rule when it injected peer-provided compact bytes.
    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn committed_compact_rejection_does_not_blacklist_block_hash() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let parent = B256::repeat_byte(0x76);
        let honest_hash = B256::repeat_byte(0x77);
        let mock = Arc::new(MockExecutionLayer::new(
            PayloadStatusEnum::Invalid {
                validation_error: "state root mismatch from compact output".to_owned(),
            },
            PayloadStatusEnum::Syncing,
        ));
        let cache = Arc::new(MockExecutionOutputCache::default());
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx)
            .with_exec_output_cache(cache.clone());
        orch.el = Some(mock.clone());
        orch.head_block_hash = parent;
        orch.async_finalize_fcu = false;
        orch.pending_block_data.insert(
            honest_hash,
            test_block_data_with_empty_execution(parent, honest_hash, 1).into(),
        );

        orch.handle_engine_output(EngineOutput::BlockCommitted {
            view: 1,
            block_hash: honest_hash,
            commit_qc: QuorumCertificate::genesis(),
            validator_changes: None,
        })
        .await;
        orch.handle_commit_execution_timeout(1, honest_hash);
        let (hash, view, outcome, _) =
            tokio::time::timeout(Duration::from_secs(2), orch.import_done_rx.recv())
                .await
                .expect("background import finishes")
                .expect("channel open");

        assert_eq!(
            (hash, view, outcome),
            (honest_hash, 1, ImportOutcome::Invalid)
        );
        assert_eq!(cache.evicted(), vec![honest_hash]);
        assert!(!cache.contains(honest_hash));
        assert!(
            !orch.bad_blocks.should_skip(honest_hash, "test"),
            "committed compact rejection must not blacklist the block hash"
        );
        assert_eq!(mock.new_payload_hashes(), vec![honest_hash]);
    }

    #[tokio::test(flavor = "current_thread")]
    async fn direct_block_arrival_is_filtered_by_bad_block_cache() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let parent = B256::repeat_byte(0x35);
        let bad_hash = B256::repeat_byte(0x36);
        let mock = Arc::new(MockExecutionLayer::new(
            PayloadStatusEnum::Valid,
            PayloadStatusEnum::Valid,
        ));
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.el = Some(mock.clone());
        orch.bad_blocks
            .insert_invalid_payload(bad_hash, "known invalid", "test_setup");

        orch.handle_block_data(test_block_data(parent, bad_hash, 1))
            .await;

        assert!(mock.new_payload_hashes().is_empty());
        assert!(
            !orch.pending_block_data.contains_key(&bad_hash),
            "known bad direct/gossip data must be dropped before consensus notification"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn syncing_payload_is_never_added_to_bad_block_cache() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let parent = B256::repeat_byte(0x41);
        let block_hash = B256::repeat_byte(0x42);
        let mock = Arc::new(MockExecutionLayer::new(
            PayloadStatusEnum::Syncing,
            PayloadStatusEnum::Valid,
        ));
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.el = Some(mock.clone());

        for _ in 0..2 {
            let broadcast = bincode::deserialize(&test_block_data(parent, block_hash, 1))
                .expect("test broadcast decodes");
            assert!(orch.import_and_notify(broadcast).await);
        }

        assert_eq!(mock.new_payload_hashes(), vec![block_hash, block_hash]);
        assert!(
            !orch.bad_blocks.should_skip(block_hash, "test"),
            "Syncing is retryable and must not poison the cache"
        );
    }

    #[tokio::test(flavor = "current_thread")]
    async fn mismatched_sync_envelope_cannot_poison_declared_hash() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let parent = B256::repeat_byte(0x51);
        let declared_hash = B256::repeat_byte(0x52);
        let payload_hash = B256::repeat_byte(0x53);
        let mock = Arc::new(MockExecutionLayer::new(
            PayloadStatusEnum::Invalid {
                validation_error: "invalid".to_owned(),
            },
            PayloadStatusEnum::Valid,
        ));
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.el = Some(mock.clone());

        let submitted = orch
            .import_and_notify(BlockDataBroadcast {
                block_hash: declared_hash,
                view: 1,
                payload_json: serde_json::to_vec(&test_execution_data(parent, payload_hash))
                    .unwrap(),
                timestamp: 0,
                execution_output: None,
                leader_ready_unix_ms: 0,
            })
            .await;

        assert!(!submitted);
        assert!(mock.new_payload_hashes().is_empty());
        assert!(
            !orch.bad_blocks.should_skip(declared_hash, "test"),
            "untrusted envelope mismatches must be dropped, not cached"
        );
    }

    /// T4 rescue edge: eager `new_payload=Valid` arriving during a failed FCU
    /// only justifies retrying FCU. If that retry is still `Accepted`, the
    /// committed/build head must remain at the last canonical Valid block.
    #[tokio::test(flavor = "current_thread")]
    async fn accepted_retry_fcu_after_eager_valid_does_not_advance_head() {
        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let head = B256::repeat_byte(0x11);
        let block = B256::repeat_byte(0x22);
        let mock = Arc::new(MockExecutionLayer::new(
            PayloadStatusEnum::Valid,
            PayloadStatusEnum::Accepted,
        ));
        let el: Arc<dyn ExecutionLayer> = mock.clone();
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.el = Some(el);
        orch.head_block_hash = head;
        orch.execution_validated_head_view = 1;
        orch.eager_import_done_tx
            .send((block, 0, head, 2, false, None))
            .await
            .expect("eager completion channel remains open");

        orch.finalize_committed_block(2, block, QuorumCertificate::genesis())
            .await;

        assert_eq!(orch.head_block_hash, head);
        assert_eq!(orch.execution_validated_head_view, 1);
        assert_eq!(
            mock.fcu_heads(),
            vec![block, block],
            "the eager completion triggers exactly one FCU retry"
        );
    }

    /// T1: startup validates the persisted view/hash mapping before calling the
    /// builder. The builder restores only the proven view and never replaces
    /// the canonical head already derived from reth.
    #[test]
    fn with_recovered_execution_validated_head_preserves_reth_hash() {
        let head = B256::repeat_byte(0x60);

        let (engine, output_rx) = make_test_engine();
        let (network, _c, _p) = make_test_network();
        let (_t, net_event_rx) = mpsc::channel(8192);
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.head_block_hash = head;
        let orch = orch.with_recovered_execution_validated_head(42);
        assert_eq!(orch.execution_validated_head_view, 42);
        assert_eq!(orch.head_block_hash, head);
    }

    /// T5 (F4): the bounded eager-validation set can evict a true confirmation
    /// under speculative churn, but the finalize path drains the eager
    /// completion channel and rescues it — the head still advances. This proves
    /// the recoverability the re-audit relies on to rate the eviction bounded.
    #[tokio::test(flavor = "current_thread")]
    async fn eager_validation_evicted_by_churn_is_rescued_at_finalize() {
        let recorder = DebuggingRecorder::new();
        let snapshotter = recorder.snapshotter();
        let _recorder_guard = metrics::set_default_local_recorder(&recorder);

        let (engine, output_rx) = make_test_engine();
        let (network, _cmd_rx, _prx) = make_test_network();
        let (_net_event_tx, net_event_rx) = mpsc::channel(8192);
        let previous_head = B256::repeat_byte(0x34);
        let committed_hash = B256::repeat_byte(0xF0);
        // FCU returns Syncing first, forcing the finalize path to drain the
        // eager completion channel — the rescue route for an evicted entry.
        let mock_el = Arc::new(MockExecutionLayer::with_fcu_statuses(
            PayloadStatusEnum::Valid,
            [PayloadStatusEnum::Syncing, PayloadStatusEnum::Valid],
        ));
        let mut orch = ConsensusService::new(engine, Arc::new(network), net_event_rx, output_rx);
        orch.el = Some(mock_el);
        orch.head_block_hash = previous_head;
        orch.async_finalize_fcu = false;

        // Saturate the bounded eager set (cap 32) with unrelated churn so the
        // committed block's own eager entry is NOT present — the eviction case.
        for i in 0..32u8 {
            orch.eager_execution_validated
                .push_back(B256::repeat_byte(0x80 + i));
        }
        assert!(
            !orch.eager_execution_validated.contains(&committed_hash),
            "the committed block's eager entry has been evicted by churn"
        );

        // Its eager import still completed and is waiting on the channel.
        orch.eager_import_done_tx
            .send((committed_hash, 1, previous_head, 1, false, None))
            .await
            .expect("queue eager completion");

        orch.handle_engine_output(EngineOutput::BlockCommitted {
            view: 1,
            block_hash: committed_hash,
            commit_qc: QuorumCertificate::genesis(),
            validator_changes: None,
        })
        .await;

        assert_eq!(
            orch.head_block_hash, committed_hash,
            "the evicted-but-imported block is rescued and the head advances"
        );
        assert_eq!(orch.execution_validated_head_view, 1);
        let rescued =
            snapshotter
                .snapshot()
                .into_vec()
                .into_iter()
                .find_map(|(key, _, _, value)| {
                    (key.key().name() == "n42_eager_import_rescued_total").then_some(value)
                });
        assert_eq!(rescued, Some(DebugValue::Counter(1)));
    }
    /// Block-like bytes for codec tests: runs of repeated values mixed with
    /// noise, so zstd sees both matches and literals.
    fn codec_sample(len: usize, seed: u64) -> Vec<u8> {
        let mut state = seed ^ 0x9E37_79B9_7F4A_7C15;
        let mut out = Vec::with_capacity(len);
        while out.len() < len {
            state ^= state << 13;
            state ^= state >> 7;
            state ^= state << 17;
            let run = (state % 64) as usize + 1;
            let byte = (state >> 32) as u8;
            if state & 1 == 0 {
                out.extend(std::iter::repeat_n(byte, run.min(len - out.len())));
            } else {
                for offset in 0..run.min(len - out.len()) {
                    out.push(
                        byte.wrapping_mul(31)
                            .wrapping_add(offset as u8 ^ (state as u8)),
                    );
                }
            }
        }
        out
    }

    #[test]
    fn pooled_zstd_matches_one_shot() {
        let level = payload_zstd_level();
        for len in [0usize, 1, 100, 4_096, 131_072, 1 << 20, 3 << 20] {
            let payload = codec_sample(len, len as u64);
            let one_shot = zstd::bulk::compress(&payload, level).unwrap();
            // Twice: the second call exercises the reused context.
            for round in 0..2 {
                let pooled = compress_payload(&payload);
                assert_eq!(pooled, one_shot, "len {len} round {round}");
                assert_eq!(
                    decompress_payload(&pooled).unwrap(),
                    payload,
                    "len {len} round {round}"
                );
            }
            assert_eq!(
                zstd_decompress_pooled(&one_shot, MAX_DECOMPRESSED_BLOCK_COMPONENT_SIZE).unwrap(),
                zstd::bulk::decompress(&one_shot, MAX_DECOMPRESSED_BLOCK_COMPONENT_SIZE).unwrap()
            );
        }
        // A different level on the same thread must not leak the previous one.
        let payload = codec_sample(1 << 20, 99);
        assert_eq!(
            zstd_compress_pooled(&payload, 1).unwrap(),
            zstd::bulk::compress(&payload, 1).unwrap()
        );
        assert_eq!(
            zstd_compress_pooled(&payload, level).unwrap(),
            zstd::bulk::compress(&payload, level).unwrap()
        );
    }

    /// Timing only. `cargo test -p n42-consensus-service zstd_pool_bench --release -- --ignored --nocapture`
    #[test]
    #[ignore = "measurement, not a correctness gate"]
    fn zstd_pool_bench() {
        let level = payload_zstd_level();
        for (label, len) in [
            ("16 KiB", 16usize << 10),
            ("1 MiB", 1usize << 20),
            ("12 MiB", 12usize << 20),
        ] {
            let payload = codec_sample(len, len as u64);
            let iterations: u32 = if len > (4 << 20) {
                10
            } else if len >= (1 << 20) {
                50
            } else {
                2_000
            };
            let compressed = zstd::bulk::compress(&payload, level).unwrap();

            let started = std::time::Instant::now();
            for _ in 0..iterations {
                std::hint::black_box(zstd::bulk::compress(&payload, level).unwrap());
            }
            let old_compress = started.elapsed() / iterations;
            let started = std::time::Instant::now();
            for _ in 0..iterations {
                std::hint::black_box(zstd_compress_pooled(&payload, level).unwrap());
            }
            let new_compress = started.elapsed() / iterations;

            let started = std::time::Instant::now();
            for _ in 0..iterations {
                std::hint::black_box(
                    zstd::bulk::decompress(&compressed, MAX_DECOMPRESSED_BLOCK_COMPONENT_SIZE)
                        .unwrap(),
                );
            }
            let old_decompress = started.elapsed() / iterations;
            let started = std::time::Instant::now();
            for _ in 0..iterations {
                std::hint::black_box(
                    zstd_decompress_pooled(&compressed, MAX_DECOMPRESSED_BLOCK_COMPONENT_SIZE)
                        .unwrap(),
                );
            }
            let new_decompress = started.elapsed() / iterations;
            println!(
                "zstd level {level} {label} ({} -> {} bytes, {iterations} iterations):\n  compress   {old_compress:?} -> {new_compress:?}\n  decompress {old_decompress:?} -> {new_decompress:?}",
                payload.len(),
                compressed.len()
            );
        }
    }
}
