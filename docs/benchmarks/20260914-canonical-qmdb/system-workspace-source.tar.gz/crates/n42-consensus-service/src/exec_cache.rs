//! Compact-block execution-output cache port — the trait boundary over reth's
//! `reth_evm::payload_cache`. The leader serializes its EVM execution output so
//! followers can skip re-execution; the follower injects it before `new_payload`.
//! All reth coupling lives in the node-side adapter (`RethExecutionOutputCache`
//! in `n42-node`); this port carries compact bytes or native commitments. Caplin EL-seam
//! refactor (stage 6a-2 / 6c).

use alloy_primitives::B256;

/// Port the orchestrator calls instead of reth's `payload_cache` directly. One
/// in-process adapter today (`RethExecutionOutputCache`, node-side).
pub trait ExecutionOutputCache: Send + Sync {
    /// Take + serialize + compress the cached compact-block execution output for
    /// `hash`. `None` when nothing is cached. The bytes are the wire blob the
    /// leader puts in `BlockDataBroadcast.execution_output`.
    fn take_serialized(&self, hash: B256) -> Option<Vec<u8>>;

    /// Take the locally built execution output, derive the chain-native QMDB
    /// state and receipts commitments from the authenticated parent branch.
    /// Gov5 carries its native block/receipts and does not use a Rust compact
    /// execution blob. Returns (QMDB state root, native receipts root).
    /// Header normalization changes the block hash after payload construction, so the
    /// orchestrator must bind the new header to what was actually executed.
    ///
    /// Adapters that do not support Gov5 normalization may keep the default
    /// `None`; an H2 participant then refuses normalization.
    fn take_gov5_normalization(
        &self,
        _execution: &alloy_rpc_types_engine::ExecutionData,
    ) -> Option<(B256, B256)> {
        None
    }

    /// Inject a received compact-block wire blob into the payload cache so the
    /// next `new_payload` hits the cache and skips EVM re-execution. Returns
    /// whether the inject succeeded.
    fn inject(&self, hash: B256, compressed: &[u8], source: &'static str) -> bool;

    /// Remove a previously injected execution output. Every caller that
    /// injects untrusted bytes must evict them when `new_payload` does not
    /// return `Valid`; otherwise a rejected bundle can poison later arrivals
    /// for the same declared block hash.
    fn evict(&self, hash: B256);
}
