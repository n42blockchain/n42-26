use alloy_consensus::{
    EMPTY_OMMER_ROOT_HASH, EMPTY_ROOT_HASH, Header, TxReceipt,
    proofs::{calculate_receipt_root, calculate_withdrawals_root},
};
use alloy_primitives::{B256, Bloom, Bytes, U256, keccak256};
use arc_swap::ArcSwapOption;
use reth_chainspec::{ChainSpec, EthChainSpec, EthereumHardforks};
use reth_consensus::{Consensus, ConsensusError, FullConsensus, HeaderValidator};
use reth_ethereum_consensus::EthBeaconConsensus;
use reth_ethereum_primitives::{Block as EthBlock, EthPrimitives};
use reth_execution_types::BlockExecutionResult;
use reth_primitives_traits::{Block, RecoveredBlock, SealedBlock, SealedHeader};
use std::fmt::Debug;
use std::sync::Arc;

use crate::committee_pool::SimulatedCommitteePool;
use crate::gov5_native_receipts_root;
use crate::gov5_rewards::{gov5_native_rewards_root, gov5_withdrawals_to_rewards};
use crate::validator::ValidatorSet;

/// Header semantics used when reconstructing and validating N42 blocks.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum N42HeaderProfile {
    /// Standard Ethereum post-merge empty-ommers commitment.
    #[default]
    Ethereum,
    /// gov5 H2 custom-chain header encoding used by the preserved replay-v2 history.
    Gov5H2,
}

/// Fixed prefix written by gov5's H2 header-extra encoder.
pub const GOV5_HEADER_EXTRA_MAGIC: &[u8; 4] = b"N42H";
/// Magic plus the little-endian H2 view number.
pub const MIN_GOV5_HEADER_EXTRA_BYTES: usize = 12;
/// Defensive allocation/wire bound shared with the H2 high-TC envelope limit.
pub const MAX_GOV5_HEADER_EXTRA_BYTES: usize = 4096;

/// Structural errors in gov5's chain-specific header-extra field.
#[derive(Clone, Debug, PartialEq, Eq, thiserror::Error)]
pub enum N42HeaderProfileError {
    #[error("gov5 header extra is too short: got {0} bytes, need at least 12")]
    Gov5ExtraTooShort(usize),
    #[error("gov5 header extra exceeds 4096 bytes: got {0}")]
    Gov5ExtraTooLong(usize),
    #[error("gov5 header extra is missing the N42H magic prefix")]
    Gov5ExtraInvalidMagic,
    #[error("gov5 H2 header requires a zero ommers hash, got {0}")]
    Gov5OmmersHash(B256),
    #[error("gov5 H2 header requires current difficulty 0 or legacy replay difficulty 1, got {0}")]
    Gov5Difficulty(U256),
    #[error("gov5 replay-v2 header violates its fixed historical shape: {0}")]
    Gov5ReplayV2Shape(&'static str),
    #[error("gov5 header commits rewards root {committed} but the body's rewards derive {derived}")]
    Gov5RewardsRoot { committed: B256, derived: B256 },
}

/// Validates the bounded, hash-authenticated outer shape of gov5 H2 header extra-data.
/// QC and seal authentication remain the responsibility of the H2 finality layer.
pub fn validate_gov5_header_extra(extra_data: &[u8]) -> Result<(), N42HeaderProfileError> {
    if extra_data.len() < MIN_GOV5_HEADER_EXTRA_BYTES {
        return Err(N42HeaderProfileError::Gov5ExtraTooShort(extra_data.len()));
    }
    if extra_data.len() > MAX_GOV5_HEADER_EXTRA_BYTES {
        return Err(N42HeaderProfileError::Gov5ExtraTooLong(extra_data.len()));
    }
    if !extra_data.starts_with(GOV5_HEADER_EXTRA_MAGIC) {
        return Err(N42HeaderProfileError::Gov5ExtraInvalidMagic);
    }
    Ok(())
}

/// Validates fields that gov5 commits to the H2 block hash but standard Engine payloads omit or
/// constrain differently.
pub fn validate_gov5_h2_header(header: &Header) -> Result<(), N42HeaderProfileError> {
    if header.ommers_hash != B256::ZERO {
        return Err(N42HeaderProfileError::Gov5OmmersHash(header.ommers_hash));
    }
    if header.difficulty != U256::ZERO && header.difficulty != U256::from(1) {
        return Err(N42HeaderProfileError::Gov5Difficulty(header.difficulty));
    }
    validate_gov5_header_extra(&header.extra_data)
}

/// Validates the fixed post-merge header shape emitted by gov5 replay-v2. Consensus evidence is
/// stored beside these historical blocks rather than in `extra_data`; every optional field below
/// is therefore pinned before the block hash is accepted.
pub fn validate_gov5_replay_v2_header(header: &Header) -> Result<(), N42HeaderProfileError> {
    let invalid = |reason| Err(N42HeaderProfileError::Gov5ReplayV2Shape(reason));
    if header.ommers_hash != EMPTY_OMMER_ROOT_HASH {
        return invalid("ommers hash is not the canonical empty-list hash");
    }
    if header.difficulty != U256::ZERO {
        return invalid("difficulty is not zero");
    }
    if header.extra_data.as_ref() != [0_u8; 32] {
        return invalid("extra data is not exactly 32 zero bytes");
    }
    if header.withdrawals_root != Some(keccak256([])) {
        return invalid("empty reward-list root is not keccak(empty)");
    }
    if header.blob_gas_used != Some(0) || header.excess_blob_gas != Some(0) {
        return invalid("blob gas fields are not both zero");
    }
    if header.parent_beacon_block_root.is_none() {
        return invalid("parent consensus-evidence root is absent");
    }
    if header.requests_hash != Some(EMPTY_ROOT_HASH) {
        return invalid("execution requests root is not the canonical empty root");
    }
    if header.block_access_list_hash.is_some() {
        return invalid("block access list is unsupported in replay-v2 v1 history");
    }
    Ok(())
}

/// Accepts exactly one of the two gov5 history/live shapes. The authenticated block hash selects
/// the concrete shape; this does not synthesize omitted fields or accept arbitrary hybrids.
pub fn validate_gov5_interop_header(header: &Header) -> Result<(), N42HeaderProfileError> {
    if header.extra_data.starts_with(GOV5_HEADER_EXTRA_MAGIC) {
        validate_gov5_h2_header(header)
    } else {
        validate_gov5_replay_v2_header(header)
    }
}

fn normalized_gov5_header(header: &Header) -> Result<Header, N42HeaderProfileError> {
    validate_gov5_interop_header(header)?;
    let mut normalized = header.clone();
    if validate_gov5_replay_v2_header(header).is_ok() {
        // replay-v2 encodes consensus-evidence/reward commitments in Ethereum fork fields while
        // executing the custom chain's pre-Shanghai rules. Remove only those fixed fields for the
        // inner Ethereum rule checker; the original sealed header remains hash-authenticated.
        normalized.withdrawals_root = None;
        normalized.blob_gas_used = None;
        normalized.excess_blob_gas = None;
        normalized.parent_beacon_block_root = None;
        normalized.requests_hash = None;
    } else {
        normalized.ommers_hash = EMPTY_OMMER_ROOT_HASH;
        normalized.difficulty = U256::ZERO;
        normalized.extra_data = Bytes::new();
    }
    Ok(normalized)
}

/// Resolves the validator set that should verify a QC for a given view.
/// Live gov5 H2 headers commit their reward list (carried in the body as
/// withdrawals) in the withdrawals-root slot with gov5's keccak-concat
/// derivation. Check that commitment here and hand reth's own validation the
/// Ethereum withdrawals root of the same list, so its body-vs-header rule
/// keeps guarding the body while the gov5 commitment guards the rewards.
fn normalize_gov5_rewards(
    header: &mut Header,
    body: &<EthBlock as reth_primitives_traits::Block>::Body,
) -> Result<(), N42HeaderProfileError> {
    match (header.withdrawals_root, body.withdrawals.as_deref()) {
        (Some(committed), Some(withdrawals)) => {
            let rewards = gov5_withdrawals_to_rewards(withdrawals);
            let derived = gov5_native_rewards_root(&rewards);
            if derived != committed {
                return Err(N42HeaderProfileError::Gov5RewardsRoot { committed, derived });
            }
            header.withdrawals_root = Some(calculate_withdrawals_root(withdrawals));
        }
        (Some(committed), None) => {
            // An empty reward list is committed as keccak("") and the body
            // then carries no withdrawals at all.
            if committed != keccak256([]) {
                return Err(N42HeaderProfileError::Gov5RewardsRoot {
                    committed,
                    derived: keccak256([]),
                });
            }
            header.withdrawals_root = Some(EMPTY_ROOT_HASH);
        }
        (None, _) => {}
    }
    Ok(())
}

pub type ValidatorSetResolver = Arc<dyn Fn(u64) -> Option<Arc<ValidatorSet>> + Send + Sync>;

/// N42 consensus adapter that integrates with the reth node builder.
///
/// Wraps `EthBeaconConsensus` for standard Ethereum validation (gas limits,
/// receipt roots, etc.) and layers N42-specific HotStuff-2 validation on top:
/// - QC verification for committed blocks
/// - Validator set checks
///
/// The adapter is intentionally stateless—it validates individual blocks/headers
/// against the consensus rules. The stateful consensus engine (`ConsensusEngine`)
/// runs as a separate background task.
#[derive(Clone)]
pub struct N42Consensus<C = ChainSpec> {
    /// Inner Ethereum consensus for standard EVM rule checks.
    inner: EthBeaconConsensus<C>,
    /// Validator set for QC verification.
    /// None during initial sync when validator set is not yet loaded.
    validator_set: Arc<ArcSwapOption<ValidatorSet>>,
    /// Optional epoch-aware validator-set resolver for QC verification.
    validator_set_resolver: Option<ValidatorSetResolver>,
    /// Chain-specific header encoding. Defaults to standard Ethereum semantics.
    header_profile: N42HeaderProfile,
    /// gov5's simulated committee pool when the chain's genesis enables one:
    /// every header's `parentBeaconRoot` must then be `Blake3(parent evidence)`.
    committee_pool: Option<Arc<SimulatedCommitteePool>>,
    /// The fork schedule, for the Prague fill-in of gov5 headers.
    chain_spec: Arc<C>,
}

impl<C> std::fmt::Debug for N42Consensus<C> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("N42Consensus")
            .field("has_validator_set", &self.validator_set.load().is_some())
            .field(
                "has_validator_set_resolver",
                &self.validator_set_resolver.is_some(),
            )
            .field("header_profile", &self.header_profile)
            .field("has_committee_pool", &self.committee_pool.is_some())
            .finish()
    }
}

impl<C> N42Consensus<C>
where
    C: EthChainSpec + EthereumHardforks,
{
    /// [`normalized_gov5_header`] plus the Prague fill-in for the live H2 shape.
    ///
    /// gov5 runs Prague (`pectraTime`: EIP-2935, the 7002/7251 system calls,
    /// EIP-7702) but its miner never stamps `requestsHash`; the wire header
    /// carries the `0x80` placeholder, decoded as `None`. Chain 94 produces no
    /// execution requests, so for the inner Ethereum rules the empty requests
    /// hash stands in — reth then compares it with the hash of the (empty)
    /// requests execution produced, exactly the check gov5 skips. The original
    /// sealed header remains hash-authenticated; only the temporary copy is
    /// filled in.
    fn normalize_header(&self, header: &Header) -> Result<Header, N42HeaderProfileError> {
        let mut normalized = normalized_gov5_header(header)?;
        if validate_gov5_replay_v2_header(header).is_err()
            && normalized.requests_hash.is_none()
            && self
                .chain_spec
                .is_prague_active_at_timestamp(header.timestamp)
        {
            normalized.requests_hash = Some(alloy_eips::eip7685::EMPTY_REQUESTS_HASH);
        }
        Ok(normalized)
    }

    /// Create a new N42 consensus adapter (without validator set).
    /// QC verification is skipped until `set_validator_set` is called.
    pub fn new(chain_spec: Arc<C>) -> Self {
        Self {
            inner: EthBeaconConsensus::new(chain_spec.clone()),
            chain_spec,
            validator_set: Arc::new(ArcSwapOption::empty()),
            validator_set_resolver: None,
            header_profile: N42HeaderProfile::Ethereum,
            committee_pool: None,
        }
    }

    /// Create a new N42 consensus adapter with a validator set for QC verification.
    pub fn with_validator_set(chain_spec: Arc<C>, validator_set: ValidatorSet) -> Self {
        Self::with_validator_set_store(
            chain_spec,
            Arc::new(ArcSwapOption::from_pointee(validator_set)),
        )
    }

    /// Create a new N42 consensus adapter backed by a shared validator-set store.
    pub fn with_validator_set_store(
        chain_spec: Arc<C>,
        validator_set: Arc<ArcSwapOption<ValidatorSet>>,
    ) -> Self {
        Self::with_validator_set_store_and_resolver(chain_spec, validator_set, None)
    }

    /// Create a new N42 consensus adapter backed by a shared validator-set store and
    /// an optional epoch-aware resolver.
    pub fn with_validator_set_store_and_resolver(
        chain_spec: Arc<C>,
        validator_set: Arc<ArcSwapOption<ValidatorSet>>,
        validator_set_resolver: Option<ValidatorSetResolver>,
    ) -> Self {
        Self {
            inner: EthBeaconConsensus::new(chain_spec.clone()),
            chain_spec,
            validator_set,
            validator_set_resolver,
            header_profile: N42HeaderProfile::Ethereum,
            committee_pool: None,
        }
    }

    /// Selects non-standard header semantics for an explicitly identified N42 chain.
    pub const fn with_header_profile(mut self, header_profile: N42HeaderProfile) -> Self {
        self.header_profile = header_profile;
        self
    }

    /// Enforces gov5's committee-evidence link (`parentBeaconRoot ==
    /// Blake3(parent evidence)`) on every header validated under the Gov5
    /// profile. Inert under the Ethereum profile.
    pub fn with_committee_pool(mut self, pool: Arc<SimulatedCommitteePool>) -> Self {
        self.committee_pool = Some(pool);
        self
    }

    /// The committee pool the link check uses, when one is configured.
    pub fn committee_pool(&self) -> Option<&Arc<SimulatedCommitteePool>> {
        self.committee_pool.as_ref()
    }

    /// Sets or updates the validator set.
    pub fn set_validator_set(&mut self, validator_set: ValidatorSet) {
        self.validator_set.store(Some(Arc::new(validator_set)));
    }

    #[cfg(test)]
    fn validator_set_for_view(&self, view: u64) -> Option<Arc<ValidatorSet>> {
        self.validator_set_resolver
            .as_ref()
            .and_then(|resolver| resolver(view))
            .or_else(|| self.validator_set.load_full())
    }
}

impl<C> FullConsensus<EthPrimitives> for N42Consensus<C>
where
    C: EthChainSpec<Header = Header> + EthereumHardforks + Debug + Send + Sync,
{
    fn validate_block_post_execution(
        &self,
        block: &RecoveredBlock<EthBlock>,
        result: &BlockExecutionResult<
            <EthPrimitives as reth_primitives_traits::NodePrimitives>::Receipt,
        >,
        receipt_root_bloom: Option<reth_consensus::ReceiptRootBloom>,
        block_access_list_hash: Option<B256>,
    ) -> Result<(), ConsensusError> {
        if self.header_profile == N42HeaderProfile::Gov5H2 {
            let native_root = gov5_native_receipts_root(&result.receipts);
            if native_root != block.header().receipts_root {
                return Err(ConsensusError::BodyReceiptRootDiff(
                    reth_primitives_traits::GotExpected {
                        got: native_root,
                        expected: block.header().receipts_root,
                    }
                    .into(),
                ));
            }

            let (ethereum_root, logs_bloom) = receipt_root_bloom.unwrap_or_else(|| {
                let receipts = result
                    .receipts
                    .iter()
                    .map(TxReceipt::with_bloom_ref)
                    .collect::<Vec<_>>();
                let root = calculate_receipt_root(&receipts);
                let bloom = receipts
                    .iter()
                    .fold(Bloom::ZERO, |bloom, receipt| bloom | receipt.bloom_ref());
                (root, bloom)
            });
            let senders = block.senders().to_vec();
            let mut normalized = block.clone().into_block();
            normalized.header.receipts_root = ethereum_root;
            if normalized.header.requests_hash.is_none()
                && self
                    .chain_spec
                    .is_prague_active_at_timestamp(normalized.header.timestamp)
            {
                normalized.header.requests_hash = Some(alloy_eips::eip7685::EMPTY_REQUESTS_HASH);
            }
            let normalized = RecoveredBlock::new_unhashed(normalized, senders);
            return <EthBeaconConsensus<C> as FullConsensus<EthPrimitives>>::validate_block_post_execution(
                &self.inner,
                &normalized,
                result,
                Some((ethereum_root, logs_bloom)),
                block_access_list_hash,
            );
        }
        <EthBeaconConsensus<C> as FullConsensus<EthPrimitives>>::validate_block_post_execution(
            &self.inner,
            block,
            result,
            receipt_root_bloom,
            block_access_list_hash,
        )
    }
}

impl<C> Consensus<EthBlock> for N42Consensus<C>
where
    C: EthChainSpec<Header = Header> + EthereumHardforks + Debug + Send + Sync,
{
    fn validate_body_against_header(
        &self,
        body: &<EthBlock as reth_primitives_traits::Block>::Body,
        header: &SealedHeader<Header>,
    ) -> Result<(), ConsensusError> {
        if self.header_profile == N42HeaderProfile::Gov5H2 {
            let mut normalized = self
                .normalize_header(header.header())
                .map_err(ConsensusError::other)?;
            let mut normalized_body = body.clone();
            if validate_gov5_replay_v2_header(header.header()).is_ok() {
                normalized_body.withdrawals = None;
            } else {
                normalize_gov5_rewards(&mut normalized, &normalized_body)
                    .map_err(ConsensusError::other)?;
            }
            return <EthBeaconConsensus<C> as Consensus<EthBlock>>::validate_body_against_header(
                &self.inner,
                &normalized_body,
                &SealedHeader::seal_slow(normalized),
            );
        }
        <EthBeaconConsensus<C> as Consensus<EthBlock>>::validate_body_against_header(
            &self.inner,
            body,
            header,
        )
    }

    fn validate_block_pre_execution(
        &self,
        block: &SealedBlock<EthBlock>,
    ) -> Result<(), ConsensusError> {
        if self.header_profile == N42HeaderProfile::Gov5H2 {
            let mut normalized = block.clone().into_block();
            normalized.header = self
                .normalize_header(block.header())
                .map_err(ConsensusError::other)?;
            if validate_gov5_replay_v2_header(block.header()).is_ok() {
                normalized.body.withdrawals = None;
            } else {
                let body = normalized.body.clone();
                normalize_gov5_rewards(&mut normalized.header, &body)
                    .map_err(ConsensusError::other)?;
            }
            return self
                .inner
                .validate_block_pre_execution(&normalized.seal_slow());
        }
        self.inner.validate_block_pre_execution(block)
    }
}

impl<C> HeaderValidator<Header> for N42Consensus<C>
where
    C: EthChainSpec<Header = Header> + EthereumHardforks + Debug + Send + Sync,
{
    fn validate_header(&self, header: &SealedHeader<Header>) -> Result<(), ConsensusError> {
        if self.header_profile == N42HeaderProfile::Gov5H2 {
            let normalized = self
                .normalize_header(header.header())
                .map_err(ConsensusError::other)?;
            return self
                .inner
                .validate_header(&SealedHeader::seal_slow(normalized));
        }
        self.inner.validate_header(header)
    }

    fn validate_header_against_parent(
        &self,
        header: &SealedHeader<Header>,
        parent: &SealedHeader<Header>,
    ) -> Result<(), ConsensusError> {
        if self.header_profile == N42HeaderProfile::Gov5H2 {
            if parent.hash() != header.parent_hash {
                return Err(ConsensusError::ParentHashMismatch(
                    reth_primitives_traits::GotExpected {
                        got: header.parent_hash,
                        expected: parent.hash(),
                    }
                    .into(),
                ));
            }
            if parent.number.checked_add(1) != Some(header.number) {
                return Err(ConsensusError::ParentBlockNumberMismatch {
                    parent_block_number: parent.number,
                    block_number: header.number,
                });
            }
            // gov5's committee-evidence link (`hotstuff/adapter.go VerifyHeader`):
            // the child's parentBeaconRoot must be Blake3 of the parent's simulated
            // committee evidence, rebuilt from the parent actually being extended
            // (its number, gov5 hash and native receipts root), never from a
            // by-number store. Genesis has no evidence; its child carries zero.
            if let Some(pool) = &self.committee_pool {
                pool.verify_parent_link(
                    header.number,
                    header.parent_beacon_block_root,
                    parent.number,
                    &parent.hash(),
                    &parent.receipts_root,
                )
                .map_err(|error| {
                    metrics::counter!("n42_gov5_committee_evidence_link_broken_total").increment(1);
                    tracing::error!(
                        target: "n42::consensus",
                        number = header.number,
                        block_hash = %header.hash(),
                        parent_hash = %parent.hash(),
                        %error,
                        "REJECTING gov5 header: committee-evidence link broken"
                    );
                    ConsensusError::other(error)
                })?;
            }
            let mut header = self
                .normalize_header(header.header())
                .map_err(ConsensusError::other)?;
            let parent = if parent.number == 0 {
                parent.header().clone()
            } else {
                self.normalize_header(parent.header())
                    .map_err(ConsensusError::other)?
            };
            // The inner Ethereum validator must compare like-for-like normalized headers. The
            // authenticated outer parent link was checked above; rewriting only this temporary
            // copy avoids comparing the Gov5 hash to its Ethereum-normalized hash.
            header.parent_hash = parent.hash_slow();
            return self.inner.validate_header_against_parent(
                &SealedHeader::seal_slow(header),
                &SealedHeader::seal_slow(parent),
            );
        }
        self.inner.validate_header_against_parent(header, parent)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use alloy_consensus::{BlockBody, EthereumReceipt, TxType};
    use alloy_primitives::{Address, B256};
    use bitvec::prelude::*;
    use n42_chainspec::ValidatorInfo;
    use n42_primitives::{BlsSecretKey, bls::AggregateSignature, consensus::QuorumCertificate};

    use crate::extra_data::{encode_qc_to_extra_data, extract_qc_from_extra_data};
    use crate::protocol::quorum::{
        commit_signing_message, signing_message, verify_commit_qc, verify_qc,
    };
    use crate::validator::ValidatorSet;

    fn test_key(seed: u8) -> BlsSecretKey {
        BlsSecretKey::key_gen(&[seed; 32]).expect("deterministic test key should be valid")
    }

    /// Helper: create a test validator set of size `n` along with the secret keys.
    fn test_validator_set(n: usize) -> (Vec<BlsSecretKey>, ValidatorSet) {
        let sks: Vec<_> = (0..n).map(|i| test_key(0x60 + i as u8)).collect();
        let infos: Vec<_> = sks
            .iter()
            .enumerate()
            .map(|(i, sk)| ValidatorInfo {
                address: Address::with_last_byte(i as u8),
                bls_public_key: sk.public_key(),
                p2p_peer_id: None,
            })
            .collect();
        let f = ((n as u32).saturating_sub(1)) / 3;
        let vs = ValidatorSet::new(&infos, f);
        (sks, vs)
    }

    #[test]
    fn test_new_without_validator_set() {
        let chain_spec = n42_chainspec::n42_dev_chainspec();
        let consensus = N42Consensus::new(chain_spec);
        assert!(consensus.validator_set.load_full().is_none());
    }

    #[test]
    fn gov5_header_profile_accepts_only_zero_empty_ommers_semantics() {
        let chain_spec = n42_chainspec::n42_dev_chainspec();
        let standard = N42Consensus::new(chain_spec.clone());
        let gov5 = N42Consensus::new(chain_spec).with_header_profile(N42HeaderProfile::Gov5H2);
        let body = BlockBody::<reth_ethereum_primitives::TransactionSigned>::default();
        let valid_extra = [b"N42H".as_slice(), &[0_u8; 8]].concat();
        let header = SealedHeader::seal_slow(Header {
            ommers_hash: B256::ZERO,
            difficulty: U256::ZERO,
            extra_data: valid_extra.clone().into(),
            ..Default::default()
        });

        assert!(
            standard
                .validate_body_against_header(&body, &header)
                .is_err()
        );
        gov5.validate_body_against_header(&body, &header).unwrap();

        let bad_tx_root = SealedHeader::seal_slow(Header {
            ommers_hash: B256::ZERO,
            difficulty: U256::ZERO,
            extra_data: valid_extra.into(),
            transactions_root: B256::ZERO,
            ..Default::default()
        });
        assert!(
            gov5.validate_body_against_header(&body, &bad_tx_root)
                .is_err()
        );
    }

    #[test]
    fn gov5_header_profile_bounds_and_identifies_h2_extra_data() {
        let chain_spec = reth_chainspec::MAINNET.clone();
        let standard = N42Consensus::new(chain_spec.clone());
        let gov5 = N42Consensus::new(chain_spec).with_header_profile(N42HeaderProfile::Gov5H2);
        let valid_extra = [b"N42H".as_slice(), &[0_u8; 8], &[0_u8; 96]].concat();
        let header = SealedHeader::seal_slow(Header {
            ommers_hash: B256::ZERO,
            difficulty: U256::ZERO,
            extra_data: valid_extra.clone().into(),
            base_fee_per_gas: Some(0),
            ..Default::default()
        });

        assert!(standard.validate_header(&header).is_err());
        gov5.validate_header(&header).unwrap();

        let malformed = SealedHeader::seal_slow(Header {
            ommers_hash: B256::ZERO,
            difficulty: U256::ZERO,
            extra_data: [b"BAD!".as_slice(), &[0_u8; 8]].concat().into(),
            base_fee_per_gas: Some(0),
            ..Default::default()
        });
        assert!(gov5.validate_header(&malformed).is_err());
        let legacy = SealedHeader::seal_slow(Header {
            ommers_hash: B256::ZERO,
            difficulty: U256::from(1),
            extra_data: [b"N42H".as_slice(), &[0_u8; 8]].concat().into(),
            base_fee_per_gas: Some(0),
            ..Default::default()
        });
        gov5.validate_header(&legacy).unwrap();
        let invalid_difficulty = Header {
            difficulty: U256::from(2),
            ..legacy.header().clone()
        };
        assert_eq!(
            validate_gov5_h2_header(&invalid_difficulty),
            Err(N42HeaderProfileError::Gov5Difficulty(U256::from(2)))
        );
        assert_eq!(
            validate_gov5_header_extra(&[0_u8; 11]),
            Err(N42HeaderProfileError::Gov5ExtraTooShort(11))
        );
        assert_eq!(
            validate_gov5_header_extra(&vec![0_u8; MAX_GOV5_HEADER_EXTRA_BYTES + 1]),
            Err(N42HeaderProfileError::Gov5ExtraTooLong(
                MAX_GOV5_HEADER_EXTRA_BYTES + 1
            ))
        );
    }

    #[test]
    fn gov5_replay_parent_validation_preserves_authenticated_outer_link() {
        let gov5 = N42Consensus::new(Arc::new(ChainSpec::default()))
            .with_header_profile(N42HeaderProfile::Gov5H2);
        let replay_header = |number, parent_hash, timestamp| Header {
            parent_hash,
            ommers_hash: EMPTY_OMMER_ROOT_HASH,
            difficulty: U256::ZERO,
            number,
            gas_limit: 30_000_000,
            timestamp,
            extra_data: Bytes::from(vec![0_u8; 32]),
            base_fee_per_gas: Some(0),
            withdrawals_root: Some(keccak256([])),
            blob_gas_used: Some(0),
            excess_blob_gas: Some(0),
            parent_beacon_block_root: Some(B256::ZERO),
            requests_hash: Some(EMPTY_ROOT_HASH),
            ..Default::default()
        };
        let parent = SealedHeader::seal_slow(replay_header(1, B256::repeat_byte(0x11), 4));
        let child = SealedHeader::seal_slow(replay_header(2, parent.hash(), 8));

        gov5.validate_header_against_parent(&child, &parent)
            .unwrap();

        let forged = SealedHeader::seal_slow(Header {
            parent_hash: B256::repeat_byte(0x42),
            ..child.header().clone()
        });
        assert!(matches!(
            gov5.validate_header_against_parent(&forged, &parent),
            Err(ConsensusError::ParentHashMismatch(_))
        ));
    }

    /// A live gov5 header under Prague carries no requests hash (the `0x80`
    /// placeholder); the inner rules see the empty requests hash instead, and
    /// post-execution then checks it against the requests execution produced.
    #[test]
    fn gov5_prague_header_without_requests_hash_is_accepted_when_no_requests_were_produced() {
        let chain_spec = reth_chainspec::MAINNET.clone();
        // Mainnet's Prague timestamp, which is also gov5's `pectraTime`.
        let prague = 1_746_612_311_u64;
        assert!(chain_spec.is_prague_active_at_timestamp(prague));
        assert!(!chain_spec.is_prague_active_at_timestamp(prague - 1));
        let gov5 = N42Consensus::new(chain_spec).with_header_profile(N42HeaderProfile::Gov5H2);
        let valid_extra = [b"N42H".as_slice(), &[0_u8; 8], &[0_u8; 96]].concat();
        let mut header = Header {
            ommers_hash: B256::ZERO,
            difficulty: U256::ZERO,
            extra_data: valid_extra.into(),
            base_fee_per_gas: Some(0),
            timestamp: prague + 12,
            number: 13_560_376,
            gas_limit: 30_000_000,
            withdrawals_root: Some(keccak256([])),
            blob_gas_used: Some(0),
            excess_blob_gas: Some(0),
            parent_beacon_block_root: Some(B256::ZERO),
            requests_hash: None,
            ..Default::default()
        };
        gov5.validate_header(&SealedHeader::seal_slow(header.clone()))
            .unwrap();
        assert_eq!(
            gov5.normalize_header(&header).unwrap().requests_hash,
            Some(alloy_eips::eip7685::EMPTY_REQUESTS_HASH)
        );
        // Before Prague nothing is filled in.
        header.timestamp = prague - 1;
        assert_eq!(gov5.normalize_header(&header).unwrap().requests_hash, None);

        // Post-execution: an empty request list matches; a produced request does not.
        let receipt = EthereumReceipt {
            tx_type: TxType::Legacy,
            success: true,
            cumulative_gas_used: 21_000,
            logs: Vec::new(),
        };
        let native_root = gov5_native_receipts_root(std::slice::from_ref(&receipt));
        header.timestamp = prague + 12;
        header.receipts_root = native_root;
        header.gas_used = 21_000;
        let block = RecoveredBlock::new_unhashed(
            EthBlock {
                header,
                body: Default::default(),
            },
            Vec::new(),
        );
        let result = BlockExecutionResult {
            receipts: vec![receipt],
            gas_used: 21_000,
            ..Default::default()
        };
        gov5.validate_block_post_execution(&block, &result, None, None)
            .unwrap();
        let with_request = BlockExecutionResult {
            requests: alloy_eips::eip7685::Requests::new(vec![alloy_primitives::Bytes::from(
                vec![1u8; 20],
            )]),
            ..result
        };
        assert!(matches!(
            gov5.validate_block_post_execution(&block, &with_request, None, None),
            Err(ConsensusError::BodyRequestsHashDiff(_))
        ));
    }

    #[test]
    fn gov5_post_execution_uses_native_receipt_commitment() {
        let chain_spec = reth_chainspec::MAINNET.clone();
        let standard = N42Consensus::new(chain_spec.clone());
        let gov5 = N42Consensus::new(chain_spec).with_header_profile(N42HeaderProfile::Gov5H2);
        let receipt = EthereumReceipt {
            tx_type: TxType::Legacy,
            success: true,
            cumulative_gas_used: 21_000,
            logs: Vec::new(),
        };
        let native_root = gov5_native_receipts_root(std::slice::from_ref(&receipt));
        let block = RecoveredBlock::new_unhashed(
            EthBlock {
                header: Header {
                    number: 13_000_000,
                    gas_used: 21_000,
                    receipts_root: native_root,
                    ..Default::default()
                },
                body: Default::default(),
            },
            Vec::new(),
        );
        let result = BlockExecutionResult {
            receipts: vec![receipt],
            gas_used: 21_000,
            ..Default::default()
        };

        assert!(
            standard
                .validate_block_post_execution(&block, &result, None, None)
                .is_err()
        );
        gov5.validate_block_post_execution(&block, &result, None, None)
            .unwrap();

        let mut forged = block.into_block();
        forged.header.receipts_root = B256::repeat_byte(0x42);
        let forged = RecoveredBlock::new_unhashed(forged, Vec::new());
        assert!(matches!(
            gov5.validate_block_post_execution(&forged, &result, None, None),
            Err(ConsensusError::BodyReceiptRootDiff(_))
        ));
    }

    #[test]
    fn test_with_validator_set() {
        let chain_spec = n42_chainspec::n42_dev_chainspec();
        let (_, vs) = test_validator_set(4);
        let consensus = N42Consensus::with_validator_set(chain_spec, vs);
        let loaded = consensus.validator_set.load_full();
        assert!(loaded.is_some());
        let vs_ref = loaded.as_ref().unwrap();
        assert_eq!(vs_ref.len(), 4);
        assert_eq!(vs_ref.quorum_size(), 3);
    }

    #[test]
    fn test_set_validator_set() {
        let chain_spec = n42_chainspec::n42_dev_chainspec();
        let mut consensus = N42Consensus::new(chain_spec);
        assert!(consensus.validator_set.load_full().is_none());

        let (_, vs) = test_validator_set(7);
        consensus.set_validator_set(vs);
        let loaded = consensus.validator_set.load_full();
        assert!(loaded.is_some());
        assert_eq!(loaded.as_ref().unwrap().len(), 7);
    }

    #[test]
    fn test_validator_set_resolver_overrides_current_set_for_matching_view() {
        let chain_spec = n42_chainspec::n42_dev_chainspec();
        let (_, current_vs) = test_validator_set(4);
        let (_, resolved_vs) = test_validator_set(7);
        let expected_resolved_len = resolved_vs.len();
        let expected_current_len = current_vs.len();
        let resolver_vs = resolved_vs.clone();
        let resolver: ValidatorSetResolver = Arc::new(move |view| {
            if view == 42 {
                Some(Arc::new(resolver_vs.clone()))
            } else {
                None
            }
        });

        let consensus = N42Consensus::with_validator_set_store_and_resolver(
            chain_spec,
            Arc::new(ArcSwapOption::from_pointee(current_vs)),
            Some(resolver),
        );

        let resolved = consensus.validator_set_for_view(42).unwrap();
        assert_eq!(resolved.len(), expected_resolved_len);

        let fallback = consensus.validator_set_for_view(1).unwrap();
        assert_eq!(fallback.len(), expected_current_len);
    }

    /// End-to-end test of the QC verification path used by adapter:
    /// encode QC → extract from extra_data → verify_qc
    #[test]
    fn test_qc_extraction_and_verification_path() {
        let (sks, vs) = test_validator_set(4);
        let view = 42u64;
        let block_hash = B256::repeat_byte(0xCC);

        let msg = signing_message(view, &block_hash);
        let sigs: Vec<_> = sks[0..3].iter().map(|sk| sk.sign(&msg)).collect();
        let sig_refs: Vec<_> = sigs.iter().collect();
        let agg = AggregateSignature::aggregate(&sig_refs).unwrap();
        let mut signers = bitvec![u8, Msb0; 0; 4];
        signers.set(0, true);
        signers.set(1, true);
        signers.set(2, true);

        let qc = QuorumCertificate {
            view,
            block_hash,
            aggregate_signature: agg,
            signers,
        };

        let extra_data = encode_qc_to_extra_data(&qc).unwrap();
        let extracted = extract_qc_from_extra_data(&extra_data)
            .expect("extraction should succeed")
            .expect("should contain a QC");

        let result = verify_qc(&extracted, &vs);
        assert!(result.is_ok());
    }

    /// End-to-end test of the CommitQC verification fallback path.
    /// adapter tries verify_qc first, then falls back to verify_commit_qc.
    #[test]
    fn test_commit_qc_verification_fallback_path() {
        let (sks, vs) = test_validator_set(4);
        let view = 99u64;
        let block_hash = B256::repeat_byte(0xDD);
        let changes_hash = B256::ZERO;

        let msg = commit_signing_message(view, &block_hash, &changes_hash);
        let sigs: Vec<_> = sks[0..3].iter().map(|sk| sk.sign(&msg)).collect();
        let sig_refs: Vec<_> = sigs.iter().collect();
        let agg = AggregateSignature::aggregate(&sig_refs).unwrap();
        let mut signers = bitvec![u8, Msb0; 0; 4];
        signers.set(0, true);
        signers.set(1, true);
        signers.set(2, true);

        let qc = QuorumCertificate {
            view,
            block_hash,
            aggregate_signature: agg,
            signers,
        };

        let extra_data = encode_qc_to_extra_data(&qc).unwrap();
        let extracted = extract_qc_from_extra_data(&extra_data).unwrap().unwrap();

        assert!(verify_qc(&extracted, &vs).is_err());

        let fallback_result = verify_qc(&extracted, &vs)
            .or_else(|_| verify_commit_qc(&extracted, &vs, &changes_hash));
        assert!(fallback_result.is_ok());
    }

    #[test]
    fn test_no_qc_in_extra_data_is_acceptable() {
        use alloy_primitives::Bytes;

        let result = extract_qc_from_extra_data(&Bytes::new());
        assert!(result.is_ok());
        assert!(result.unwrap().is_none());

        let result = extract_qc_from_extra_data(&Bytes::from_static(b"some other data"));
        assert!(result.is_ok());
        assert!(result.unwrap().is_none());
    }
}
