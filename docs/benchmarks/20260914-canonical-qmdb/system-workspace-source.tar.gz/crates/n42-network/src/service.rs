use alloy_primitives::{B256, keccak256};
use futures::StreamExt;
use libp2p::gossipsub;
use libp2p::swarm::SwarmEvent;
use libp2p::{Multiaddr, PeerId, Swarm};
use n42_primitives::ConsensusMessage;
use std::collections::{HashMap, HashSet, VecDeque};
use std::sync::{Arc, RwLock, Weak};
use std::time::{Duration, Instant};
use tokio::sync::mpsc;
use tokio::time::interval;

use crate::block_direct::{
    BLOCK_DIRECT_PROTOCOL, BlockDirectFrame, BlockDirectManifest, BlockDirectRequest,
    BlockDirectResponse, MAX_BLOCK_DIRECT_CHUNK_SIZE, MAX_BLOCK_DIRECT_SIZE,
    MIN_BLOCK_DIRECT_CHUNK_SIZE, block_direct_chunk_size,
};
use crate::consensus_direct::{ConsensusDirectRequest, ConsensusDirectResponse};
use crate::error::NetworkError;
use crate::gossipsub::handlers::{
    decode_consensus_message, encode_consensus_message, validate_message,
};
use crate::gossipsub::topics::{
    blob_sidecar_topic, block_announce_topic, consensus_topic, gov5_block_topic, gov5_h2_topic,
    h2_v4_topic, mempool_topic, verification_receipts_topic,
};
use crate::gov5_block::{Gov5BlockError, attributable_hash, decode_gov5_block_rlp};
use crate::gov5_rpc::{
    GOV5_BLOCK_BY_HASH_PROTOCOL, Gov5BlockByHashRequest, Gov5BlockByHashResponse,
    Gov5BlockPushRequest, Gov5BlockPushResponse, Gov5BodiesByRangeRequest,
    Gov5BodiesByRangeResponse, Gov5CanonicalBlockReader, Gov5HotstuffDirectRequest,
    Gov5HotstuffDirectResponse, Gov5Status,
};
use crate::h2_v4::{
    H2V4ChainIdentity, H2V4Envelope, decode_gossip as decode_h2_v4_gossip,
    encode_gossip as encode_h2_v4_gossip,
};
use crate::h2_wire::{H2Message, decode_gov5_gossip_message, encode_gov5_gossip_message};
use crate::reconnection::ReconnectionManager;
use crate::state_sync::{BlockSyncRequest, BlockSyncResponse, SYNC_PROTOCOL};
use crate::transport::{
    N42Behaviour, N42BehaviourEvent, deterministic_validator_peer_id, quic_udp_port,
    requested_quic_udp_socket_buffer_bytes, tune_quic_udp_socket_buffers,
};
use crate::tx_forward::{TxForwardRequest, TxForwardResponse};

const MAX_PENDING_RELIABLE_EVENTS: usize = 2048;
const MAX_PENDING_DATA_EVENTS: usize = 8192;
// Bound work done before polling the swarm. Draining an always-ready priority
// lane to exhaustion can prevent libp2p from opening the substreams requested
// by the commands that were just accepted.
const MAX_PRIORITY_COMMANDS_PER_TICK: usize = 8;
const RECENT_BLOCK_ANNOUNCEMENT_IDS_LIMIT: usize = 4096;
const DEFAULT_COMMAND_SEND_TIMEOUT_MS: u64 = 50;
const SYNC_RATE_WINDOW: Duration = Duration::from_secs(1);
const MAX_SYNC_REQUESTS_UNTRUSTED: u32 = 4;
const MAX_SYNC_REQUESTS_VALIDATOR: u32 = 32;
const MAX_PENDING_GOV5_BLOCK_REQUESTS: usize = 256;
// A reverse ancestry is intrinsically serial: the next parent hash is learned
// from the current body. Sending every step to every validator leaves several
// redundant ten-second request streams alive after the first response and
// eventually starves useful requests. Hedge by rotating peers after a short
// deadline instead of eagerly duplicating every request.
const MAX_GOV5_BLOCK_FETCH_FANOUT: usize = 1;
const MAX_RECENT_GOV5_BLOCK_REQUESTS: usize = 4096;
const GOV5_BLOCK_FULFILLED_RETENTION: Duration = Duration::from_secs(30);
const GOV5_BLOCK_REQUEST_COOLDOWN: Duration = Duration::from_millis(750);
// Re-arm before the orchestrator's two-second retry. Late transport responses
// are redundant and safely ignored after their request id is reaped.
const GOV5_BLOCK_REQUEST_STALE_AFTER: Duration = Duration::from_millis(1500);
const MAX_SERVED_GOV5_BLOCKS: usize = 1024;
const GOV5_RANGE_BLOCKS_PER_SECOND: f64 = 1024.0;
const GOV5_RANGE_BLOCKS_BURST: f64 = 4096.0;
const MAX_PENDING_GOV5_RANGES: usize = 8;
const MAX_PENDING_GOV5_RANGES_PER_PEER: usize = 2;
const MAX_INBOUND_BLOCK_DIRECT_TRANSFERS: usize = 32;
const BLOCK_DIRECT_TRANSFER_TIMEOUT: Duration = Duration::from_secs(30);
const DEFAULT_BLOCK_DIRECT_QUEUE_DEPTH: usize = 64;
const MAX_BLOCK_DIRECT_RETRIES: u8 = 2;

/// Check the requested hash before touching the serve cache. Only byte-identical
/// cached bodies can bypass transaction decoding and root verification.
fn cache_gov5_served_block(
    blocks: &mut HashMap<B256, Vec<u8>>,
    order: &mut VecDeque<B256>,
    rlp: &[u8],
    expected_hash: Option<B256>,
) -> Result<B256, Gov5BlockError> {
    let hash = attributable_hash(rlp).ok_or(Gov5BlockError::InvalidRlp)?;
    if let Some(expected) = expected_hash
        && hash != expected
    {
        return Err(Gov5BlockError::UnexpectedBlockHash {
            expected,
            actual: hash,
        });
    }
    if blocks.get(&hash).is_some_and(|cached| cached == rlp) {
        return Ok(hash);
    }
    decode_gov5_block_rlp(rlp)?;
    if !blocks.contains_key(&hash) {
        if blocks.len() >= MAX_SERVED_GOV5_BLOCKS
            && let Some(oldest) = order.pop_front()
        {
            blocks.remove(&oldest);
        }
        order.push_back(hash);
    }
    blocks.insert(hash, rlp.to_vec());
    Ok(hash)
}

#[derive(Debug, Clone, Copy)]
enum PendingBlockDirectFrame {
    Complete,
    Transfer { transfer_id: [u8; 32] },
}

#[derive(Debug)]
struct PendingBlockDirectRequest {
    peer: PeerId,
    bytes: usize,
    started_at: Instant,
    frame: PendingBlockDirectFrame,
    data: Arc<Vec<u8>>,
    attempt: u8,
}

#[derive(Debug)]
struct QueuedBlockDirect {
    data: Arc<Vec<u8>>,
    /// Digest of `data`, computed once and shared across peer fanout/retries.
    transfer_id: Option<[u8; 32]>,
    attempt: u8,
}

#[derive(Debug, Default)]
struct BlockDirectDigestCache {
    last: Option<(Weak<Vec<u8>>, [u8; 32])>,
}

impl BlockDirectDigestCache {
    fn transfer_id(&mut self, data: &Arc<Vec<u8>>) -> [u8; 32] {
        if let Some((cached, transfer_id)) = &self.last
            && cached
                .upgrade()
                .is_some_and(|cached| Arc::ptr_eq(&cached, data))
        {
            metrics::counter!("n42_block_direct_digest_cache_hits_total").increment(1);
            metrics::counter!(
                "n42_block_direct_digest_rehash_avoided_bytes_total",
                "site" => "peer_fanout",
            )
            .increment(data.len() as u64);
            return *transfer_id;
        }

        let transfer_id = *blake3::hash(data.as_slice()).as_bytes();
        self.last = Some((Arc::downgrade(data), transfer_id));
        metrics::counter!("n42_block_direct_digest_computations_total").increment(1);
        metrics::counter!("n42_block_direct_digest_computed_bytes_total")
            .increment(data.len() as u64);
        transfer_id
    }
}

#[derive(Debug)]
struct OutboundBlockDirectTransfer {
    manifest: BlockDirectManifest,
    data: Arc<Vec<u8>>,
    started_at: Instant,
}

#[derive(Debug)]
struct InboundBlockDirectTransfer {
    manifest: BlockDirectManifest,
    next_chunk: u32,
    data: Vec<u8>,
    started_at: Instant,
}

fn block_direct_queue_depth() -> usize {
    static DEPTH: std::sync::OnceLock<usize> = std::sync::OnceLock::new();
    *DEPTH.get_or_init(|| {
        std::env::var("N42_BLOCK_DIRECT_QUEUE_DEPTH")
            .ok()
            .and_then(|value| value.parse::<usize>().ok())
            .unwrap_or(DEFAULT_BLOCK_DIRECT_QUEUE_DEPTH)
            .clamp(2, 256)
    })
}

fn gov5_direct_source_authorized(
    peer: PeerId,
    trusted: bool,
    routed_validators: &HashMap<PeerId, u32>,
    authenticated_validators: &HashMap<PeerId, u32>,
) -> bool {
    trusted || routed_validators.contains_key(&peer) || authenticated_validators.contains_key(&peer)
}

fn stale_gov5_block_fetches(
    pending_hashes: &HashSet<B256>,
    recent_requests: &HashMap<B256, (Instant, PeerId)>,
    now: Instant,
) -> Vec<B256> {
    recent_requests
        .iter()
        .filter_map(|(hash, (attempted, _))| {
            (pending_hashes.contains(hash)
                && now.saturating_duration_since(*attempted) >= GOV5_BLOCK_REQUEST_STALE_AFTER)
                .then_some(*hash)
        })
        .collect()
}

fn gov5_block_fulfilled_recently(
    fulfilled: &mut HashMap<B256, Instant>,
    block_hash: B256,
    now: Instant,
) -> bool {
    if fulfilled.get(&block_hash).is_some_and(|fulfilled_at| {
        now.saturating_duration_since(*fulfilled_at) < GOV5_BLOCK_FULFILLED_RETENTION
    }) {
        return true;
    }
    fulfilled.remove(&block_hash);
    false
}

fn remember_gov5_block_fulfilled(
    fulfilled: &mut HashMap<B256, Instant>,
    block_hash: B256,
    now: Instant,
) {
    if fulfilled.len() >= MAX_RECENT_GOV5_BLOCK_REQUESTS {
        fulfilled.retain(|_, fulfilled_at| {
            now.saturating_duration_since(*fulfilled_at) < GOV5_BLOCK_FULFILLED_RETENTION
        });
    }
    if fulfilled.len() >= MAX_RECENT_GOV5_BLOCK_REQUESTS
        && let Some(oldest) = fulfilled
            .iter()
            .min_by_key(|(_, fulfilled_at)| *fulfilled_at)
            .map(|(hash, _)| *hash)
    {
        fulfilled.remove(&oldest);
    }
    fulfilled.insert(block_hash, now);
}

fn gov5_block_fetch_fanout(
    preferred: PeerId,
    last_peer: Option<PeerId>,
    advertised_connected: &[PeerId],
    connected: &[PeerId],
) -> Vec<PeerId> {
    let mut peers = Vec::with_capacity(MAX_GOV5_BLOCK_FETCH_FANOUT);
    let mut push = |peer: PeerId| {
        if peers.len() < MAX_GOV5_BLOCK_FETCH_FANOUT && !peers.contains(&peer) {
            peers.push(peer);
        }
    };

    // Preserve the authenticated message source as the first choice. The
    // orchestrator remembers attempted peers and rotates through the complete
    // connected set on short deadlines, so only one transport stream is needed
    // per attempt and the previous peer remains the final fallback.
    if connected.contains(&preferred) && Some(preferred) != last_peer {
        push(preferred);
    }
    for peer in advertised_connected
        .iter()
        .chain(connected)
        .copied()
        .filter(|peer| Some(*peer) != last_peer)
    {
        push(peer);
    }
    if let Some(last_peer) = last_peer
        && connected.contains(&last_peer)
    {
        push(last_peer);
    }
    peers
}

#[derive(Clone, Copy)]
struct SyncRequestWindow {
    started_at: Instant,
    accepted: u32,
}

impl SyncRequestWindow {
    fn new(now: Instant) -> Self {
        Self {
            started_at: now,
            accepted: 0,
        }
    }

    fn allow(&mut self, now: Instant, limit: u32) -> bool {
        if now.duration_since(self.started_at) >= SYNC_RATE_WINDOW {
            self.started_at = now;
            self.accepted = 0;
        }
        if self.accepted >= limit {
            return false;
        }
        self.accepted += 1;
        true
    }
}

#[derive(Clone, Copy)]
struct Gov5RangeQuota {
    tokens: f64,
    updated_at: Instant,
}

impl Gov5RangeQuota {
    fn new(now: Instant) -> Self {
        Self {
            tokens: GOV5_RANGE_BLOCKS_BURST,
            updated_at: now,
        }
    }

    fn allow(&mut self, now: Instant, blocks: u64) -> bool {
        let elapsed = now.saturating_duration_since(self.updated_at).as_secs_f64();
        self.tokens =
            (self.tokens + elapsed * GOV5_RANGE_BLOCKS_PER_SECOND).min(GOV5_RANGE_BLOCKS_BURST);
        self.updated_at = now;
        let cost = blocks as f64;
        if cost > self.tokens {
            return false;
        }
        self.tokens -= cost;
        true
    }
}

fn command_send_timeout() -> Duration {
    static TIMEOUT: std::sync::OnceLock<Duration> = std::sync::OnceLock::new();
    *TIMEOUT.get_or_init(|| {
        Duration::from_millis(
            std::env::var("N42_NETWORK_SEND_TIMEOUT_MS")
                .ok()
                .and_then(|value| value.parse::<u64>().ok())
                .unwrap_or(DEFAULT_COMMAND_SEND_TIMEOUT_MS),
        )
    })
}

#[derive(Default)]
struct RecentBlockAnnouncementDedup {
    order: VecDeque<B256>,
    ids: HashSet<B256>,
}

impl RecentBlockAnnouncementDedup {
    fn observe(&mut self, data: &[u8]) -> bool {
        let id = keccak256(data);
        if self.ids.contains(&id) {
            return true;
        }

        self.ids.insert(id);
        self.order.push_back(id);
        if self.order.len() > RECENT_BLOCK_ANNOUNCEMENT_IDS_LIMIT
            && let Some(evicted) = self.order.pop_front()
        {
            self.ids.remove(&evicted);
        }
        false
    }
}

/// Commands sent to the network service from the node layer.
#[derive(Debug)]
pub enum NetworkCommand {
    BroadcastConsensus(ConsensusMessage),
    BroadcastH2V4(H2V4Envelope),
    BroadcastGov5Block(Vec<u8>),
    SendDirect {
        peer: PeerId,
        message: ConsensusMessage,
    },
    AnnounceBlock(Vec<u8>),
    BroadcastTransaction(Vec<u8>),
    BroadcastBlobSidecar(Vec<u8>),
    /// Send block data directly to a specific peer (leader → validator).
    SendBlockDirect {
        peer: PeerId,
        data: Arc<Vec<u8>>,
    },
    /// Forward a batch of RLP-encoded transactions to the current leader.
    ForwardTxBatch {
        peer: PeerId,
        txs: Vec<Vec<u8>>,
    },
    Dial(Multiaddr),
    RequestSync {
        peer: PeerId,
        request: BlockSyncRequest,
    },
    /// Fetch one Gov5 block body from an already-connected peer.
    RequestGov5BlockByHash {
        peer: PeerId,
        block_hash: B256,
    },
    /// Retire an in-flight Gov5 hash fetch after the same block body arrived
    /// through gossip or the validator direct-push lane.
    CancelGov5BlockFetch {
        block_hash: B256,
    },
    SendSyncResponse {
        request_id: u64,
        response: BlockSyncResponse,
    },
    RegisterPeer {
        peer_id: PeerId,
        addrs: Vec<Multiaddr>,
        trusted: bool,
    },
    AuthenticateValidatorPeer {
        peer_id: PeerId,
        validator_index: u32,
    },
    ReplaceExpectedValidatorPeers {
        peers: HashMap<u32, PeerId>,
    },
    AddKademliaPeer {
        peer_id: PeerId,
        addrs: Vec<Multiaddr>,
    },
    /// Update validator context for Rotor relay forwarding.
    SetValidatorContext {
        my_index: u32,
        validator_count: u32,
    },
}

/// Events produced by the network service for the node layer.
#[derive(Debug)]
pub enum NetworkEvent {
    ConsensusMessage {
        source: PeerId,
        message: Box<ConsensusMessage>,
    },
    /// Strictly decoded canonical Gov5 H2 message. In H2-v4 participant mode
    /// this is promoted to the reliable consensus lane and converted by the
    /// orchestrator; otherwise it remains observer data.
    Gov5H2Message {
        source: PeerId,
        message: Box<H2Message>,
    },
    /// Snappy-decoded Gov5 ETH-style RLP block. It remains untrusted until the
    /// observer validates its header/body commitments and matches its hash to
    /// an authenticated H2-v4 Decide.
    Gov5Block {
        source: PeerId,
        rlp: Vec<u8>,
    },
    /// Gov5 block returned by the hash-bound fetch-on-miss protocol.
    Gov5BlockFetched {
        source: PeerId,
        requested_hash: B256,
        rlp: Vec<u8>,
    },
    Gov5BlockFetchFailed {
        source: PeerId,
        block_hash: B256,
        error: String,
        /// True when the failure is a verdict about content the requested hash
        /// commits to, so no peer can serve anything that decodes differently.
        /// Consumers must stop re-requesting the hash; see
        /// [`Gov5BlockError::is_permanent`].
        permanent: bool,
    },
    H2V4Message {
        source: PeerId,
        envelope: Box<H2V4Envelope>,
    },
    BlockAnnouncement {
        source: PeerId,
        data: Vec<u8>,
    },
    VerificationReceipt {
        source: PeerId,
        data: Vec<u8>,
    },
    TransactionReceived {
        source: PeerId,
        data: Vec<u8>,
    },
    BlobSidecarReceived {
        source: PeerId,
        data: Vec<u8>,
    },
    PeerConnected(PeerId),
    PeerDisconnected(PeerId),
    /// Batch of transactions forwarded from a non-leader validator.
    TxForwardReceived {
        source: PeerId,
        txs: Vec<Vec<u8>>,
    },
    /// Leader granted (or revoked) TX forward credit to this follower.
    TxForwardCreditUpdate {
        remaining_credit: Option<u32>,
    },
    SyncRequest {
        peer: PeerId,
        request_id: u64,
        request: BlockSyncRequest,
    },
    SyncResponse {
        peer: PeerId,
        response: BlockSyncResponse,
    },
    SyncRequestFailed {
        peer: PeerId,
        error: String,
        /// True when the peer never advertised the N42 state-sync protocol, so
        /// no retry against it can succeed. Consumers should drop it from the
        /// sync rotation rather than come back every interval.
        unsupported_protocol: bool,
    },
}

fn event_uses_consensus_lane(event: &NetworkEvent, h2_v4_participant: bool) -> bool {
    matches!(
        event,
        NetworkEvent::ConsensusMessage { .. } | NetworkEvent::BlockAnnouncement { .. }
    ) || h2_v4_participant
        && matches!(
            event,
            NetworkEvent::Gov5H2Message { .. }
                | NetworkEvent::H2V4Message { .. }
                | NetworkEvent::Gov5Block { .. }
                | NetworkEvent::Gov5BlockFetched { .. }
                | NetworkEvent::Gov5BlockFetchFailed { .. }
        )
}

/// Handle for sending commands to the running `NetworkService`.
///
/// Cheaply cloneable. The main interface for the node layer to interact with
/// the network.
#[derive(Clone, Debug)]
pub struct NetworkHandle {
    command_tx: mpsc::Sender<NetworkCommand>,
    /// High-priority channel for block data and consensus commands.
    /// These bypass the potentially deep tx-broadcast backlog in `command_tx`.
    priority_tx: mpsc::Sender<NetworkCommand>,
    /// Best-known validator index → PeerId mapping. Identify populates this early,
    /// and successful consensus-message authentication can later overwrite it with
    /// a stronger binding for the same validator index.
    validator_peer_map: Arc<RwLock<HashMap<u32, PeerId>>>,
}

impl NetworkHandle {
    pub fn new(
        command_tx: mpsc::Sender<NetworkCommand>,
        priority_tx: mpsc::Sender<NetworkCommand>,
    ) -> Self {
        Self {
            command_tx,
            priority_tx,
            validator_peer_map: Arc::new(RwLock::new(HashMap::new())),
        }
    }

    /// Returns the PeerId for a given validator index, if known.
    pub fn validator_peer(&self, index: u32) -> Option<PeerId> {
        match self.validator_peer_map.read() {
            Ok(map) => map.get(&index).copied(),
            Err(e) => {
                tracing::error!("validator_peer_map lock poisoned: {}", e);
                None
            }
        }
    }

    pub fn send_direct(&self, peer: PeerId, msg: ConsensusMessage) -> Result<(), NetworkError> {
        self.send_priority(NetworkCommand::SendDirect { peer, message: msg })
    }

    pub fn broadcast_consensus(&self, msg: ConsensusMessage) -> Result<(), NetworkError> {
        self.send_priority(NetworkCommand::BroadcastConsensus(msg))
    }

    pub fn broadcast_h2_v4(&self, envelope: H2V4Envelope) -> Result<(), NetworkError> {
        self.send_priority(NetworkCommand::BroadcastH2V4(envelope))
    }

    pub fn broadcast_gov5_block(&self, rlp: Vec<u8>) -> Result<(), NetworkError> {
        self.send_priority(NetworkCommand::BroadcastGov5Block(rlp))
    }

    pub fn announce_block(&self, data: Vec<u8>) -> Result<(), NetworkError> {
        self.send_priority(NetworkCommand::AnnounceBlock(data))
    }

    pub fn broadcast_transaction(&self, data: Vec<u8>) -> Result<(), NetworkError> {
        self.send(NetworkCommand::BroadcastTransaction(data))
    }

    pub fn broadcast_blob_sidecar(&self, data: Vec<u8>) -> Result<(), NetworkError> {
        self.send(NetworkCommand::BroadcastBlobSidecar(data))
    }

    /// Sends block data directly to a specific validator peer.
    pub fn send_block_direct(&self, peer: PeerId, data: Vec<u8>) -> Result<(), NetworkError> {
        self.send_priority(NetworkCommand::SendBlockDirect {
            peer,
            data: Arc::new(data),
        })
    }

    /// Forwards a batch of RLP-encoded transactions to the current leader.
    pub fn forward_tx_batch(&self, peer: PeerId, txs: Vec<Vec<u8>>) -> Result<(), NetworkError> {
        self.send(NetworkCommand::ForwardTxBatch { peer, txs })
    }

    /// Returns all known validator peers (index → PeerId).
    pub fn all_validator_peers(&self) -> Vec<(u32, PeerId)> {
        match self.validator_peer_map.read() {
            Ok(map) => map.iter().map(|(&idx, &pid)| (idx, pid)).collect(),
            Err(_) => Vec::new(),
        }
    }

    pub fn dial(&self, addr: Multiaddr) -> Result<(), NetworkError> {
        self.send(NetworkCommand::Dial(addr))
    }

    pub fn request_sync(
        &self,
        peer: PeerId,
        request: BlockSyncRequest,
    ) -> Result<(), NetworkError> {
        self.send(NetworkCommand::RequestSync { peer, request })
    }

    pub fn send_sync_response(
        &self,
        request_id: u64,
        response: BlockSyncResponse,
    ) -> Result<(), NetworkError> {
        self.send(NetworkCommand::SendSyncResponse {
            request_id,
            response,
        })
    }

    pub async fn request_sync_reliable(
        &self,
        peer: PeerId,
        request: BlockSyncRequest,
    ) -> Result<(), NetworkError> {
        Self::send_with_backpressure(
            &self.command_tx,
            NetworkCommand::RequestSync { peer, request },
        )
        .await
    }

    pub async fn send_sync_response_reliable(
        &self,
        request_id: u64,
        response: BlockSyncResponse,
    ) -> Result<(), NetworkError> {
        Self::send_with_backpressure(
            &self.command_tx,
            NetworkCommand::SendSyncResponse {
                request_id,
                response,
            },
        )
        .await
    }

    /// Registers a peer for automatic reconnection.
    /// Trusted peers are retried indefinitely; discovered peers up to a limited count.
    pub fn register_peer(
        &self,
        peer_id: PeerId,
        addrs: Vec<Multiaddr>,
        trusted: bool,
    ) -> Result<(), NetworkError> {
        const MAX_ADDRS_PER_PEER: usize = 16;
        if addrs.len() > MAX_ADDRS_PER_PEER {
            return Err(NetworkError::Dial(format!(
                "too many addresses for peer ({}), max is {}",
                addrs.len(),
                MAX_ADDRS_PER_PEER
            )));
        }
        self.send(NetworkCommand::RegisterPeer {
            peer_id,
            addrs,
            trusted,
        })
    }

    /// Promotes a connected peer to an authenticated validator after the caller
    /// has verified a single-validator consensus message signed by that validator.
    pub fn authenticate_validator_peer(
        &self,
        peer_id: PeerId,
        validator_index: u32,
    ) -> Result<(), NetworkError> {
        self.send(NetworkCommand::AuthenticateValidatorPeer {
            peer_id,
            validator_index,
        })
    }

    pub async fn authenticate_validator_peer_reliable(
        &self,
        peer_id: PeerId,
        validator_index: u32,
    ) -> Result<(), NetworkError> {
        Self::send_with_backpressure(
            &self.command_tx,
            NetworkCommand::AuthenticateValidatorPeer {
                peer_id,
                validator_index,
            },
        )
        .await
    }

    pub fn replace_expected_validator_peers(
        &self,
        peers: HashMap<u32, PeerId>,
    ) -> Result<(), NetworkError> {
        self.send(NetworkCommand::ReplaceExpectedValidatorPeers { peers })
    }

    pub async fn replace_expected_validator_peers_reliable(
        &self,
        peers: HashMap<u32, PeerId>,
    ) -> Result<(), NetworkError> {
        Self::send_with_backpressure(
            &self.command_tx,
            NetworkCommand::ReplaceExpectedValidatorPeers { peers },
        )
        .await
    }

    pub fn add_kademlia_peer(
        &self,
        peer_id: PeerId,
        addrs: Vec<Multiaddr>,
    ) -> Result<(), NetworkError> {
        self.send(NetworkCommand::AddKademliaPeer { peer_id, addrs })
    }

    /// Updates the network layer's validator context for Rotor relay forwarding.
    ///
    /// Best-effort (returns `()`), but uses backpressure rather than a bare
    /// `try_send`: this is called once per epoch transition, so dropping it on a
    /// momentarily-full command channel would leave the relay layer forwarding
    /// against a stale `my_index`/`validator_count` with no trace. Backpressure +
    /// a warning give delivery a real chance and surface the rare failure.
    pub async fn set_validator_context(&self, my_index: u32, validator_count: u32) {
        if let Err(error) = Self::send_with_backpressure(
            &self.command_tx,
            NetworkCommand::SetValidatorContext {
                my_index,
                validator_count,
            },
        )
        .await
        {
            tracing::warn!(
                %error,
                my_index,
                validator_count,
                "failed to update network validator context for Rotor relay"
            );
            metrics::counter!("n42_network_set_validator_context_drops_total").increment(1);
        }
    }

    fn send(&self, cmd: NetworkCommand) -> Result<(), NetworkError> {
        self.command_tx.try_send(cmd).map_err(|error| match error {
            tokio::sync::mpsc::error::TrySendError::Full(_) => NetworkError::ChannelFull,
            tokio::sync::mpsc::error::TrySendError::Closed(_) => NetworkError::ChannelClosed,
        })
    }

    /// Send via the high-priority channel (block data, consensus, sync).
    fn send_priority(&self, cmd: NetworkCommand) -> Result<(), NetworkError> {
        self.priority_tx.try_send(cmd).map_err(|error| match error {
            tokio::sync::mpsc::error::TrySendError::Full(_) => NetworkError::ChannelFull,
            tokio::sync::mpsc::error::TrySendError::Closed(_) => NetworkError::ChannelClosed,
        })
    }

    async fn send_with_backpressure(
        tx: &mpsc::Sender<NetworkCommand>,
        cmd: NetworkCommand,
    ) -> Result<(), NetworkError> {
        match tx.try_send(cmd) {
            Ok(()) => Ok(()),
            Err(tokio::sync::mpsc::error::TrySendError::Full(cmd)) => {
                match tokio::time::timeout(command_send_timeout(), tx.send(cmd)).await {
                    Ok(Ok(())) => Ok(()),
                    Ok(Err(_)) => Err(NetworkError::ChannelClosed),
                    Err(_) => Err(NetworkError::ChannelFull),
                }
            }
            Err(tokio::sync::mpsc::error::TrySendError::Closed(_)) => {
                Err(NetworkError::ChannelClosed)
            }
        }
    }

    pub async fn broadcast_consensus_reliable(
        &self,
        msg: ConsensusMessage,
    ) -> Result<(), NetworkError> {
        Self::send_with_backpressure(&self.priority_tx, NetworkCommand::BroadcastConsensus(msg))
            .await
    }

    pub async fn broadcast_h2_v4_reliable(
        &self,
        envelope: H2V4Envelope,
    ) -> Result<(), NetworkError> {
        Self::send_with_backpressure(&self.priority_tx, NetworkCommand::BroadcastH2V4(envelope))
            .await
    }

    pub async fn broadcast_gov5_block_reliable(&self, rlp: Vec<u8>) -> Result<(), NetworkError> {
        Self::send_with_backpressure(&self.priority_tx, NetworkCommand::BroadcastGov5Block(rlp))
            .await
    }

    pub async fn send_direct_reliable(
        &self,
        peer: PeerId,
        msg: ConsensusMessage,
    ) -> Result<(), NetworkError> {
        Self::send_with_backpressure(
            &self.priority_tx,
            NetworkCommand::SendDirect { peer, message: msg },
        )
        .await
    }

    pub async fn announce_block_reliable(&self, data: Vec<u8>) -> Result<(), NetworkError> {
        Self::send_with_backpressure(&self.priority_tx, NetworkCommand::AnnounceBlock(data)).await
    }

    pub async fn send_block_direct_reliable(
        &self,
        peer: PeerId,
        data: Arc<Vec<u8>>,
    ) -> Result<(), NetworkError> {
        Self::send_with_backpressure(
            &self.priority_tx,
            NetworkCommand::SendBlockDirect { peer, data },
        )
        .await
    }

    pub fn request_gov5_block_by_hash(
        &self,
        peer: PeerId,
        block_hash: B256,
    ) -> Result<(), NetworkError> {
        self.send_priority(NetworkCommand::RequestGov5BlockByHash { peer, block_hash })
    }

    pub async fn cancel_gov5_block_fetch_reliable(
        &self,
        block_hash: B256,
    ) -> Result<(), NetworkError> {
        Self::send_with_backpressure(
            &self.priority_tx,
            NetworkCommand::CancelGov5BlockFetch { block_hash },
        )
        .await
    }
}

/// The network service drives the libp2p swarm and bridges messages between
/// the P2P network and the node layer.
pub struct NetworkService {
    swarm: Swarm<N42Behaviour>,
    command_rx: mpsc::Receiver<NetworkCommand>,
    /// High-priority commands (block data, consensus) — drained before `command_rx`.
    priority_rx: mpsc::Receiver<NetworkCommand>,
    /// High-priority channel for consensus messages (Vote, Proposal, PrepareQC, etc.).
    consensus_event_tx: mpsc::Sender<NetworkEvent>,
    /// Lower-priority channel for data events (BlockData, TX, Sync, Peers).
    event_tx: mpsc::Sender<NetworkEvent>,
    /// Reliable consensus/block events that could not be delivered immediately.
    pending_reliable_events: VecDeque<NetworkEvent>,
    /// Reliable data-plane events that could not be delivered immediately.
    pending_data_events: VecDeque<NetworkEvent>,
    consensus_topic_hash: gossipsub::TopicHash,
    gov5_h2_topic_hash: Option<gossipsub::TopicHash>,
    gov5_block_topic_hash: Option<gossipsub::TopicHash>,
    h2_v4_topic_hash: Option<gossipsub::TopicHash>,
    h2_v4_identity: Option<H2V4ChainIdentity>,
    h2_v4_participant: bool,
    gov5_status: Option<Gov5Status>,
    pending_gov5_status_peers: HashSet<PeerId>,
    /// Peers that completed a status exchange for this exact genesis. Range
    /// serving is fail-closed until the Noise-authenticated PeerId is both a
    /// configured/trusted validator and bound to this chain.
    gov5_chain_authenticated_peers: HashSet<PeerId>,
    /// Persistent canonical storage used by Gov5 range sync. Deliberately
    /// separate from the recent `gov5_served_blocks` recovery cache.
    gov5_canonical_blocks: Option<Gov5CanonicalBlockReader>,
    /// Per-peer block-cost token buckets matching Gov5's 1024 block/s and
    /// 4x burst defaults.
    gov5_range_quotas: HashMap<PeerId, Gov5RangeQuota>,
    /// Accepted range streams still being written by request-response.
    pending_gov5_ranges: HashMap<libp2p::request_response::InboundRequestId, PeerId>,
    block_announce_topic_hash: gossipsub::TopicHash,
    mempool_topic_hash: gossipsub::TopicHash,
    blob_sidecar_topic_hash: gossipsub::TopicHash,
    verification_receipts_topic_hash: gossipsub::TopicHash,
    /// Maps internal request ID → libp2p ResponseChannel for sending sync replies.
    pending_sync_channels:
        HashMap<u64, libp2p::request_response::ResponseChannel<BlockSyncResponse>>,
    /// Outbound block pushes retained until the remote validator ACKs or the
    /// request-response protocol reports a transport failure. Queue admission
    /// alone is not delivery, so this is also the source of direct-path
    /// latency and backlog diagnostics.
    pending_block_direct_requests:
        HashMap<libp2p::request_response::OutboundRequestId, PendingBlockDirectRequest>,
    /// One ACK-paced manifest/chunk transfer per peer. Every chunk references
    /// the original Arc envelope; the sender does not allocate chunk copies.
    outbound_block_direct_transfers: HashMap<PeerId, OutboundBlockDirectTransfer>,
    /// Authenticated receiver-side reassembly, bounded by count, total size,
    /// strict next index and a 30-second lifetime.
    inbound_block_direct_transfers: HashMap<(PeerId, [u8; 32]), InboundBlockDirectTransfer>,
    /// Ordered per-peer block queue behind the single in-flight QUIC data
    /// substream. It preserves every intermediate block instead of coalescing
    /// to the latest hash, and is bounded to the request-timeout horizon.
    queued_block_direct_by_peer: HashMap<PeerId, VecDeque<QueuedBlockDirect>>,
    /// One-entry identity cache: fanout commands for a block share the same Arc,
    /// so its transfer digest is calculated once rather than once per peer.
    block_direct_digest_cache: BlockDirectDigestCache,
    pending_gov5_block_requests: HashMap<libp2p::request_response::OutboundRequestId, B256>,
    /// Hash-level de-duplication keeps a stream of QCs for the same missing
    /// ancestry from creating an unbounded request-response storm.
    pending_gov5_block_hashes: HashSet<B256>,
    /// Last attempt and peer per hash, used for bounded retry and peer rotation.
    recent_gov5_block_requests: HashMap<B256, (Instant, PeerId)>,
    /// Short tombstones for bodies already delivered through any authenticated
    /// path. The observer and participant can enqueue request/cancel commands
    /// concurrently; retaining fulfillment closes the cancel-before-request
    /// ordering without making historical hashes permanent.
    recent_gov5_block_fulfilled: HashMap<B256, Instant>,
    /// Peers that advertised the native Gov5 block-by-hash protocol.
    gov5_block_by_hash_peers: HashSet<PeerId>,
    /// Peers that advertised N42's native state-sync protocol. Gov5 peers do
    /// not implement it and must never receive those requests.
    state_sync_peers: HashSet<PeerId>,
    /// Peers whose Identify protocol set contains the block-direct protocol.
    /// Dispatch remains compatible with pre-Identify startup, but every large
    /// request records this capability bit so unsupported negotiation is no
    /// longer indistinguishable from a congested QUIC stream.
    block_direct_peers: HashSet<PeerId>,
    /// QUIC listener ports whose kernel UDP buffers were successfully tuned.
    tuned_quic_udp_ports: HashSet<u16>,
    /// Recently broadcast canonical Gov5 blocks, retained so followers that
    /// receive the proposal before the block can recover through Gov5's native
    /// block-by-hash RPC.
    gov5_served_blocks: HashMap<B256, Vec<u8>>,
    /// Insertion order for `gov5_served_blocks` eviction. HashMap iteration
    /// order is arbitrary, and evicting an arbitrary entry preferentially
    /// drops exactly the fresh blocks followers are most likely to fetch.
    gov5_served_block_order: VecDeque<B256>,
    /// Fixed-window protection for inbound catch-up work. Validators receive a
    /// higher allowance, while unauthenticated peers cannot monopolize the
    /// bounded response-channel table or node-side database reads.
    sync_request_windows: HashMap<PeerId, SyncRequestWindow>,
    next_sync_id: u64,
    /// Configured validator index -> expected PeerId bindings.
    expected_validator_peer_ids: HashMap<u32, PeerId>,
    /// Best-known validator index → PeerId mapping used for outbound routing.
    validator_peer_map: Arc<RwLock<HashMap<u32, PeerId>>>,
    /// Reverse map for best-known validator routing information.
    peer_validator_map: HashMap<PeerId, u32>,
    /// Cryptographically authenticated validator index → PeerId mapping.
    authenticated_validator_peer_map: HashMap<u32, PeerId>,
    /// Reverse map used to authorize inbound block_direct / tx_forward traffic.
    authenticated_peer_validator_map: HashMap<PeerId, u32>,
    reconnection: ReconnectionManager,
    /// When true, skip GossipSub tx publishing/forwarding to avoid event queue flooding.
    tx_gossip_disabled: bool,
    /// Whether validators without explicit `p2p_peer_id` bindings may fall back
    /// to deterministic PeerIds derived from their public validator index.
    allow_deterministic_peer_ids: bool,
    /// Recent block-announcement payload hashes observed across both GossipSub
    /// and direct push. This suppresses cross-channel duplicates before they
    /// reach the consensus/orchestrator task.
    recent_block_announcements: RecentBlockAnnouncementDedup,
    /// Local validator index (None if not a validator or if observer mode)
    my_validator_index: Option<u32>,
    /// Current validator count for Rotor relay computation
    validator_count: u32,
}

fn claimed_validator_index(agent_version: &str) -> Option<u32> {
    agent_version
        .strip_prefix("n42/1.0.0/v")
        .and_then(|idx| idx.parse::<u32>().ok())
}

fn expected_peer_id_for_validator(
    expected_validator_peer_ids: &HashMap<u32, PeerId>,
    validator_index: u32,
    allow_deterministic_peer_ids: bool,
) -> eyre::Result<PeerId> {
    if let Some(peer_id) = expected_validator_peer_ids.get(&validator_index).copied() {
        return Ok(peer_id);
    }

    if allow_deterministic_peer_ids {
        deterministic_validator_peer_id(validator_index)
    } else {
        Err(eyre::eyre!(
            "no configured expected peer id for validator index {validator_index}"
        ))
    }
}

fn validator_index_for_expected_peer(
    expected_validator_peer_ids: &HashMap<u32, PeerId>,
    peer_id: PeerId,
) -> Option<u32> {
    expected_validator_peer_ids
        .iter()
        .find_map(|(&index, &expected)| (expected == peer_id).then_some(index))
}

fn push_bounded_backlog<T>(queue: &mut VecDeque<T>, max_len: usize, item: T, label: &'static str) {
    if queue.len() >= max_len {
        metrics::counter!("n42_network_event_drops_total").increment(1);
        metrics::counter!("n42_network_backlog_overflow_total", "backlog" => label).increment(1);
        tracing::warn!(
            backlog = label,
            max_len,
            "reliable event backlog full, dropping newest event"
        );
        return;
    }

    queue.push_back(item);
}

impl NetworkService {
    /// Creates a new network service. Returns the service, a handle, a consensus event
    /// receiver (high-priority), and a data event receiver (lower-priority).
    ///
    /// Splitting the channels ensures that consensus messages (Vote, Proposal, CommitVote,
    /// PrepareQC, Decide, Timeout, NewView) are never queued behind high-volume data
    /// events (TxForward, BlockAnnouncement, TransactionReceived).
    pub fn new(
        swarm: Swarm<N42Behaviour>,
    ) -> Result<
        (
            Self,
            NetworkHandle,
            mpsc::Receiver<NetworkEvent>,
            mpsc::Receiver<NetworkEvent>,
        ),
        NetworkError,
    > {
        Self::new_with_options(swarm, HashMap::new(), true, None, None, None, false)
    }

    /// Creates a non-voting service which also subscribes to the gov5 H2 topic
    /// derived from this chain's genesis hash.
    pub fn new_gov5_h2_observer(
        swarm: Swarm<N42Behaviour>,
        chain_id: u64,
        genesis_hash: B256,
    ) -> Result<
        (
            Self,
            NetworkHandle,
            mpsc::Receiver<NetworkEvent>,
            mpsc::Receiver<NetworkEvent>,
        ),
        NetworkError,
    > {
        Self::new_with_options(
            swarm,
            HashMap::new(),
            true,
            Some(gov5_h2_topic(genesis_hash)),
            Some(gov5_block_topic(genesis_hash)),
            Some(H2V4ChainIdentity {
                chain_id,
                genesis_hash,
            }),
            false,
        )
    }

    /// Creates a voting H2-v4 network endpoint. Unlike observer mode, inbound
    /// H2-v4 frames use the high-priority consensus channel and outbound H2-v4
    /// publication is enabled. The caller must still enable the matching
    /// consensus signing profile before processing messages.
    pub fn new_gov5_h2_participant(
        swarm: Swarm<N42Behaviour>,
        expected_validator_peer_ids: HashMap<u32, PeerId>,
        allow_deterministic_peer_ids: bool,
        chain_id: u64,
        genesis_hash: B256,
    ) -> Result<
        (
            Self,
            NetworkHandle,
            mpsc::Receiver<NetworkEvent>,
            mpsc::Receiver<NetworkEvent>,
        ),
        NetworkError,
    > {
        Self::new_with_options(
            swarm,
            expected_validator_peer_ids,
            allow_deterministic_peer_ids,
            Some(gov5_h2_topic(genesis_hash)),
            Some(gov5_block_topic(genesis_hash)),
            Some(H2V4ChainIdentity {
                chain_id,
                genesis_hash,
            }),
            true,
        )
    }

    pub fn new_with_expected_validator_peer_ids(
        swarm: Swarm<N42Behaviour>,
        expected_validator_peer_ids: HashMap<u32, PeerId>,
        allow_deterministic_peer_ids: bool,
    ) -> Result<
        (
            Self,
            NetworkHandle,
            mpsc::Receiver<NetworkEvent>,
            mpsc::Receiver<NetworkEvent>,
        ),
        NetworkError,
    > {
        Self::new_with_options(
            swarm,
            expected_validator_peer_ids,
            allow_deterministic_peer_ids,
            None,
            None,
            None,
            false,
        )
    }

    fn new_with_options(
        mut swarm: Swarm<N42Behaviour>,
        expected_validator_peer_ids: HashMap<u32, PeerId>,
        allow_deterministic_peer_ids: bool,
        gov5_h2_observer_topic: Option<gossipsub::IdentTopic>,
        gov5_block_observer_topic: Option<gossipsub::IdentTopic>,
        h2_v4_identity: Option<H2V4ChainIdentity>,
        h2_v4_participant: bool,
    ) -> Result<
        (
            Self,
            NetworkHandle,
            mpsc::Receiver<NetworkEvent>,
            mpsc::Receiver<NetworkEvent>,
        ),
        NetworkError,
    > {
        let (command_tx, command_rx) = mpsc::channel(8192);
        let (priority_tx, priority_rx) = mpsc::channel(2048);
        let (consensus_event_tx, consensus_event_rx) = mpsc::channel(2048);
        let (event_tx, event_rx) = mpsc::channel(8192);

        // TX gossip is disabled by default (TX Forward to Leader replaces it).
        // Set N42_ENABLE_TX_GOSSIP=1 to re-enable legacy GossipSub tx flooding.
        let tx_gossip_disabled = std::env::var("N42_ENABLE_TX_GOSSIP").is_err();
        if tx_gossip_disabled {
            tracing::info!(
                "TX gossip disabled (default): using TX Forward to Leader. Set N42_ENABLE_TX_GOSSIP=1 to re-enable."
            );
        }
        let topics = [
            consensus_topic(),
            block_announce_topic(),
            verification_receipts_topic(),
            mempool_topic(),
            blob_sidecar_topic(),
        ];
        for (i, topic) in topics.iter().enumerate() {
            // Skip mempool topic (index 3) when tx gossip is disabled
            if tx_gossip_disabled && i == 3 {
                continue;
            }
            swarm
                .behaviour_mut()
                .gossipsub
                .subscribe(topic)
                .map_err(|e| NetworkError::Subscribe(e.to_string()))?;
        }
        if let Some(topic) = gov5_h2_observer_topic.as_ref() {
            swarm
                .behaviour_mut()
                .gossipsub
                .subscribe(topic)
                .map_err(|e| NetworkError::Subscribe(e.to_string()))?;
            tracing::info!(topic = %topic.hash(), "subscribed to legacy gov5 H2 observer topic");
        }
        if let Some(topic) = gov5_block_observer_topic.as_ref() {
            swarm
                .behaviour_mut()
                .gossipsub
                .subscribe(topic)
                .map_err(|e| NetworkError::Subscribe(e.to_string()))?;
            tracing::info!(topic = %topic.hash(), "subscribed to gov5 block observer topic");
        }
        let h2_v4_observer_topic = h2_v4_identity.map(|_| h2_v4_topic());
        let gov5_status = h2_v4_identity.map(|identity| Gov5Status {
            genesis_hash: identity.genesis_hash,
            current_height: 0,
        });
        if let Some(topic) = h2_v4_observer_topic.as_ref() {
            swarm
                .behaviour_mut()
                .gossipsub
                .subscribe(topic)
                .map_err(|e| NetworkError::Subscribe(e.to_string()))?;
            tracing::info!(topic = %topic.hash(), "subscribed to H2-v4 observer topic");
        }

        let [
            consensus,
            block_announce,
            verification,
            mempool,
            blob_sidecar,
        ] = topics;
        let consensus_topic_hash = consensus.hash();
        let block_announce_topic_hash = block_announce.hash();
        let verification_receipts_topic_hash = verification.hash();
        let mempool_topic_hash = mempool.hash();
        let blob_sidecar_topic_hash = blob_sidecar.hash();
        let gov5_h2_topic_hash = gov5_h2_observer_topic.map(|topic| topic.hash());
        let gov5_block_topic_hash = gov5_block_observer_topic.map(|topic| topic.hash());
        let h2_v4_topic_hash = h2_v4_observer_topic.map(|topic| topic.hash());

        let validator_peer_map = Arc::new(RwLock::new(HashMap::new()));
        let handle = NetworkHandle {
            command_tx,
            priority_tx,
            validator_peer_map: validator_peer_map.clone(),
        };

        let service = Self {
            swarm,
            command_rx,
            priority_rx,
            consensus_event_tx,
            event_tx,
            pending_reliable_events: VecDeque::new(),
            pending_data_events: VecDeque::new(),
            consensus_topic_hash,
            gov5_h2_topic_hash,
            gov5_block_topic_hash,
            h2_v4_topic_hash,
            h2_v4_identity,
            h2_v4_participant,
            gov5_status,
            pending_gov5_status_peers: HashSet::new(),
            gov5_chain_authenticated_peers: HashSet::new(),
            gov5_canonical_blocks: None,
            gov5_range_quotas: HashMap::new(),
            pending_gov5_ranges: HashMap::new(),
            block_announce_topic_hash,
            mempool_topic_hash,
            blob_sidecar_topic_hash,
            verification_receipts_topic_hash,
            pending_sync_channels: HashMap::new(),
            pending_block_direct_requests: HashMap::new(),
            outbound_block_direct_transfers: HashMap::new(),
            inbound_block_direct_transfers: HashMap::new(),
            queued_block_direct_by_peer: HashMap::new(),
            block_direct_digest_cache: BlockDirectDigestCache::default(),
            pending_gov5_block_requests: HashMap::new(),
            pending_gov5_block_hashes: HashSet::new(),
            recent_gov5_block_requests: HashMap::new(),
            recent_gov5_block_fulfilled: HashMap::new(),
            gov5_block_by_hash_peers: HashSet::new(),
            state_sync_peers: HashSet::new(),
            block_direct_peers: HashSet::new(),
            tuned_quic_udp_ports: HashSet::new(),
            gov5_served_blocks: HashMap::new(),
            gov5_served_block_order: VecDeque::new(),
            sync_request_windows: HashMap::new(),
            next_sync_id: 0,
            expected_validator_peer_ids,
            validator_peer_map,
            peer_validator_map: HashMap::new(),
            authenticated_validator_peer_map: HashMap::new(),
            authenticated_peer_validator_map: HashMap::new(),
            reconnection: ReconnectionManager::new(),
            tx_gossip_disabled,
            allow_deterministic_peer_ids,
            recent_block_announcements: RecentBlockAnnouncementDedup::default(),
            my_validator_index: None,
            validator_count: 0,
        };

        Ok((service, handle, consensus_event_rx, event_rx))
    }

    /// Installs the persistent canonical-chain source used to answer Gov5
    /// `bodies_by_range` requests. Interop services advertise the protocol but
    /// reject requests until this source is present.
    pub fn set_gov5_canonical_block_reader(&mut self, reader: Gov5CanonicalBlockReader) {
        self.gov5_canonical_blocks = Some(reader);
    }

    fn current_gov5_status(&self) -> Option<Gov5Status> {
        let mut status = self.gov5_status?;
        if let Some(reader) = self.gov5_canonical_blocks.as_ref() {
            match reader.best_block_number() {
                Ok(height) => status.current_height = height,
                Err(error) => {
                    tracing::warn!(
                        target: "n42::interop::range",
                        %error,
                        "failed to read canonical head for Gov5 status; refusing stale status"
                    );
                    return None;
                }
            }
        }
        Some(status)
    }

    pub fn listen_on(&mut self, addr: Multiaddr) -> Result<(), NetworkError> {
        self.swarm
            .listen_on(addr)
            .map(|_| ())
            .map_err(|e| NetworkError::Listen(e.to_string()))
    }

    pub fn dial(&mut self, addr: Multiaddr) -> Result<(), NetworkError> {
        self.swarm
            .dial(addr)
            .map_err(|e| NetworkError::Dial(e.to_string()))
    }

    /// Runs the event loop. Should be spawned as a background task.
    pub async fn run(mut self) {
        tracing::info!("network service started");

        let mut reconnect_interval = interval(Duration::from_secs(5));
        reconnect_interval.tick().await;

        let mut dht_refresh_interval = interval(Duration::from_secs(300));
        dht_refresh_interval.tick().await;

        if let Some(kad) = self.swarm.behaviour_mut().kademlia.as_mut()
            && let Err(e) = kad.bootstrap()
        {
            tracing::debug!(error = ?e, "kademlia bootstrap skipped (no known peers yet)");
        }

        loop {
            // Gov5 gives an inbound peer ten seconds to initiate Status. Flush
            // this immediately after ConnectionEstablished, ahead of catch-up
            // queues that can remain continuously non-empty.
            if let Some(status) = self.current_gov5_status() {
                for peer_id in std::mem::take(&mut self.pending_gov5_status_peers) {
                    if self.swarm.is_connected(&peer_id) {
                        let request_id = self
                            .swarm
                            .behaviour_mut()
                            .gov5_status
                            .send_request(&peer_id, status);
                        tracing::info!(%peer_id, %request_id, "queued gov5 Status handshake");
                    }
                }
            }

            // A full consumer channel must not suspend the only task polling
            // the swarm. Retain the front event and retry on the next tick.
            while let Some(event) = self.pending_reliable_events.pop_front() {
                match self.consensus_event_tx.try_send(event) {
                    Ok(()) => {}
                    Err(mpsc::error::TrySendError::Full(event)) => {
                        self.pending_reliable_events.push_front(event);
                        break;
                    }
                    Err(mpsc::error::TrySendError::Closed(_)) => {
                        metrics::counter!("n42_network_event_drops_total").increment(1);
                        tracing::warn!(
                            "consensus event channel closed while draining reliable backlog"
                        );
                        self.pending_reliable_events.clear();
                        break;
                    }
                }
            }

            while let Some(event) = self.pending_data_events.pop_front() {
                match self.event_tx.try_send(event) {
                    Ok(()) => {}
                    Err(mpsc::error::TrySendError::Full(event)) => {
                        self.pending_data_events.push_front(event);
                        break;
                    }
                    Err(mpsc::error::TrySendError::Closed(_)) => {
                        metrics::counter!("n42_network_event_drops_total").increment(1);
                        tracing::warn!("data event channel closed while draining reliable backlog");
                        self.pending_data_events.clear();
                        break;
                    }
                }
            }

            // Preserve a short priority burst, then force one swarm poll when
            // it is ready so command intake cannot starve connection progress.
            for _ in 0..MAX_PRIORITY_COMMANDS_PER_TICK {
                let Ok(cmd) = self.priority_rx.try_recv() else {
                    break;
                };
                self.handle_command(cmd);
            }

            tokio::select! {
                // Swarm first after the bounded command burst. If it is not
                // ready, priority commands still win over the normal lane.
                biased;

                event = self.swarm.select_next_some() => {
                    self.handle_swarm_event(event);
                }
                cmd = async {
                    if self.priority_rx.is_closed() && self.priority_rx.is_empty() {
                        std::future::pending::<Option<NetworkCommand>>().await
                    } else {
                        self.priority_rx.recv().await
                    }
                } => {
                    match cmd {
                        Some(command) => self.handle_command(command),
                        None => {
                            tracing::debug!("priority command channel closed");
                        }
                    }
                }
                cmd = self.command_rx.recv() => {
                    match cmd {
                        Some(command) => self.handle_command(command),
                        None => {
                            tracing::info!("command channel closed, shutting down");
                            break;
                        }
                    }
                }
                _ = reconnect_interval.tick() => {
                    let to_reconnect = self.reconnection.peers_to_reconnect();
                    for (peer_id, addr) in to_reconnect {
                        tracing::debug!(%peer_id, %addr, "attempting reconnection");
                        metrics::counter!("n42_reconnection_attempts").increment(1);
                        if let Err(e) = self.swarm.dial(addr.clone()) {
                            tracing::debug!(%peer_id, %addr, error = %e, "reconnect dial failed");
                            self.reconnection.on_dial_failure(&peer_id);
                        }
                    }
                }
                _ = dht_refresh_interval.tick() => {
                    if let Some(kad) = self.swarm.behaviour_mut().kademlia.as_mut() {
                        kad.get_closest_peers(PeerId::random());
                        tracing::debug!("kademlia DHT refresh");
                    }
                }
            }
        }
    }

    fn handle_swarm_event(&mut self, event: SwarmEvent<N42BehaviourEvent>) {
        match event {
            SwarmEvent::Behaviour(N42BehaviourEvent::Gossipsub(gossipsub::Event::Message {
                propagation_source,
                message,
                message_id: _,
            })) => {
                self.handle_gossipsub_message(propagation_source, message);
            }
            SwarmEvent::Behaviour(N42BehaviourEvent::Gossipsub(gossipsub::Event::Subscribed {
                peer_id,
                topic,
            })) => {
                tracing::debug!(%peer_id, %topic, "peer subscribed to topic");
            }
            SwarmEvent::Behaviour(N42BehaviourEvent::StateSync(event)) => {
                self.handle_state_sync_event(event);
            }
            SwarmEvent::Behaviour(N42BehaviourEvent::ConsensusDirect(event)) => {
                self.handle_consensus_direct_event(event);
            }
            SwarmEvent::Behaviour(N42BehaviourEvent::BlockDirect(event)) => {
                self.handle_block_direct_event(event);
            }
            SwarmEvent::Behaviour(N42BehaviourEvent::Gov5BlockPush(event)) => {
                self.handle_gov5_block_push_event(event);
            }
            SwarmEvent::Behaviour(N42BehaviourEvent::Gov5BlockByHash(event)) => {
                self.handle_gov5_block_by_hash_event(event);
            }
            SwarmEvent::Behaviour(N42BehaviourEvent::Gov5BodiesByRange(event)) => {
                self.handle_gov5_bodies_by_range_event(event);
            }
            SwarmEvent::Behaviour(N42BehaviourEvent::Gov5Status(event)) => {
                self.handle_gov5_status_event(event);
            }
            SwarmEvent::Behaviour(N42BehaviourEvent::Gov5HotstuffDirect(event)) => {
                self.handle_gov5_hotstuff_direct_event(event);
            }
            SwarmEvent::Behaviour(N42BehaviourEvent::TxForward(event)) => {
                self.handle_tx_forward_event(event);
            }
            SwarmEvent::Behaviour(N42BehaviourEvent::Identify(
                libp2p::identify::Event::Received { peer_id, info, .. },
            )) => {
                self.handle_identify_event(peer_id, info);
            }
            SwarmEvent::Behaviour(N42BehaviourEvent::Kademlia(event)) => {
                self.handle_kademlia_event(event);
            }
            SwarmEvent::Behaviour(N42BehaviourEvent::ConnectionLimits(event)) => match event {},
            SwarmEvent::Behaviour(N42BehaviourEvent::Mdns(event)) => {
                self.handle_mdns_event(event);
            }
            SwarmEvent::ConnectionEstablished { peer_id, .. } => {
                tracing::info!(%peer_id, "peer connected");
                metrics::gauge!("n42_active_peer_connections").increment(1.0);
                self.reconnection.on_connected(&peer_id);
                if let Some(validator_index) = self.route_expected_validator_peer(peer_id) {
                    tracing::info!(
                        %peer_id,
                        validator_index,
                        "routed connected peer using expected validator binding"
                    );
                }
                if self.gov5_status.is_some() {
                    self.pending_gov5_status_peers.insert(peer_id);
                }
                self.emit_event(NetworkEvent::PeerConnected(peer_id));
            }
            SwarmEvent::ConnectionClosed { peer_id, .. } => {
                tracing::info!(%peer_id, "peer disconnected");
                metrics::gauge!("n42_active_peer_connections").decrement(1.0);
                self.reconnection.on_disconnected(&peer_id);
                self.pending_gov5_status_peers.remove(&peer_id);
                self.gov5_block_by_hash_peers.remove(&peer_id);
                self.gov5_chain_authenticated_peers.remove(&peer_id);
                self.gov5_range_quotas.remove(&peer_id);
                self.pending_gov5_ranges
                    .retain(|_, pending_peer| *pending_peer != peer_id);
                self.state_sync_peers.remove(&peer_id);
                self.block_direct_peers.remove(&peer_id);
                self.outbound_block_direct_transfers.remove(&peer_id);
                self.inbound_block_direct_transfers
                    .retain(|(peer, _), _| *peer != peer_id);
                self.queued_block_direct_by_peer.remove(&peer_id);
                let queued_total = self
                    .queued_block_direct_by_peer
                    .values()
                    .map(VecDeque::len)
                    .sum::<usize>();
                metrics::gauge!("n42_block_direct_queued").set(queued_total as f64);
                self.sync_request_windows.remove(&peer_id);
                self.clear_validator_mapping_for_peer(&peer_id);
                self.clear_authenticated_validator_peer(&peer_id);
                self.emit_event(NetworkEvent::PeerDisconnected(peer_id));
            }
            SwarmEvent::OutgoingConnectionError {
                peer_id: Some(peer_id),
                ..
            } => {
                tracing::debug!(%peer_id, "outgoing connection error");
                self.reconnection.on_dial_failure(&peer_id);
            }
            SwarmEvent::NewListenAddr { address, .. } => {
                let local_peer_id = *self.swarm.local_peer_id();
                tracing::info!(%local_peer_id, %address, "listening on address");
                self.tune_quic_listener_socket(&address);
            }
            _ => {}
        }
    }

    fn tune_quic_listener_socket(&mut self, address: &Multiaddr) {
        let Some(port) = quic_udp_port(address) else {
            return;
        };
        if self.tuned_quic_udp_ports.contains(&port) {
            return;
        }

        let requested_bytes = requested_quic_udp_socket_buffer_bytes();
        match tune_quic_udp_socket_buffers(port, requested_bytes) {
            Ok(Some(buffers)) => {
                self.tuned_quic_udp_ports.insert(port);
                metrics::gauge!("n42_quic_udp_receive_buffer_bytes")
                    .set(buffers.receive_bytes as f64);
                metrics::gauge!("n42_quic_udp_send_buffer_bytes").set(buffers.send_bytes as f64);
                if buffers.receive_bytes < requested_bytes || buffers.send_bytes < requested_bytes {
                    tracing::warn!(
                        port,
                        requested_bytes,
                        receive_bytes = buffers.receive_bytes,
                        send_bytes = buffers.send_bytes,
                        matched_sockets = buffers.matched_sockets,
                        "QUIC UDP socket buffer capped by host limits; raise net.core.rmem_max and net.core.wmem_max"
                    );
                } else {
                    tracing::info!(
                        port,
                        requested_bytes,
                        receive_bytes = buffers.receive_bytes,
                        send_bytes = buffers.send_bytes,
                        matched_sockets = buffers.matched_sockets,
                        "tuned QUIC UDP socket buffers"
                    );
                }
            }
            Ok(None) => {
                tracing::warn!(
                    port,
                    requested_bytes,
                    "QUIC listener socket not found while applying UDP buffer tuning"
                );
            }
            Err(error) => {
                tracing::warn!(
                    port,
                    requested_bytes,
                    %error,
                    "failed to tune QUIC UDP socket buffers"
                );
            }
        }
    }

    fn clear_validator_mapping_for_peer(&mut self, peer_id: &PeerId) {
        if let Some(idx) = self.peer_validator_map.remove(peer_id) {
            let mut map = self.validator_peer_map.write().unwrap_or_else(|e| {
                tracing::error!(
                    "validator_peer_map lock poisoned on disconnect cleanup: {}",
                    e
                );
                e.into_inner()
            });
            if map.get(&idx) == Some(peer_id) {
                map.remove(&idx);
            }
        }
    }

    fn clear_authenticated_validator_peer(&mut self, peer_id: &PeerId) {
        if let Some(idx) = self.authenticated_peer_validator_map.remove(peer_id) {
            tracing::info!(
                %peer_id,
                validator_index = idx,
                "removed authenticated validator mapping for disconnected peer"
            );
            if self.authenticated_validator_peer_map.get(&idx) == Some(peer_id) {
                self.authenticated_validator_peer_map.remove(&idx);
            }
            metrics::gauge!("n42_authenticated_validator_peers")
                .set(self.authenticated_peer_validator_map.len() as f64);
        }
    }

    /// Routes a live peer whose Noise-authenticated PeerId exactly matches the
    /// configured binding for a validator. This does not mark the peer as BLS
    /// authenticated; that stronger authorization remains gated on a verified
    /// single-validator consensus message.
    fn route_expected_validator_peer(&mut self, peer_id: PeerId) -> Option<u32> {
        let validator_index =
            validator_index_for_expected_peer(&self.expected_validator_peer_ids, peer_id)?;

        self.reconnection.register_peer(peer_id, Vec::new(), true);
        self.peer_validator_map
            .retain(|_, idx| *idx != validator_index);
        self.peer_validator_map.insert(peer_id, validator_index);
        let mut map = self.validator_peer_map.write().unwrap_or_else(|e| {
            tracing::error!(
                "validator_peer_map lock poisoned on expected peer route: {}",
                e
            );
            e.into_inner()
        });
        map.insert(validator_index, peer_id);
        Some(validator_index)
    }

    fn authenticate_validator_peer(&mut self, peer_id: PeerId, validator_index: u32) {
        // Consensus messages may arrive through GossipSub or Rotor relays, so
        // the transport source is not necessarily the signed message's author.
        // Never let a relay overwrite validator routing: promotion is valid only
        // when the source PeerId matches the configured/deterministic binding.
        match expected_peer_id_for_validator(
            &self.expected_validator_peer_ids,
            validator_index,
            self.allow_deterministic_peer_ids,
        ) {
            Ok(expected_peer_id) if expected_peer_id == peer_id => {}
            Ok(expected_peer_id) => {
                tracing::debug!(
                    %peer_id,
                    %expected_peer_id,
                    validator_index,
                    "ignoring relayed consensus signer for validator peer authentication"
                );
                return;
            }
            Err(error) => {
                tracing::warn!(
                    %peer_id,
                    validator_index,
                    %error,
                    "refusing validator authentication without a trusted peer binding"
                );
                return;
            }
        }

        if !self.swarm.is_connected(&peer_id) {
            tracing::debug!(
                %peer_id,
                validator_index,
                "skipping validator authentication for disconnected peer"
            );
            return;
        }

        // A successfully authenticated validator is safety-critical and must
        // keep the indefinite reconnect policy even if it was first discovered
        // through mDNS/Identify as an ordinary peer.
        self.reconnection.register_peer(peer_id, Vec::new(), true);

        let already_authenticated = self.authenticated_validator_peer_map.get(&validator_index)
            == Some(&peer_id)
            && self.authenticated_peer_validator_map.get(&peer_id) == Some(&validator_index);

        if let Some(previous_peer) = self
            .authenticated_validator_peer_map
            .insert(validator_index, peer_id)
            && previous_peer != peer_id
        {
            self.authenticated_peer_validator_map.remove(&previous_peer);
        }

        if let Some(previous_idx) = self
            .authenticated_peer_validator_map
            .insert(peer_id, validator_index)
            && previous_idx != validator_index
            && self.authenticated_validator_peer_map.get(&previous_idx) == Some(&peer_id)
        {
            self.authenticated_validator_peer_map.remove(&previous_idx);
        }

        self.peer_validator_map
            .retain(|_, idx| *idx != validator_index);
        self.peer_validator_map.insert(peer_id, validator_index);
        let mut map = self.validator_peer_map.write().unwrap_or_else(|e| {
            tracing::error!("validator_peer_map lock poisoned on auth write: {}", e);
            e.into_inner()
        });
        map.insert(validator_index, peer_id);

        metrics::gauge!("n42_authenticated_validator_peers")
            .set(self.authenticated_peer_validator_map.len() as f64);
        if already_authenticated {
            tracing::debug!(
                %peer_id,
                validator_index,
                "refreshed authenticated validator mapping"
            );
        } else {
            metrics::counter!("n42_validator_peer_auth_promotions_total").increment(1);
            tracing::info!(
                %peer_id,
                validator_index,
                "peer promoted to authenticated validator"
            );
        }
    }

    fn replace_expected_validator_peers(&mut self, peers: HashMap<u32, PeerId>) {
        self.expected_validator_peer_ids = peers;

        self.authenticated_validator_peer_map
            .retain(|idx, peer_id| self.expected_validator_peer_ids.get(idx) == Some(peer_id));
        self.authenticated_peer_validator_map
            .retain(|peer_id, idx| self.expected_validator_peer_ids.get(idx) == Some(peer_id));
        self.peer_validator_map
            .retain(|peer_id, idx| self.expected_validator_peer_ids.get(idx) == Some(peer_id));

        let mut map = self.validator_peer_map.write().unwrap_or_else(|e| {
            tracing::error!(
                "validator_peer_map lock poisoned on expected peer replacement: {}",
                e
            );
            e.into_inner()
        });
        map.retain(|idx, peer_id| self.expected_validator_peer_ids.get(idx) == Some(peer_id));
        drop(map);

        let connected_expected: Vec<_> = self
            .expected_validator_peer_ids
            .values()
            .copied()
            .filter(|peer_id| self.swarm.is_connected(peer_id))
            .collect();
        for peer_id in connected_expected {
            self.route_expected_validator_peer(peer_id);
        }

        let routed = self
            .validator_peer_map
            .read()
            .map(|map| map.len())
            .unwrap_or_default();

        tracing::info!(
            validator_count = self.expected_validator_peer_ids.len(),
            authenticated = self.authenticated_validator_peer_map.len(),
            routed,
            "replaced expected validator peer bindings"
        );
    }

    fn handle_identify_event(&mut self, peer_id: PeerId, info: libp2p::identify::Info) {
        let supports_gov5_block_fetch = info
            .protocols
            .iter()
            .any(|protocol| protocol.as_ref() == GOV5_BLOCK_BY_HASH_PROTOCOL);
        let supports_state_sync = info
            .protocols
            .iter()
            .any(|protocol| protocol.as_ref() == SYNC_PROTOCOL);
        let supports_block_direct = info
            .protocols
            .iter()
            .any(|protocol| protocol.as_ref() == BLOCK_DIRECT_PROTOCOL);
        let newly_ready_for_block_fetch =
            supports_gov5_block_fetch && self.gov5_block_by_hash_peers.insert(peer_id);
        let newly_ready_for_state_sync =
            supports_state_sync && self.state_sync_peers.insert(peer_id);
        let newly_ready_for_block_direct =
            supports_block_direct && self.block_direct_peers.insert(peer_id);
        if !supports_block_direct {
            self.block_direct_peers.remove(&peer_id);
        }
        if newly_ready_for_block_fetch || newly_ready_for_state_sync || newly_ready_for_block_direct
        {
            tracing::info!(
                %peer_id,
                protocol = ?info.protocol_version,
                supports_gov5_block_fetch,
                supports_state_sync,
                supports_block_direct,
                "identified peer capabilities"
            );
        } else {
            tracing::debug!(
                %peer_id,
                protocol = ?info.protocol_version,
                supports_gov5_block_fetch,
                supports_state_sync,
                supports_block_direct,
                "refreshed peer capabilities"
            );
        }

        if let Some(idx) = claimed_validator_index(&info.agent_version) {
            let expected_peer_id = expected_peer_id_for_validator(
                &self.expected_validator_peer_ids,
                idx,
                self.allow_deterministic_peer_ids,
            );

            match expected_peer_id {
                Ok(expected_peer_id) if expected_peer_id == peer_id => {
                    tracing::info!(
                        %peer_id,
                        validator_index = idx,
                        "mapped peer to validator from identify metadata"
                    );
                    self.reconnection
                        .register_peer(peer_id, info.listen_addrs.clone(), true);
                    // Update reverse map: remove any old peer that claimed this index
                    self.peer_validator_map.retain(|_, v| *v != idx);
                    self.peer_validator_map.insert(peer_id, idx);
                    let mut map = self.validator_peer_map.write().unwrap_or_else(|e| {
                        tracing::error!("validator_peer_map lock poisoned on write: {}", e);
                        e.into_inner()
                    });
                    map.insert(idx, peer_id);
                }
                Ok(expected_peer_id) => {
                    tracing::warn!(
                        %peer_id,
                        %expected_peer_id,
                        validator_index = idx,
                        "ignoring validator identify mapping with unexpected peer id"
                    );
                    self.clear_validator_mapping_for_peer(&peer_id);
                }
                Err(error) => {
                    tracing::warn!(
                        %peer_id,
                        validator_index = idx,
                        error = %error,
                        "failed to derive expected validator peer id"
                    );
                }
            }
        }

        if let Some(kad) = self.swarm.behaviour_mut().kademlia.as_mut() {
            for addr in &info.listen_addrs {
                kad.add_address(&peer_id, addr.clone());
            }
        }

        // ConnectionEstablished precedes Identify. Re-emitting this idempotent
        // event makes startup recovery retry persisted certificate anchors as
        // soon as a native block source is actually usable.
        if newly_ready_for_block_fetch {
            self.emit_event(NetworkEvent::PeerConnected(peer_id));
        }
    }

    fn retain_gov5_served_block(
        &mut self,
        rlp: &[u8],
        expected_hash: Option<B256>,
    ) -> Result<B256, Gov5BlockError> {
        cache_gov5_served_block(
            &mut self.gov5_served_blocks,
            &mut self.gov5_served_block_order,
            rlp,
            expected_hash,
        )
    }

    fn handle_gossipsub_message(&mut self, source: PeerId, message: gossipsub::Message) {
        metrics::counter!("n42_gossipsub_messages_received").increment(1);
        tracing::info!(target: "n42::net", %source, topic = %message.topic, bytes = message.data.len(), "gossipsub message received");

        let acceptance = validate_message(
            &message.topic,
            &message.data,
            &self.consensus_topic_hash,
            &self.block_announce_topic_hash,
            &self.mempool_topic_hash,
            &self.blob_sidecar_topic_hash,
            self.gov5_block_topic_hash.as_ref(),
        );

        if !matches!(acceptance, gossipsub::MessageAcceptance::Accept) {
            tracing::warn!(%source, "rejected invalid gossipsub message");
            return;
        }

        let topic = &message.topic;
        let event = match () {
            _ if self
                .gov5_block_topic_hash
                .as_ref()
                .is_some_and(|hash| topic == hash) =>
            {
                const MAX_GOV5_BLOCK_BYTES: usize = 1 << 20;
                let decoded_len = match snap::raw::decompress_len(&message.data) {
                    Ok(len) if len <= MAX_GOV5_BLOCK_BYTES => len,
                    Ok(len) => {
                        metrics::counter!("n42_gov5_blocks_rejected_total", "reason" => "oversized")
                            .increment(1);
                        tracing::warn!(target: "n42::interop::block", %source, decoded_len = len, "rejected oversized gov5 block gossip");
                        return;
                    }
                    Err(error) => {
                        metrics::counter!("n42_gov5_blocks_rejected_total", "reason" => "snappy")
                            .increment(1);
                        tracing::warn!(target: "n42::interop::block", %source, %error, "rejected invalid gov5 block snappy frame");
                        return;
                    }
                };
                match crate::snappy_pool::raw_decompress(&message.data) {
                    Ok(rlp) if rlp.len() == decoded_len => {
                        metrics::counter!("n42_gov5_blocks_observed_total").increment(1);
                        if let Err(error) = self.retain_gov5_served_block(&rlp, None) {
                            tracing::warn!(
                                target: "n42::interop::block",
                                %source,
                                %error,
                                "refusing to retain malformed gov5 block gossip"
                            );
                        }
                        NetworkEvent::Gov5Block { source, rlp }
                    }
                    Ok(_) => {
                        metrics::counter!("n42_gov5_blocks_rejected_total", "reason" => "length")
                            .increment(1);
                        tracing::warn!(target: "n42::interop::block", %source, "rejected inconsistent gov5 block snappy frame");
                        return;
                    }
                    Err(error) => {
                        metrics::counter!("n42_gov5_blocks_rejected_total", "reason" => "snappy")
                            .increment(1);
                        tracing::warn!(target: "n42::interop::block", %source, %error, "rejected invalid gov5 block snappy frame");
                        return;
                    }
                }
            }
            _ if self
                .h2_v4_topic_hash
                .as_ref()
                .is_some_and(|hash| topic == hash) =>
            {
                let Some(identity) = self.h2_v4_identity else {
                    return;
                };
                match decode_h2_v4_gossip(&message.data, identity) {
                    Ok(envelope) => {
                        let kind = envelope.message.kind().as_str();
                        metrics::counter!("n42_h2_v4_messages_observed_total", "kind" => kind)
                            .increment(1);
                        NetworkEvent::H2V4Message {
                            source,
                            envelope: Box::new(envelope),
                        }
                    }
                    Err(error) => {
                        metrics::counter!("n42_h2_v4_messages_rejected_total").increment(1);
                        tracing::warn!(target: "n42::interop::h2v4", %source, %error, "rejected invalid H2-v4 message");
                        return;
                    }
                }
            }
            _ if self
                .gov5_h2_topic_hash
                .as_ref()
                .is_some_and(|hash| topic == hash) =>
            {
                match decode_gov5_gossip_message(&message.data) {
                    Ok(msg) => {
                        let kind = msg.kind().as_str();
                        metrics::counter!("n42_gov5_h2_messages_observed_total", "kind" => kind)
                            .increment(1);
                        tracing::debug!(target: "n42::interop::h2", %source, kind, "observed gov5 H2 message");
                        NetworkEvent::Gov5H2Message {
                            source,
                            message: Box::new(msg),
                        }
                    }
                    Err(error) => {
                        metrics::counter!("n42_gov5_h2_messages_rejected_total").increment(1);
                        tracing::warn!(target: "n42::interop::h2", %source, %error, "rejected invalid gov5 H2 message");
                        return;
                    }
                }
            }
            _ if *topic == self.consensus_topic_hash => {
                match decode_consensus_message(&message.data) {
                    Ok(msg) => {
                        tracing::trace!(%source, "received consensus message");
                        NetworkEvent::ConsensusMessage {
                            source,
                            message: Box::new(msg),
                        }
                    }
                    Err(e) => {
                        tracing::warn!(%source, error = %e, "failed to decode consensus message");
                        return;
                    }
                }
            }
            _ if *topic == self.block_announce_topic_hash => {
                if self.observe_block_announcement(&message.data, "gossipsub") {
                    tracing::info!(
                        %source,
                        dedup_source = "gossipsub",
                        bytes = message.data.len(),
                        "N42_DUP_BLOCK_ANNOUNCEMENT_RAW: dropped duplicate block announcement"
                    );
                    return;
                }
                NetworkEvent::BlockAnnouncement {
                    source,
                    data: message.data,
                }
            }
            _ if *topic == self.mempool_topic_hash => NetworkEvent::TransactionReceived {
                source,
                data: message.data,
            },
            _ if *topic == self.blob_sidecar_topic_hash => NetworkEvent::BlobSidecarReceived {
                source,
                data: message.data,
            },
            _ if *topic == self.verification_receipts_topic_hash => {
                NetworkEvent::VerificationReceipt {
                    source,
                    data: message.data,
                }
            }
            _ => {
                tracing::warn!(%source, %topic, "received message on unknown topic");
                return;
            }
        };

        self.emit_event(event);
    }

    fn handle_state_sync_event(
        &mut self,
        event: libp2p::request_response::Event<BlockSyncRequest, BlockSyncResponse>,
    ) {
        match event {
            libp2p::request_response::Event::Message { peer, message, .. } => match message {
                libp2p::request_response::Message::Request {
                    request, channel, ..
                } => {
                    if !self.allow_inbound_sync_request(peer) {
                        let validator = self.reconnection.is_trusted(&peer)
                            || self.authenticated_peer_validator_map.contains_key(&peer);
                        metrics::counter!(
                            "n42_state_sync_requests_throttled_total",
                            "peer_class" => if validator { "validator" } else { "untrusted" }
                        )
                        .increment(1);
                        tracing::warn!(
                            %peer,
                            validator,
                            "dropping rate-limited inbound state-sync request"
                        );
                        drop(channel);
                        return;
                    }
                    metrics::counter!("n42_state_sync_requests").increment(1);
                    let id = self.next_sync_id;
                    self.next_sync_id = self.next_sync_id.wrapping_add(1);

                    // Evict oldest stale channels to bound memory growth.
                    const MAX_PENDING: usize = 64;
                    if self.pending_sync_channels.len() >= MAX_PENDING {
                        let stale_count = self.pending_sync_channels.len() - MAX_PENDING + 1;
                        let mut ids: Vec<u64> =
                            self.pending_sync_channels.keys().copied().collect();
                        ids.sort_unstable();
                        for stale_id in ids.into_iter().take(stale_count) {
                            tracing::warn!(request_id = stale_id, "evicting stale sync channel");
                            self.pending_sync_channels.remove(&stale_id);
                        }
                    }

                    self.pending_sync_channels.insert(id, channel);
                    tracing::debug!(%peer, request_id = id, "received sync request");
                    self.emit_event(NetworkEvent::SyncRequest {
                        peer,
                        request_id: id,
                        request,
                    });
                }
                libp2p::request_response::Message::Response { response, .. } => {
                    tracing::debug!(%peer, blocks = response.blocks.len(), "received sync response");
                    self.emit_event(NetworkEvent::SyncResponse { peer, response });
                }
            },
            libp2p::request_response::Event::OutboundFailure { peer, error, .. } => {
                tracing::warn!(%peer, %error, "sync request failed");
                self.emit_event(NetworkEvent::SyncRequestFailed {
                    peer,
                    error: error.to_string(),
                    // A transport failure says nothing about the peer's
                    // protocol set.
                    unsupported_protocol: false,
                });
            }
            libp2p::request_response::Event::InboundFailure { peer, error, .. } => {
                tracing::debug!(%peer, %error, "sync inbound failure");
            }
            libp2p::request_response::Event::ResponseSent { peer, .. } => {
                tracing::debug!(%peer, "sync response sent");
            }
        }
    }

    fn allow_inbound_sync_request(&mut self, peer: PeerId) -> bool {
        let validator = self.reconnection.is_trusted(&peer)
            || self.authenticated_peer_validator_map.contains_key(&peer);
        let limit = if validator {
            MAX_SYNC_REQUESTS_VALIDATOR
        } else {
            MAX_SYNC_REQUESTS_UNTRUSTED
        };
        self.sync_request_windows
            .entry(peer)
            .or_insert_with(|| SyncRequestWindow::new(Instant::now()))
            .allow(Instant::now(), limit)
    }

    fn handle_consensus_direct_event(
        &mut self,
        event: libp2p::request_response::Event<ConsensusDirectRequest, ConsensusDirectResponse>,
    ) {
        match event {
            libp2p::request_response::Event::Message { peer, message, .. } => match message {
                libp2p::request_response::Message::Request {
                    request, channel, ..
                } => {
                    metrics::counter!("n42_direct_messages_received").increment(1);
                    match decode_consensus_message(&request.message_bytes) {
                        Ok(msg) => {
                            // Check if we should relay this proposal to our assigned targets
                            if let n42_primitives::consensus::ConsensusMessage::Proposal(
                                ref proposal,
                            ) = msg
                            {
                                self.maybe_relay_proposal(proposal, &request.message_bytes, peer);
                            }
                            self.emit_event(NetworkEvent::ConsensusMessage {
                                source: peer,
                                message: Box::new(msg),
                            });
                            if self
                                .swarm
                                .behaviour_mut()
                                .consensus_direct
                                .send_response(channel, ConsensusDirectResponse { accepted: true })
                                .is_err()
                            {
                                tracing::warn!(%peer, "failed to send consensus direct ACK");
                            }
                        }
                        Err(e) => {
                            tracing::warn!(%peer, error = %e, "invalid consensus direct message");
                            if self
                                .swarm
                                .behaviour_mut()
                                .consensus_direct
                                .send_response(channel, ConsensusDirectResponse { accepted: false })
                                .is_err()
                            {
                                tracing::warn!(%peer, "failed to send consensus direct rejection");
                            }
                        }
                    }
                }
                libp2p::request_response::Message::Response { .. } => {
                    // ACK received — fire-and-forget semantics, no action needed.
                }
            },
            libp2p::request_response::Event::OutboundFailure { peer, error, .. } => {
                tracing::debug!(%peer, ?error, "consensus direct send failed");
                metrics::counter!("n42_direct_send_failures").increment(1);
            }
            libp2p::request_response::Event::InboundFailure { .. } => {}
            libp2p::request_response::Event::ResponseSent { .. } => {}
        }
    }

    /// If this node is a Rotor relay for the current view, forward the raw
    /// proposal bytes to its assigned target validators via consensus_direct.
    fn maybe_relay_proposal(
        &mut self,
        proposal: &n42_primitives::consensus::Proposal,
        raw_bytes: &[u8],
        source: libp2p::PeerId,
    ) {
        let Some(my_index) = self.my_validator_index else {
            return;
        };
        if self.validator_count < 2 {
            return;
        }

        // Only relay messages that came directly from the leader
        let leader_peer = {
            let map = self.validator_peer_map.read().unwrap_or_else(|e| {
                tracing::warn!("validator_peer_map poisoned, recovering");
                e.into_inner()
            });
            map.get(&proposal.proposer).copied()
        };
        if leader_peer != Some(source) {
            return; // Not from leader — don't relay (prevents forwarding loops)
        }

        use n42_consensus::rotor::cached_relay_assignment;
        let assignment = cached_relay_assignment(
            proposal.view,
            self.validator_count,
            proposal.proposer,
            3, // DEFAULT_RELAY_COUNT
        );

        // Find my targets if I'm a relay for this view
        let my_targets = assignment
            .relays
            .iter()
            .find(|(relay, _)| *relay == my_index)
            .map(|(_, targets)| targets.clone());

        let Some(targets) = my_targets else { return };

        // Collect target peer IDs while holding the lock, then release before sending.
        let target_peers: Vec<libp2p::PeerId> = {
            let map = self.validator_peer_map.read().unwrap_or_else(|e| {
                tracing::warn!("validator_peer_map poisoned, recovering");
                e.into_inner()
            });
            targets
                .iter()
                .filter(|&&idx| idx != my_index)
                .filter_map(|idx| map.get(idx).copied())
                .collect()
        };

        let mut forwarded = 0u32;
        for peer_id in &target_peers {
            let req = crate::consensus_direct::ConsensusDirectRequest {
                message_bytes: raw_bytes.to_vec(),
            };
            self.swarm
                .behaviour_mut()
                .consensus_direct
                .send_request(peer_id, req);
            forwarded += 1;
        }
        if forwarded > 0 {
            metrics::counter!("n42_rotor_relayed_msgs").increment(forwarded as u64);
            tracing::debug!(
                target: "n42::network::rotor",
                view = proposal.view,
                my_index,
                targets = targets.len(),
                forwarded,
                "relayed proposal to targets"
            );
        }
    }

    fn dispatch_block_direct_frame(
        &mut self,
        peer: PeerId,
        frame: BlockDirectFrame,
        pending_frame: PendingBlockDirectFrame,
        queued: QueuedBlockDirect,
    ) {
        let bytes = frame.payload_len();
        let request_id = self
            .swarm
            .behaviour_mut()
            .block_direct
            .send_request(&peer, BlockDirectRequest { frame });
        self.pending_block_direct_requests.insert(
            request_id,
            PendingBlockDirectRequest {
                peer,
                bytes,
                started_at: Instant::now(),
                frame: pending_frame,
                data: queued.data,
                attempt: queued.attempt,
            },
        );
        metrics::counter!("n42_block_direct_frames_sent_total").increment(1);
        metrics::gauge!("n42_block_direct_pending")
            .set(self.pending_block_direct_requests.len() as f64);
    }

    fn dispatch_block_direct_request(&mut self, peer: PeerId, queued: QueuedBlockDirect) {
        metrics::counter!("n42_block_direct_sent").increment(1);
        let data = Arc::clone(&queued.data);
        let bytes = data.len();
        if bytes > MAX_BLOCK_DIRECT_SIZE {
            tracing::error!(%peer, bytes, max = MAX_BLOCK_DIRECT_SIZE, "block direct envelope exceeds reconstructed transfer limit");
            metrics::counter!("n42_block_direct_oversized_total").increment(1);
            return;
        }
        let chunk_size = block_direct_chunk_size();
        if bytes <= chunk_size {
            self.dispatch_block_direct_frame(
                peer,
                BlockDirectFrame::Complete { data },
                PendingBlockDirectFrame::Complete,
                queued,
            );
            return;
        }

        let transfer_id = queued
            .transfer_id
            .expect("large direct block digest is prepared before queueing");
        let chunk_count = bytes.div_ceil(chunk_size) as u32;
        let manifest = BlockDirectManifest {
            transfer_id,
            total_len: bytes as u64,
            chunk_size: chunk_size as u32,
            chunk_count,
        };
        self.outbound_block_direct_transfers.insert(
            peer,
            OutboundBlockDirectTransfer {
                manifest,
                data: Arc::clone(&data),
                started_at: Instant::now(),
            },
        );
        metrics::counter!("n42_block_direct_chunked_transfers_total").increment(1);
        tracing::info!(
            %peer,
            bytes,
            chunk_size,
            chunk_count,
            transfer_id = %hex::encode(transfer_id),
            "N42_BLOCK_DIRECT_MANIFEST: starting one-substream chunk transfer"
        );
        self.dispatch_block_direct_frame(
            peer,
            BlockDirectFrame::Transfer { manifest, data },
            PendingBlockDirectFrame::Transfer { transfer_id },
            queued,
        );
    }

    fn enqueue_or_dispatch_block_direct(&mut self, peer: PeerId, data: Arc<Vec<u8>>) {
        let transfer_id = (data.len() > block_direct_chunk_size()
            && data.len() <= MAX_BLOCK_DIRECT_SIZE)
            .then(|| self.block_direct_digest_cache.transfer_id(&data));
        let in_flight = self
            .pending_block_direct_requests
            .values()
            .any(|request| request.peer == peer)
            || self.outbound_block_direct_transfers.contains_key(&peer);
        if !in_flight {
            self.dispatch_block_direct_request(
                peer,
                QueuedBlockDirect {
                    data,
                    transfer_id,
                    attempt: 0,
                },
            );
            return;
        }

        let bytes = data.len();
        let queue = self.queued_block_direct_by_peer.entry(peer).or_default();
        if queue.len() >= block_direct_queue_depth() {
            metrics::counter!("n42_block_direct_queue_overflow_total").increment(1);
            tracing::error!(
                %peer,
                bytes,
                queue_depth = queue.len(),
                max_queue_depth = block_direct_queue_depth(),
                "N42_BLOCK_DIRECT_QUEUE_OVERFLOW: refusing to lose an older committed block"
            );
            return;
        }
        queue.push_back(QueuedBlockDirect {
            data,
            transfer_id,
            attempt: 0,
        });
        let peer_queue_depth = queue.len();
        metrics::counter!("n42_block_direct_queued_total").increment(1);
        let queued_total = self
            .queued_block_direct_by_peer
            .values()
            .map(VecDeque::len)
            .sum::<usize>();
        metrics::gauge!("n42_block_direct_queued").set(queued_total as f64);
        if bytes >= 1024 * 1024 {
            tracing::info!(
                %peer,
                bytes,
                pending = self.pending_block_direct_requests.len(),
                peer_queue_depth,
                queued_total,
                "N42_BLOCK_DIRECT_QUEUE: retained ordered block behind in-flight request"
            );
        }
    }

    fn dispatch_queued_block_direct(&mut self, peer: PeerId) {
        if self
            .pending_block_direct_requests
            .values()
            .any(|request| request.peer == peer)
            || self.outbound_block_direct_transfers.contains_key(&peer)
        {
            return;
        }
        let Some(queued) = self
            .queued_block_direct_by_peer
            .get_mut(&peer)
            .and_then(VecDeque::pop_front)
        else {
            return;
        };
        if self
            .queued_block_direct_by_peer
            .get(&peer)
            .is_some_and(VecDeque::is_empty)
        {
            self.queued_block_direct_by_peer.remove(&peer);
        }
        metrics::counter!("n42_block_direct_queued_dispatch_total").increment(1);
        let queued_total = self
            .queued_block_direct_by_peer
            .values()
            .map(VecDeque::len)
            .sum::<usize>();
        metrics::gauge!("n42_block_direct_queued").set(queued_total as f64);
        self.dispatch_block_direct_request(peer, queued);
    }

    fn accept_inbound_block_direct_frame(
        &mut self,
        peer: PeerId,
        frame: BlockDirectFrame,
    ) -> (bool, Option<Vec<u8>>) {
        let now = Instant::now();
        self.inbound_block_direct_transfers.retain(|_, transfer| {
            now.saturating_duration_since(transfer.started_at) < BLOCK_DIRECT_TRANSFER_TIMEOUT
        });
        match frame {
            BlockDirectFrame::Complete { data } => {
                if data.len() > block_direct_chunk_size() {
                    return (false, None);
                }
                (
                    true,
                    Some(Arc::try_unwrap(data).unwrap_or_else(|shared| (*shared).clone())),
                )
            }
            // The codec has already bounded every allocation, verified every
            // chunk length and checked the digest over this immutable Arc.
            BlockDirectFrame::Transfer { manifest, data } => {
                let total_len = usize::try_from(manifest.total_len).unwrap_or(usize::MAX);
                let chunk_size = manifest.chunk_size as usize;
                let valid = total_len == data.len()
                    && total_len > chunk_size
                    && total_len <= MAX_BLOCK_DIRECT_SIZE
                    && (MIN_BLOCK_DIRECT_CHUNK_SIZE..=MAX_BLOCK_DIRECT_CHUNK_SIZE)
                        .contains(&chunk_size)
                    && manifest.chunk_count as usize == total_len.div_ceil(chunk_size);
                if !valid {
                    metrics::counter!("n42_block_direct_manifest_rejected_total").increment(1);
                    return (false, None);
                }
                metrics::counter!(
                    "n42_block_direct_digest_rehash_avoided_bytes_total",
                    "site" => "inbound_dispatch",
                )
                .increment(data.len() as u64);
                metrics::counter!("n42_block_direct_stream_transfers_received_total").increment(1);
                (
                    true,
                    Some(Arc::try_unwrap(data).unwrap_or_else(|shared| (*shared).clone())),
                )
            }
            BlockDirectFrame::Manifest(manifest) => {
                let Ok(total_len) = usize::try_from(manifest.total_len) else {
                    return (false, None);
                };
                let chunk_size = manifest.chunk_size as usize;
                let expected_count = total_len.div_ceil(chunk_size.max(1));
                if total_len <= chunk_size
                    || total_len > MAX_BLOCK_DIRECT_SIZE
                    || !(MIN_BLOCK_DIRECT_CHUNK_SIZE..=MAX_BLOCK_DIRECT_CHUNK_SIZE)
                        .contains(&chunk_size)
                    || manifest.chunk_count == 0
                    || manifest.chunk_count as usize != expected_count
                {
                    metrics::counter!("n42_block_direct_manifest_rejected_total").increment(1);
                    return (false, None);
                }
                if self.inbound_block_direct_transfers.len() >= MAX_INBOUND_BLOCK_DIRECT_TRANSFERS
                    && let Some(oldest) = self
                        .inbound_block_direct_transfers
                        .iter()
                        .min_by_key(|(_, transfer)| transfer.started_at)
                        .map(|(key, _)| *key)
                {
                    self.inbound_block_direct_transfers.remove(&oldest);
                    metrics::counter!("n42_block_direct_reassembly_evictions_total").increment(1);
                }
                // A peer has one ordered data channel. A fresh manifest retires
                // any abandoned transfer from that peer before reserving bytes.
                self.inbound_block_direct_transfers
                    .retain(|(source, _), _| *source != peer);
                let mut data = Vec::new();
                if data.try_reserve_exact(total_len).is_err() {
                    metrics::counter!("n42_block_direct_reassembly_alloc_failures_total")
                        .increment(1);
                    return (false, None);
                }
                self.inbound_block_direct_transfers.insert(
                    (peer, manifest.transfer_id),
                    InboundBlockDirectTransfer {
                        manifest,
                        next_chunk: 0,
                        data,
                        started_at: now,
                    },
                );
                metrics::gauge!("n42_block_direct_reassemblies")
                    .set(self.inbound_block_direct_transfers.len() as f64);
                (true, None)
            }
            BlockDirectFrame::Chunk {
                transfer_id,
                index,
                data,
                offset,
                len,
            } => {
                let key = (peer, transfer_id);
                let Some(transfer) = self.inbound_block_direct_transfers.get_mut(&key) else {
                    metrics::counter!("n42_block_direct_orphan_chunks_total").increment(1);
                    return (false, None);
                };
                let chunk_size = transfer.manifest.chunk_size as usize;
                let Some(chunk_offset) = (index as usize).checked_mul(chunk_size) else {
                    self.inbound_block_direct_transfers.remove(&key);
                    return (false, None);
                };
                let Some(remaining) =
                    (transfer.manifest.total_len as usize).checked_sub(chunk_offset)
                else {
                    self.inbound_block_direct_transfers.remove(&key);
                    return (false, None);
                };
                let expected_len = remaining.min(chunk_size);
                let valid_range = offset.checked_add(len).is_some_and(|end| end <= data.len());
                if index != transfer.next_chunk || len != expected_len || !valid_range {
                    metrics::counter!("n42_block_direct_out_of_order_chunks_total").increment(1);
                    self.inbound_block_direct_transfers.remove(&key);
                    return (false, None);
                }
                transfer.data.extend_from_slice(&data[offset..offset + len]);
                transfer.next_chunk += 1;
                metrics::counter!("n42_block_direct_chunk_bytes_received_total")
                    .increment(len as u64);
                if transfer.next_chunk < transfer.manifest.chunk_count {
                    return (true, None);
                }

                let transfer = self
                    .inbound_block_direct_transfers
                    .remove(&key)
                    .expect("reassembly exists until final chunk");
                metrics::gauge!("n42_block_direct_reassemblies")
                    .set(self.inbound_block_direct_transfers.len() as f64);
                if transfer.data.len() != transfer.manifest.total_len as usize
                    || blake3::hash(&transfer.data).as_bytes() != &transfer_id
                {
                    metrics::counter!("n42_block_direct_digest_mismatch_total").increment(1);
                    return (false, None);
                }
                metrics::histogram!("n42_block_direct_transfer_ms")
                    .record(transfer.started_at.elapsed().as_secs_f64() * 1_000.0);
                metrics::counter!("n42_block_direct_reassembled_total").increment(1);
                (true, Some(transfer.data))
            }
        }
    }

    fn handle_block_direct_event(
        &mut self,
        event: libp2p::request_response::Event<BlockDirectRequest, BlockDirectResponse>,
    ) {
        match event {
            libp2p::request_response::Event::Message { peer, message, .. } => match message {
                libp2p::request_response::Message::Request {
                    request, channel, ..
                } => {
                    metrics::counter!("n42_block_direct_received").increment(1);
                    let bytes = request.frame.payload_len();
                    // Accept direct push only from peers that have already proved
                    // control of a current validator key via a signed consensus message.
                    if let Some(&validator_idx) = self.authenticated_peer_validator_map.get(&peer) {
                        let (accepted, completed) =
                            self.accept_inbound_block_direct_frame(peer, request.frame);
                        if let Some(data) = completed {
                            let total_bytes = data.len();
                            metrics::counter!("n42_block_direct_bytes_received_total")
                                .increment(total_bytes as u64);
                            let is_duplicate =
                                self.observe_block_announcement(&data, "block_direct_v3");
                            if is_duplicate {
                                tracing::info!(
                                    %peer,
                                    validator_index = validator_idx,
                                    dedup_source = "block_direct_v3",
                                    bytes = total_bytes,
                                    "N42_DUP_BLOCK_ANNOUNCEMENT_RAW: dropped duplicate block announcement"
                                );
                            } else {
                                tracing::info!(
                                    %peer,
                                    validator_index = validator_idx,
                                    bytes = total_bytes,
                                    "N42_BLOCK_DIRECT_RECV: authenticated envelope complete"
                                );
                                self.emit_event(NetworkEvent::BlockAnnouncement {
                                    source: peer,
                                    data,
                                });
                            }
                        }
                        if self
                            .swarm
                            .behaviour_mut()
                            .block_direct
                            .send_response(channel, BlockDirectResponse { accepted })
                            .is_err()
                        {
                            tracing::warn!(%peer, "failed to send block direct ACK");
                        }
                    } else {
                        tracing::warn!(
                            %peer,
                            bytes,
                            "rejected block direct push from unauthenticated peer"
                        );
                        metrics::counter!("n42_block_direct_rejected_non_validator").increment(1);
                        metrics::counter!("n42_block_direct_rejected_non_validator_bytes_total")
                            .increment(bytes as u64);
                        metrics::histogram!("n42_block_direct_rejected_non_validator_bytes")
                            .record(bytes as f64);
                        if bytes > 1024 * 1024 {
                            metrics::counter!("n42_block_direct_rejected_non_validator_gt_1mb")
                                .increment(1);
                        }
                        if bytes > 3 * 1024 * 1024 {
                            metrics::counter!("n42_block_direct_rejected_non_validator_gt_3mb")
                                .increment(1);
                        }
                        if self
                            .swarm
                            .behaviour_mut()
                            .block_direct
                            .send_response(channel, BlockDirectResponse { accepted: false })
                            .is_err()
                        {
                            tracing::warn!(%peer, "failed to send block direct rejection");
                        }
                    }
                }
                libp2p::request_response::Message::Response {
                    request_id,
                    response,
                } => {
                    if let Some(pending) = self.pending_block_direct_requests.remove(&request_id) {
                        let completed_peer = pending.peer;
                        let elapsed_ms = pending.started_at.elapsed().as_millis() as u64;
                        metrics::histogram!("n42_block_direct_ack_latency_ms")
                            .record(elapsed_ms as f64);
                        metrics::gauge!("n42_block_direct_pending")
                            .set(self.pending_block_direct_requests.len() as f64);
                        if pending.bytes >= 1024 * 1024 {
                            tracing::debug!(
                                %peer,
                                expected_peer = %pending.peer,
                                ?request_id,
                                accepted = response.accepted,
                                bytes = pending.bytes,
                                elapsed_ms,
                                pending = self.pending_block_direct_requests.len(),
                                "N42_BLOCK_DIRECT_ACK: remote validator completed block push"
                            );
                        }
                        if !response.accepted {
                            self.outbound_block_direct_transfers.remove(&completed_peer);
                            metrics::counter!("n42_block_direct_remote_rejections_total")
                                .increment(1);
                            self.dispatch_queued_block_direct(completed_peer);
                            return;
                        }
                        metrics::counter!("n42_block_direct_bytes_sent_total")
                            .increment(pending.bytes as u64);
                        match pending.frame {
                            PendingBlockDirectFrame::Complete => {
                                self.dispatch_queued_block_direct(completed_peer);
                            }
                            PendingBlockDirectFrame::Transfer { transfer_id } => {
                                if let Some(transfer) = self
                                    .outbound_block_direct_transfers
                                    .remove(&completed_peer)
                                    .filter(|transfer| transfer.manifest.transfer_id == transfer_id)
                                {
                                    metrics::histogram!("n42_block_direct_transfer_send_ms")
                                        .record(
                                            transfer.started_at.elapsed().as_secs_f64() * 1_000.0,
                                        );
                                    metrics::counter!("n42_block_direct_chunk_bytes_sent_total")
                                        .increment(transfer.data.len() as u64);
                                }
                                self.dispatch_queued_block_direct(completed_peer);
                            }
                        }
                    } else {
                        tracing::debug!(%peer, ?request_id, "received block direct ACK for unknown request");
                    }
                }
            },
            libp2p::request_response::Event::OutboundFailure {
                peer,
                request_id,
                error,
                ..
            } => {
                let pending = self.pending_block_direct_requests.remove(&request_id);
                let failed_peer = pending.as_ref().map(|request| request.peer).unwrap_or(peer);
                let (bytes, elapsed_ms) = pending
                    .as_ref()
                    .map(|request| {
                        (
                            request.bytes,
                            request.started_at.elapsed().as_millis() as u64,
                        )
                    })
                    .unwrap_or_default();
                tracing::warn!(
                    %peer,
                    ?request_id,
                    ?error,
                    bytes,
                    elapsed_ms,
                    pending = self.pending_block_direct_requests.len(),
                    "N42_BLOCK_DIRECT_FAILURE: block direct send failed"
                );
                metrics::counter!("n42_block_direct_send_failures").increment(1);
                metrics::gauge!("n42_block_direct_pending")
                    .set(self.pending_block_direct_requests.len() as f64);
                self.outbound_block_direct_transfers.remove(&failed_peer);
                if let Some(pending) = pending
                    && pending.attempt < MAX_BLOCK_DIRECT_RETRIES
                {
                    let next_attempt = pending.attempt + 1;
                    let queue = self
                        .queued_block_direct_by_peer
                        .entry(failed_peer)
                        .or_default();
                    if queue.len() >= block_direct_queue_depth() {
                        // Preserve the failed older block and the contiguous
                        // prefix; a later suffix is the only safe eviction.
                        queue.pop_back();
                        metrics::counter!("n42_block_direct_retry_suffix_evictions_total")
                            .increment(1);
                    }
                    queue.push_front(QueuedBlockDirect {
                        data: pending.data,
                        transfer_id: match pending.frame {
                            PendingBlockDirectFrame::Complete => None,
                            PendingBlockDirectFrame::Transfer { transfer_id } => Some(transfer_id),
                        },
                        attempt: next_attempt,
                    });
                    metrics::counter!("n42_block_direct_retries_total").increment(1);
                    tracing::warn!(
                        %failed_peer,
                        next_attempt,
                        max_attempts = MAX_BLOCK_DIRECT_RETRIES + 1,
                        "N42_BLOCK_DIRECT_RETRY: requeued failed block at the ordered queue head"
                    );
                }
                let queued_total = self
                    .queued_block_direct_by_peer
                    .values()
                    .map(VecDeque::len)
                    .sum::<usize>();
                metrics::gauge!("n42_block_direct_queued").set(queued_total as f64);
                self.dispatch_queued_block_direct(failed_peer);
            }
            libp2p::request_response::Event::InboundFailure { .. } => {}
            libp2p::request_response::Event::ResponseSent { .. } => {}
        }
    }

    fn handle_gov5_block_push_event(
        &mut self,
        event: libp2p::request_response::Event<Gov5BlockPushRequest, Gov5BlockPushResponse>,
    ) {
        match event {
            libp2p::request_response::Event::Message {
                peer,
                message:
                    libp2p::request_response::Message::Request {
                        request, channel, ..
                    },
                ..
            } => {
                if !gov5_direct_source_authorized(
                    peer,
                    self.reconnection.is_trusted(&peer),
                    &self.peer_validator_map,
                    &self.authenticated_peer_validator_map,
                ) {
                    metrics::counter!(
                        "n42_gov5_block_push_rejected_total",
                        "reason" => "unauthorized"
                    )
                    .increment(1);
                    tracing::warn!(
                        target: "n42::interop::block",
                        %peer,
                        bytes = request.rlp.len(),
                        "rejected Gov5 direct block push from an unbound peer"
                    );
                    let _ = self
                        .swarm
                        .behaviour_mut()
                        .gov5_block_push
                        .send_response(channel, Gov5BlockPushResponse);
                    return;
                }
                metrics::counter!("n42_gov5_block_push_received_total").increment(1);
                if let Err(error) = self.retain_gov5_served_block(&request.rlp, None) {
                    tracing::warn!(
                        target: "n42::interop::block",
                        %peer,
                        %error,
                        "refusing to retain malformed gov5 block push"
                    );
                }
                self.emit_event(NetworkEvent::Gov5Block {
                    source: peer,
                    rlp: request.rlp,
                });
                let _ = self
                    .swarm
                    .behaviour_mut()
                    .gov5_block_push
                    .send_response(channel, Gov5BlockPushResponse);
            }
            libp2p::request_response::Event::Message {
                peer,
                message: libp2p::request_response::Message::Response { .. },
                ..
            } => {
                tracing::debug!(%peer, "gov5 block push completed");
                metrics::counter!("n42_gov5_block_push_completed_total").increment(1);
            }
            libp2p::request_response::Event::OutboundFailure { peer, error, .. } => {
                tracing::warn!(%peer, ?error, "gov5 block direct push failed");
                metrics::counter!("n42_gov5_block_push_send_failures_total").increment(1);
            }
            libp2p::request_response::Event::InboundFailure { peer, error, .. } => {
                tracing::debug!(%peer, ?error, "inbound gov5 block push failed");
            }
            libp2p::request_response::Event::ResponseSent { .. } => {}
        }
    }

    fn handle_gov5_hotstuff_direct_event(
        &mut self,
        event: libp2p::request_response::Event<
            Gov5HotstuffDirectRequest,
            Gov5HotstuffDirectResponse,
        >,
    ) {
        match event {
            libp2p::request_response::Event::Message {
                peer,
                message:
                    libp2p::request_response::Message::Request {
                        request, channel, ..
                    },
                ..
            } => {
                // Direct request-response streams have no GossipSub peer
                // scoring or mesh admission. Admit only operator-trusted peers
                // or PeerIds already bound to the current validator set. A
                // routed (but not yet BLS-promoted) validator is allowed so its
                // first valid signed message can establish full authentication.
                if !gov5_direct_source_authorized(
                    peer,
                    self.reconnection.is_trusted(&peer),
                    &self.peer_validator_map,
                    &self.authenticated_peer_validator_map,
                ) {
                    metrics::counter!("n42_gov5_h2_direct_rejected_total", "reason" => "unauthorized")
                        .increment(1);
                    tracing::warn!(
                        target: "n42::interop::h2v4",
                        %peer,
                        bytes = request.data.len(),
                        "rejected Gov5 direct consensus message from an unbound peer"
                    );
                    let _ = self
                        .swarm
                        .behaviour_mut()
                        .gov5_hotstuff_direct
                        .send_response(channel, Gov5HotstuffDirectResponse);
                    return;
                }
                match decode_gov5_gossip_message(&request.data) {
                    Ok(message) => {
                        metrics::counter!(
                            "n42_gov5_h2_direct_received_total",
                            "kind" => message.kind().as_str()
                        )
                        .increment(1);
                        self.emit_event(NetworkEvent::Gov5H2Message {
                            source: peer,
                            message: Box::new(message),
                        });
                    }
                    Err(error) => {
                        metrics::counter!("n42_gov5_h2_direct_rejected_total").increment(1);
                        tracing::warn!(
                            target: "n42::interop::h2v4",
                            %peer,
                            %error,
                            "rejected malformed Gov5 direct consensus message"
                        );
                    }
                }
                let _ = self
                    .swarm
                    .behaviour_mut()
                    .gov5_hotstuff_direct
                    .send_response(channel, Gov5HotstuffDirectResponse);
            }
            libp2p::request_response::Event::Message {
                peer,
                message: libp2p::request_response::Message::Response { .. },
                ..
            } => {
                tracing::debug!(%peer, "Gov5 direct consensus delivery completed");
            }
            libp2p::request_response::Event::OutboundFailure { peer, error, .. } => {
                // Gov5 intentionally closes this one-way stream without an
                // acknowledgement. Gossip remains the independent fallback.
                tracing::debug!(%peer, ?error, "Gov5 direct consensus stream completed without ACK");
            }
            libp2p::request_response::Event::InboundFailure { peer, error, .. } => {
                tracing::debug!(%peer, ?error, "Gov5 direct consensus receive failed");
            }
            libp2p::request_response::Event::ResponseSent { .. } => {}
        }
    }

    fn handle_gov5_block_by_hash_event(
        &mut self,
        event: libp2p::request_response::Event<Gov5BlockByHashRequest, Gov5BlockByHashResponse>,
    ) {
        match event {
            libp2p::request_response::Event::Message {
                peer,
                message:
                    libp2p::request_response::Message::Request {
                        request, channel, ..
                    },
                ..
            } => {
                let response = self
                    .gov5_served_blocks
                    .get(&request.block_hash)
                    .cloned()
                    .unwrap_or_default();
                let found = !response.is_empty();
                if self
                    .swarm
                    .behaviour_mut()
                    .gov5_block_by_hash
                    .send_response(channel, Gov5BlockByHashResponse { rlp: response })
                    .is_err()
                {
                    tracing::warn!(%peer, block_hash = %request.block_hash, "failed to answer Gov5 block-by-hash request");
                } else {
                    metrics::counter!(
                        "n42_gov5_block_fetch_responses_total",
                        "result" => if found { "found" } else { "missing" }
                    )
                    .increment(1);
                    tracing::debug!(
                        %peer,
                        block_hash = %request.block_hash,
                        found,
                        "answered Gov5 block-by-hash request"
                    );
                }
            }
            libp2p::request_response::Event::Message {
                peer,
                message:
                    libp2p::request_response::Message::Response {
                        request_id,
                        response,
                    },
                ..
            } => {
                let Some(requested_hash) = self.pending_gov5_block_requests.remove(&request_id)
                else {
                    tracing::debug!(%peer, "received redundant gov5 block response after another fan-out peer succeeded");
                    return;
                };
                match self.retain_gov5_served_block(&response.rlp, Some(requested_hash)) {
                    Ok(_) => {}
                    Err(error) => {
                        // Only an invalid matching header rules out the hash.
                        // An empty response or a corrupt body attached to an
                        // honest header must remain retryable through another peer.
                        let permanent = error.is_permanent()
                            && attributable_hash(&response.rlp) == Some(requested_hash);
                        metrics::counter!("n42_gov5_block_fetch_failed_total").increment(1);
                        if !self
                            .pending_gov5_block_requests
                            .values()
                            .any(|hash| *hash == requested_hash)
                        {
                            self.pending_gov5_block_hashes.remove(&requested_hash);
                            self.recent_gov5_block_requests.remove(&requested_hash);
                            self.emit_event(NetworkEvent::Gov5BlockFetchFailed {
                                source: peer,
                                block_hash: requested_hash,
                                error: format!("all fan-out peers failed; final response: {error}"),
                                permanent,
                            });
                        }
                        return;
                    }
                }
                self.pending_gov5_block_hashes.remove(&requested_hash);
                self.pending_gov5_block_requests
                    .retain(|_, hash| *hash != requested_hash);
                // This entry only guards an in-flight attempt and its short
                // retry cooldown. Keeping every successful historical hash
                // makes the overflow cleanup scan thousands of entries on
                // every step of a long reverse ancestry.
                self.recent_gov5_block_requests.remove(&requested_hash);
                remember_gov5_block_fulfilled(
                    &mut self.recent_gov5_block_fulfilled,
                    requested_hash,
                    Instant::now(),
                );
                metrics::counter!("n42_gov5_block_fetch_succeeded_total").increment(1);
                self.emit_event(NetworkEvent::Gov5BlockFetched {
                    source: peer,
                    requested_hash,
                    rlp: response.rlp,
                });
            }
            libp2p::request_response::Event::OutboundFailure {
                peer,
                request_id,
                error,
                ..
            } => {
                if let Some(block_hash) = self.pending_gov5_block_requests.remove(&request_id) {
                    let error_text = error.to_string();
                    if error_text.contains("supports none")
                        || error_text.contains("UnsupportedProtocols")
                    {
                        self.gov5_block_by_hash_peers.remove(&peer);
                    }
                    metrics::counter!("n42_gov5_block_fetch_failed_total").increment(1);
                    if !self
                        .pending_gov5_block_requests
                        .values()
                        .any(|hash| *hash == block_hash)
                    {
                        self.pending_gov5_block_hashes.remove(&block_hash);
                        self.recent_gov5_block_requests.remove(&block_hash);
                        self.emit_event(NetworkEvent::Gov5BlockFetchFailed {
                            source: peer,
                            block_hash,
                            error: format!("all fan-out peers failed; final failure: {error_text}"),
                            // Transport-level: the content was never seen.
                            permanent: false,
                        });
                    }
                }
            }
            libp2p::request_response::Event::InboundFailure { peer, error, .. } => {
                tracing::debug!(%peer, %error, "gov5 block-by-hash inbound failure");
            }
            libp2p::request_response::Event::ResponseSent { .. } => {}
        }
    }

    fn gov5_range_peer_is_authorized(&self, peer: &PeerId) -> bool {
        (self.reconnection.is_trusted(peer)
            || self.authenticated_peer_validator_map.contains_key(peer))
            && self.gov5_chain_authenticated_peers.contains(peer)
    }

    fn reject_gov5_range(
        &mut self,
        channel: libp2p::request_response::ResponseChannel<Gov5BodiesByRangeResponse>,
        code: u8,
        message: String,
    ) {
        let _ = self
            .swarm
            .behaviour_mut()
            .gov5_bodies_by_range
            .send_response(channel, Gov5BodiesByRangeResponse::Error { code, message });
    }

    fn handle_gov5_bodies_by_range_event(
        &mut self,
        event: libp2p::request_response::Event<Gov5BodiesByRangeRequest, Gov5BodiesByRangeResponse>,
    ) {
        match event {
            libp2p::request_response::Event::Message {
                peer,
                message:
                    libp2p::request_response::Message::Request {
                        request_id,
                        request,
                        channel,
                    },
                ..
            } => {
                if let Err(error) = request.validate() {
                    metrics::counter!(
                        "n42_gov5_range_requests_rejected_total",
                        "reason" => "invalid"
                    )
                    .increment(1);
                    self.reject_gov5_range(channel, 1, error.to_string());
                    return;
                }
                if !self.gov5_range_peer_is_authorized(&peer) {
                    metrics::counter!(
                        "n42_gov5_range_requests_rejected_total",
                        "reason" => "unauthorized"
                    )
                    .increment(1);
                    tracing::warn!(
                        target: "n42::interop::range",
                        %peer,
                        "refusing Gov5 range request before trusted chain authentication"
                    );
                    self.reject_gov5_range(
                        channel,
                        1,
                        "peer is not authorized for canonical range sync".to_owned(),
                    );
                    return;
                }
                let Some(reader) = self.gov5_canonical_blocks.clone() else {
                    metrics::counter!(
                        "n42_gov5_range_requests_rejected_total",
                        "reason" => "unavailable"
                    )
                    .increment(1);
                    self.reject_gov5_range(
                        channel,
                        2,
                        "canonical block provider is unavailable".to_owned(),
                    );
                    return;
                };
                let best = match reader.best_block_number() {
                    Ok(best) => best,
                    Err(error) => {
                        metrics::counter!(
                            "n42_gov5_range_requests_rejected_total",
                            "reason" => "provider"
                        )
                        .increment(1);
                        self.reject_gov5_range(
                            channel,
                            2,
                            format!("canonical head lookup failed: {error}"),
                        );
                        return;
                    }
                };
                if request.start > best.saturating_add(2 * 1024) {
                    metrics::counter!(
                        "n42_gov5_range_requests_rejected_total",
                        "reason" => "future"
                    )
                    .increment(1);
                    self.reject_gov5_range(
                        channel,
                        1,
                        "range starts too far beyond the canonical head".to_owned(),
                    );
                    return;
                }
                let pending_for_peer = self
                    .pending_gov5_ranges
                    .values()
                    .filter(|pending_peer| **pending_peer == peer)
                    .count();
                if self.pending_gov5_ranges.len() >= MAX_PENDING_GOV5_RANGES
                    || pending_for_peer >= MAX_PENDING_GOV5_RANGES_PER_PEER
                {
                    metrics::counter!(
                        "n42_gov5_range_requests_rejected_total",
                        "reason" => "concurrency"
                    )
                    .increment(1);
                    self.reject_gov5_range(
                        channel,
                        1,
                        "too many range responses are already in flight".to_owned(),
                    );
                    return;
                }
                let now = Instant::now();
                if !self
                    .gov5_range_quotas
                    .entry(peer)
                    .or_insert_with(|| Gov5RangeQuota::new(now))
                    .allow(now, request.count)
                {
                    metrics::counter!(
                        "n42_gov5_range_requests_rejected_total",
                        "reason" => "rate_limit"
                    )
                    .increment(1);
                    self.reject_gov5_range(
                        channel,
                        1,
                        "range block-rate limit exceeded".to_owned(),
                    );
                    return;
                }

                let fork_digest = self
                    .gov5_status
                    .expect("authorized Gov5 range peer requires interop status")
                    .genesis_hash
                    .as_slice()[..4]
                    .try_into()
                    .expect("four-byte genesis prefix");
                let response = Gov5BodiesByRangeResponse::Stream {
                    request,
                    fork_digest,
                    reader,
                };
                if self
                    .swarm
                    .behaviour_mut()
                    .gov5_bodies_by_range
                    .send_response(channel, response)
                    .is_err()
                {
                    metrics::counter!(
                        "n42_gov5_range_requests_rejected_total",
                        "reason" => "closed"
                    )
                    .increment(1);
                    tracing::debug!(%peer, ?request_id, "Gov5 range response channel closed");
                } else {
                    self.pending_gov5_ranges.insert(request_id, peer);
                    metrics::counter!("n42_gov5_range_requests_accepted_total").increment(1);
                    metrics::counter!("n42_gov5_range_blocks_requested_total")
                        .increment(request.count);
                    tracing::debug!(
                        target: "n42::interop::range",
                        %peer,
                        ?request_id,
                        start = request.start,
                        count = request.count,
                        "serving Gov5 canonical block range"
                    );
                }
            }
            libp2p::request_response::Event::Message {
                peer,
                message: libp2p::request_response::Message::Response { .. },
                ..
            } => {
                tracing::warn!(%peer, "unexpected outbound Gov5 bodies-by-range response");
            }
            libp2p::request_response::Event::InboundFailure {
                peer,
                request_id,
                error,
                ..
            } => {
                self.pending_gov5_ranges.remove(&request_id);
                metrics::counter!("n42_gov5_range_response_failures_total").increment(1);
                tracing::debug!(%peer, ?request_id, %error, "Gov5 range response failed");
            }
            libp2p::request_response::Event::OutboundFailure { peer, error, .. } => {
                tracing::warn!(%peer, %error, "unexpected outbound Gov5 range request failed");
            }
            libp2p::request_response::Event::ResponseSent {
                peer, request_id, ..
            } => {
                self.pending_gov5_ranges.remove(&request_id);
                metrics::counter!("n42_gov5_range_responses_completed_total").increment(1);
                tracing::debug!(%peer, ?request_id, "Gov5 range response completed");
            }
        }
    }

    fn handle_gov5_status_event(
        &mut self,
        event: libp2p::request_response::Event<Gov5Status, Gov5Status>,
    ) {
        let Some(local_status) = self.current_gov5_status() else {
            return;
        };
        match event {
            libp2p::request_response::Event::Message {
                peer,
                message:
                    libp2p::request_response::Message::Request {
                        request, channel, ..
                    },
                ..
            } => {
                if request.genesis_hash != local_status.genesis_hash {
                    self.gov5_chain_authenticated_peers.remove(&peer);
                    tracing::warn!(%peer, remote_genesis = %request.genesis_hash, local_genesis = %local_status.genesis_hash, "gov5 status genesis mismatch");
                } else {
                    self.gov5_chain_authenticated_peers.insert(peer);
                }
                let _ = self
                    .swarm
                    .behaviour_mut()
                    .gov5_status
                    .send_response(channel, local_status);
            }
            libp2p::request_response::Event::Message {
                peer,
                message: libp2p::request_response::Message::Response { response, .. },
                ..
            } => {
                if response.genesis_hash == local_status.genesis_hash {
                    self.gov5_chain_authenticated_peers.insert(peer);
                    metrics::counter!("n42_gov5_status_succeeded_total").increment(1);
                    tracing::debug!(%peer, height = response.current_height, "validated gov5 status response");
                } else {
                    self.gov5_chain_authenticated_peers.remove(&peer);
                    metrics::counter!("n42_gov5_status_failed_total").increment(1);
                    tracing::warn!(%peer, remote_genesis = %response.genesis_hash, local_genesis = %local_status.genesis_hash, "rejected gov5 status response for another genesis");
                }
            }
            libp2p::request_response::Event::OutboundFailure { peer, error, .. } => {
                metrics::counter!("n42_gov5_status_failed_total").increment(1);
                tracing::info!(%peer, %error, "gov5 status outbound exchange failed");
            }
            libp2p::request_response::Event::InboundFailure { peer, error, .. } => {
                metrics::counter!("n42_gov5_status_failed_total").increment(1);
                tracing::info!(%peer, %error, "gov5 status inbound exchange failed");
            }
            libp2p::request_response::Event::ResponseSent { .. } => {}
        }
    }

    fn observe_block_announcement(&mut self, data: &[u8], source: &'static str) -> bool {
        let duplicate = self.recent_block_announcements.observe(data);
        if duplicate {
            metrics::counter!("n42_block_announcement_dup_raw_total", "source" => source)
                .increment(1);
            metrics::counter!(
                "n42_block_announcement_dup_raw_bytes_total",
                "source" => source
            )
            .increment(data.len() as u64);
            metrics::histogram!("n42_block_announcement_dup_raw_bytes", "source" => source)
                .record(data.len() as f64);
        }
        duplicate
    }

    fn handle_tx_forward_event(
        &mut self,
        event: libp2p::request_response::Event<TxForwardRequest, TxForwardResponse>,
    ) {
        match event {
            libp2p::request_response::Event::Message { peer, message, .. } => match message {
                libp2p::request_response::Message::Request {
                    request, channel, ..
                } => {
                    let count = request.txs.len();
                    metrics::counter!("n42_tx_forward_batches_received").increment(1);
                    metrics::counter!("n42_tx_forward_txs_received").increment(count as u64);
                    if self.authenticated_peer_validator_map.contains_key(&peer) {
                        tracing::debug!(%peer, count, "received forwarded tx batch from validator");
                        self.emit_event(NetworkEvent::TxForwardReceived {
                            source: peer,
                            txs: request.txs,
                        });
                        if self
                            .swarm
                            .behaviour_mut()
                            .tx_forward
                            .send_response(
                                channel,
                                TxForwardResponse {
                                    accepted: true,
                                    remaining_credit: None,
                                },
                            )
                            .is_err()
                        {
                            tracing::warn!(%peer, "failed to send tx forward ACK");
                        }
                    } else {
                        tracing::warn!(%peer, count, "rejected tx forward from unauthenticated peer");
                        if self
                            .swarm
                            .behaviour_mut()
                            .tx_forward
                            .send_response(
                                channel,
                                TxForwardResponse {
                                    accepted: false,
                                    remaining_credit: Some(0),
                                },
                            )
                            .is_err()
                        {
                            tracing::warn!(%peer, "failed to send tx forward rejection");
                        }
                    }
                }
                libp2p::request_response::Message::Response { response, .. } => {
                    if response.remaining_credit.is_some() {
                        self.emit_event(NetworkEvent::TxForwardCreditUpdate {
                            remaining_credit: response.remaining_credit,
                        });
                    }
                }
            },
            libp2p::request_response::Event::OutboundFailure { peer, error, .. } => {
                tracing::debug!(%peer, ?error, "tx forward send failed");
            }
            libp2p::request_response::Event::InboundFailure { .. } => {}
            libp2p::request_response::Event::ResponseSent { .. } => {}
        }
    }

    fn handle_mdns_event(&mut self, event: libp2p::mdns::Event) {
        match event {
            libp2p::mdns::Event::Discovered(peers) => {
                for (peer_id, addr) in peers {
                    tracing::info!(%peer_id, %addr, "mDNS: discovered peer");
                    // Avoid add_explicit_peer() — explicit peers are excluded from
                    // GossipSub mesh formation. Dial instead and let heartbeat add them.
                    self.reconnection
                        .register_peer(peer_id, vec![addr.clone()], false);
                    if let Err(e) = self.swarm.dial(addr.clone()) {
                        tracing::debug!(%peer_id, error = %e, "mDNS dial failed");
                    }
                }
            }
            libp2p::mdns::Event::Expired(peers) => {
                for (peer_id, _) in peers {
                    tracing::debug!(%peer_id, "mDNS: peer expired");
                }
            }
        }
    }

    fn handle_kademlia_event(&mut self, event: libp2p::kad::Event) {
        match event {
            libp2p::kad::Event::RoutingUpdated {
                peer, addresses, ..
            } => {
                tracing::debug!(%peer, addrs = addresses.len(), "kademlia routing updated");
            }
            libp2p::kad::Event::OutboundQueryProgressed { result, .. } => match result {
                libp2p::kad::QueryResult::GetClosestPeers(Ok(ok)) => {
                    tracing::debug!(peers = ok.peers.len(), "kademlia closest peers query done");
                    for peer_info in &ok.peers {
                        let peer_id = peer_info.peer_id;
                        if !self.swarm.is_connected(&peer_id) {
                            for addr in &peer_info.addrs {
                                if self.swarm.dial(addr.clone()).is_ok() {
                                    self.reconnection.register_peer(
                                        peer_id,
                                        vec![addr.clone()],
                                        false,
                                    );
                                    break;
                                }
                            }
                        }
                    }
                }
                libp2p::kad::QueryResult::Bootstrap(Ok(ok)) => {
                    tracing::debug!(
                        num_remaining = ok.num_remaining,
                        "kademlia bootstrap progress"
                    );
                }
                libp2p::kad::QueryResult::Bootstrap(Err(e)) => {
                    tracing::warn!(error = ?e, "kademlia bootstrap failed");
                }
                _ => {}
            },
            _ => {}
        }
    }

    /// Sends a network event to the node layer via the appropriate channel.
    ///
    /// Consensus messages AND block data go to the high-priority channel so they
    /// are never delayed by high-volume TX events in the data channel.
    /// BlockData is critical for follower import pipeline — deprioritizing it
    /// delays block import → delays voting → delays commit.
    fn emit_event(&mut self, event: NetworkEvent) {
        // H2 participant block bodies are part of the execution-gated
        // consensus path. Routing gossip/fetch responses through the lower
        // data lane lets a continuously readable consensus lane starve them:
        // the node can authenticate and commit several hashes while reth
        // remains unable to execute any of their bodies. Preserve observer
        // isolation by promoting these events only in participant mode.
        let reliable_consensus = event_uses_consensus_lane(&event, self.h2_v4_participant);
        let reliable_data = matches!(
            &event,
            NetworkEvent::Gov5H2Message { .. }
                | NetworkEvent::Gov5Block { .. }
                | NetworkEvent::Gov5BlockFetched { .. }
                | NetworkEvent::Gov5BlockFetchFailed { .. }
                | NetworkEvent::H2V4Message { .. }
                | NetworkEvent::VerificationReceipt { .. }
                | NetworkEvent::BlobSidecarReceived { .. }
                | NetworkEvent::PeerConnected(_)
                | NetworkEvent::PeerDisconnected(_)
                | NetworkEvent::TxForwardReceived { .. }
                | NetworkEvent::TxForwardCreditUpdate { .. }
                | NetworkEvent::SyncRequest { .. }
                | NetworkEvent::SyncResponse { .. }
                | NetworkEvent::SyncRequestFailed { .. }
        );
        let tx = if reliable_consensus {
            &self.consensus_event_tx
        } else {
            &self.event_tx
        };
        match tx.try_send(event) {
            Ok(()) => {}
            Err(mpsc::error::TrySendError::Full(event)) => {
                if reliable_consensus {
                    push_bounded_backlog(
                        &mut self.pending_reliable_events,
                        MAX_PENDING_RELIABLE_EVENTS,
                        event,
                        "consensus",
                    );
                } else if reliable_data {
                    push_bounded_backlog(
                        &mut self.pending_data_events,
                        MAX_PENDING_DATA_EVENTS,
                        event,
                        "data",
                    );
                } else {
                    metrics::counter!("n42_network_event_drops_total").increment(1);
                    tracing::warn!("event channel full, dropping event");
                }
            }
            Err(mpsc::error::TrySendError::Closed(_)) => {
                tracing::warn!("event channel closed, consumer gone");
            }
        }
    }

    /// Publish raw data to a gossipsub topic.
    fn gossipsub_publish(&mut self, topic: gossipsub::IdentTopic, data: Vec<u8>, label: &str) {
        match self.swarm.behaviour_mut().gossipsub.publish(topic, data) {
            Ok(_) => {}
            Err(gossipsub::PublishError::NoPeersSubscribedToTopic) => {
                tracing::debug!("failed to publish {label}: no peers subscribed to topic");
            }
            Err(e) => {
                tracing::warn!(error = %e, "failed to publish {label}");
            }
        }
    }

    /// Encode a consensus message and publish it to the consensus topic.
    fn publish_consensus(&mut self, msg: &ConsensusMessage, label: &str) {
        match encode_consensus_message(msg) {
            Ok(data) => self.gossipsub_publish(consensus_topic(), data, label),
            Err(e) => tracing::error!(error = %e, "failed to encode {label}"),
        }
    }

    fn handle_command(&mut self, command: NetworkCommand) {
        match command {
            NetworkCommand::BroadcastConsensus(msg) => {
                metrics::counter!("n42_broadcast_messages_sent").increment(1);
                self.publish_consensus(&msg, "consensus message");
            }
            NetworkCommand::BroadcastH2V4(envelope) => {
                if !self.h2_v4_participant {
                    tracing::warn!(target: "n42::interop::h2v4", "refusing H2-v4 publish outside participant mode");
                    return;
                }
                // Publish both migration transports and also fan out the
                // canonical payload over Gov5's reliable Rotor/direct stream.
                // Direct delivery is required for leader/vote latency even
                // while either GossipSub mesh is still converging.
                match encode_gov5_gossip_message(&envelope.message) {
                    Ok(data) => {
                        metrics::counter!(
                            "n42_gov5_h2_messages_sent_total",
                            "kind" => envelope.message.kind().as_str()
                        )
                        .increment(1);
                        self.gossipsub_publish(
                            gov5_h2_topic(envelope.identity.genesis_hash),
                            data.clone(),
                            "Gov5 H2-v4 consensus message",
                        );
                        let direct_peers: Vec<PeerId> = self
                            .validator_peer_map
                            .read()
                            .unwrap_or_else(|error| {
                                tracing::warn!(%error, "validator_peer_map poisoned, recovering");
                                error.into_inner()
                            })
                            .iter()
                            .filter_map(|(index, peer)| {
                                (Some(*index) != self.my_validator_index).then_some(*peer)
                            })
                            .collect();
                        for peer in &direct_peers {
                            self.swarm
                                .behaviour_mut()
                                .gov5_hotstuff_direct
                                .send_request(
                                    peer,
                                    Gov5HotstuffDirectRequest { data: data.clone() },
                                );
                        }
                        metrics::counter!(
                            "n42_gov5_h2_direct_sent_total",
                            "kind" => envelope.message.kind().as_str()
                        )
                        .increment(direct_peers.len() as u64);
                    }
                    Err(error) => {
                        tracing::warn!(
                            target: "n42::interop::h2v4",
                            %error,
                            "failed to encode canonical Gov5 H2-v4 message"
                        )
                    }
                }
                match encode_h2_v4_gossip(&envelope) {
                    Ok(data) => {
                        metrics::counter!("n42_h2_v4_messages_sent_total", "kind" => envelope.message.kind().as_str()).increment(1);
                        self.gossipsub_publish(h2_v4_topic(), data, "H2-v4 consensus message");
                    }
                    Err(error) => {
                        tracing::warn!(target: "n42::interop::h2v4", %error, "failed to encode H2-v4 message")
                    }
                }
            }
            NetworkCommand::BroadcastGov5Block(rlp) => {
                let Some(identity) = self.h2_v4_identity.filter(|_| self.h2_v4_participant) else {
                    tracing::warn!(target: "n42::interop::h2v4", "refusing gov5 block publish outside participant mode");
                    return;
                };

                if let Err(error) = self.retain_gov5_served_block(&rlp, None) {
                    tracing::warn!(
                        target: "n42::interop::h2v4",
                        %error,
                        "refusing to retain malformed local Gov5 block"
                    );
                    return;
                }

                // Gov5's canonical leader delivery is a one-way direct stream.
                // Fan out the raw RLP to every connected validator before the
                // gossip fallback; a lone block publisher cannot rely on a
                // GossipSub mesh being formed for the block topic.
                let direct_peers: Vec<PeerId> = self
                    .validator_peer_map
                    .read()
                    .unwrap_or_else(|error| {
                        tracing::warn!(%error, "validator_peer_map poisoned, recovering");
                        error.into_inner()
                    })
                    .iter()
                    .filter_map(|(index, peer)| {
                        (Some(*index) != self.my_validator_index).then_some(*peer)
                    })
                    .collect();
                for peer in &direct_peers {
                    self.swarm.behaviour_mut().gov5_block_push.send_request(
                        peer,
                        Gov5BlockPushRequest {
                            rlp: rlp.clone(),
                            fork_digest: identity.genesis_hash.as_slice()[..4]
                                .try_into()
                                .expect("four-byte genesis prefix"),
                        },
                    );
                }
                metrics::counter!("n42_gov5_block_push_sent_total")
                    .increment(direct_peers.len() as u64);
                tracing::info!(
                    target: "n42::interop::h2v4",
                    peers = direct_peers.len(),
                    bytes = rlp.len(),
                    "direct-pushed gov5 leader block"
                );

                match crate::snappy_pool::raw_compress(&rlp) {
                    Ok(data) => {
                        metrics::counter!("n42_h2_v4_blocks_sent_total").increment(1);
                        self.gossipsub_publish(
                            gov5_block_topic(identity.genesis_hash),
                            data,
                            "gov5 block",
                        );
                    }
                    Err(error) => {
                        tracing::warn!(target: "n42::interop::h2v4", %error, "failed to compress gov5 block")
                    }
                }
            }
            NetworkCommand::SendDirect { peer, message } => {
                metrics::counter!("n42_direct_messages_sent").increment(1);
                // Use request-response for true point-to-point delivery instead of gossipsub.
                match encode_consensus_message(&message) {
                    Ok(bytes) => {
                        let req = ConsensusDirectRequest {
                            message_bytes: bytes,
                        };
                        self.swarm
                            .behaviour_mut()
                            .consensus_direct
                            .send_request(&peer, req);
                        tracing::debug!(%peer, "sending direct message via request-response");
                    }
                    Err(e) => {
                        tracing::warn!(%peer, error = %e, "failed to encode direct message, falling back to broadcast");
                        self.publish_consensus(&message, "direct fallback");
                    }
                }
            }
            NetworkCommand::RequestGov5BlockByHash { peer, block_hash } => {
                let now = Instant::now();
                if gov5_block_fulfilled_recently(
                    &mut self.recent_gov5_block_fulfilled,
                    block_hash,
                    now,
                ) {
                    metrics::counter!(
                        "n42_gov5_block_fetch_suppressed_total",
                        "reason" => "already_fulfilled"
                    )
                    .increment(1);
                    return;
                }
                // Hash de-duplication must not outlive the transport request
                // that created it. In live catch-up a request could lose
                // every terminal swarm event, leaving the orchestrator's
                // orchestrator retry suppressed even though all
                // Gov5 peers already served the body. Reap every overdue hash
                // before applying pending/capacity checks; late responses are
                // safely treated as redundant by the response handler.
                let stale = stale_gov5_block_fetches(
                    &self.pending_gov5_block_hashes,
                    &self.recent_gov5_block_requests,
                    now,
                );
                for stale_hash in stale {
                    let requests_before = self.pending_gov5_block_requests.len();
                    self.pending_gov5_block_requests
                        .retain(|_, hash| *hash != stale_hash);
                    self.pending_gov5_block_hashes.remove(&stale_hash);
                    self.recent_gov5_block_requests.remove(&stale_hash);
                    let reaped = requests_before - self.pending_gov5_block_requests.len();
                    metrics::counter!("n42_gov5_block_fetch_stale_rearmed_total").increment(1);
                    tracing::warn!(
                        %stale_hash,
                        reaped,
                        "re-armed stale Gov5 block fetch after transport deadline"
                    );
                }
                if self.pending_gov5_block_hashes.contains(&block_hash)
                    || self.pending_gov5_block_requests.len() >= MAX_PENDING_GOV5_BLOCK_REQUESTS
                {
                    metrics::counter!(
                        "n42_gov5_block_fetch_suppressed_total",
                        "reason" => "pending"
                    )
                    .increment(1);
                    return;
                }

                if self.recent_gov5_block_requests.len() >= MAX_RECENT_GOV5_BLOCK_REQUESTS {
                    self.recent_gov5_block_requests.retain(|_, (attempted, _)| {
                        now.duration_since(*attempted) < Duration::from_secs(60)
                    });
                }
                let previous = self.recent_gov5_block_requests.get(&block_hash).copied();
                if previous.is_some_and(|(attempted, _)| {
                    now.duration_since(attempted) < GOV5_BLOCK_REQUEST_COOLDOWN
                }) {
                    metrics::counter!(
                        "n42_gov5_block_fetch_suppressed_total",
                        "reason" => "cooldown"
                    )
                    .increment(1);
                    return;
                }

                let last_peer = previous.map(|(_, last_peer)| last_peer);
                // Gov5 registers the compatible stream handler after its
                // identify service starts, so older peers do not always
                // advertise the protocol in their first identify snapshot.
                // A trusted, connected preferred peer is still safe to try:
                // multistream-select will reject it cleanly if unsupported.
                // Falling back across all connected peers also avoids a
                // Rust↔Rust missing-parent loop when only Rust peers happened
                // to advertise the capability.
                let connected: Vec<_> = self.swarm.connected_peers().copied().collect();
                let advertised_connected: Vec<_> = self
                    .gov5_block_by_hash_peers
                    .iter()
                    .copied()
                    .filter(|candidate| connected.contains(candidate))
                    .collect();
                let mut selected_peers =
                    gov5_block_fetch_fanout(peer, last_peer, &advertised_connected, &connected);
                let available =
                    MAX_PENDING_GOV5_BLOCK_REQUESTS - self.pending_gov5_block_requests.len();
                selected_peers.truncate(available);
                if selected_peers.is_empty() {
                    metrics::counter!(
                        "n42_gov5_block_fetch_suppressed_total",
                        "reason" => "unsupported_peer"
                    )
                    .increment(1);
                    tracing::debug!(
                        %peer,
                        %block_hash,
                        "no connected peer advertises gov5 block-by-hash"
                    );
                    return;
                }
                for selected_peer in &selected_peers {
                    let request_id = self
                        .swarm
                        .behaviour_mut()
                        .gov5_block_by_hash
                        .send_request(selected_peer, Gov5BlockByHashRequest { block_hash });
                    self.pending_gov5_block_requests
                        .insert(request_id, block_hash);
                }
                self.pending_gov5_block_hashes.insert(block_hash);
                self.recent_gov5_block_requests
                    .insert(block_hash, (now, selected_peers[0]));
                metrics::counter!("n42_gov5_block_fetch_fanout_total")
                    .increment(selected_peers.len() as u64);
            }
            NetworkCommand::CancelGov5BlockFetch { block_hash } => {
                let requests_before = self.pending_gov5_block_requests.len();
                self.pending_gov5_block_requests
                    .retain(|_, pending_hash| *pending_hash != block_hash);
                let reaped = requests_before - self.pending_gov5_block_requests.len();
                let pending = self.pending_gov5_block_hashes.remove(&block_hash);
                let recent = self.recent_gov5_block_requests.remove(&block_hash);
                remember_gov5_block_fulfilled(
                    &mut self.recent_gov5_block_fulfilled,
                    block_hash,
                    Instant::now(),
                );
                if reaped > 0 || pending || recent.is_some() {
                    metrics::counter!("n42_gov5_block_fetch_cross_path_retired_total").increment(1);
                    tracing::debug!(
                        %block_hash,
                        reaped,
                        "retired Gov5 block fetch satisfied by another delivery path"
                    );
                }
            }
            NetworkCommand::AnnounceBlock(data) => {
                self.gossipsub_publish(block_announce_topic(), data, "block announcement");
            }
            NetworkCommand::BroadcastTransaction(data) => {
                if !self.tx_gossip_disabled {
                    self.gossipsub_publish(mempool_topic(), data, "transaction");
                }
            }
            NetworkCommand::BroadcastBlobSidecar(data) => {
                self.gossipsub_publish(blob_sidecar_topic(), data, "blob sidecar");
            }
            NetworkCommand::SendBlockDirect { peer, data } => {
                self.enqueue_or_dispatch_block_direct(peer, data);
            }
            NetworkCommand::ForwardTxBatch { peer, txs } => {
                let count = txs.len();
                metrics::counter!("n42_tx_forward_batches_sent").increment(1);
                metrics::counter!("n42_tx_forward_txs_sent").increment(count as u64);
                let req = TxForwardRequest { txs };
                self.swarm
                    .behaviour_mut()
                    .tx_forward
                    .send_request(&peer, req);
            }
            NetworkCommand::Dial(addr) => {
                if let Err(e) = self.swarm.dial(addr.clone()) {
                    tracing::warn!(%addr, error = %e, "failed to dial peer");
                }
            }
            NetworkCommand::RequestSync { peer, request } => {
                if !self.state_sync_peers.contains(&peer) {
                    metrics::counter!(
                        "n42_state_sync_requests_suppressed_total",
                        "reason" => "unsupported_peer"
                    )
                    .increment(1);
                    tracing::debug!(
                        %peer,
                        from_view = request.from_view,
                        to_view = request.to_view,
                        "not sending N42 state-sync request to peer without advertised support"
                    );
                    self.emit_event(NetworkEvent::SyncRequestFailed {
                        peer,
                        error: "peer does not advertise N42 state-sync".to_string(),
                        unsupported_protocol: true,
                    });
                    return;
                }
                tracing::debug!(
                    %peer,
                    from_view = request.from_view,
                    to_view = request.to_view,
                    "sending sync request"
                );
                self.swarm
                    .behaviour_mut()
                    .state_sync
                    .send_request(&peer, request);
            }
            NetworkCommand::SendSyncResponse {
                request_id,
                response,
            } => {
                if let Some(channel) = self.pending_sync_channels.remove(&request_id) {
                    let block_count = response.blocks.len();
                    if self
                        .swarm
                        .behaviour_mut()
                        .state_sync
                        .send_response(channel, response)
                        .is_err()
                    {
                        tracing::warn!(request_id, "failed to send sync response (channel closed)");
                    } else {
                        tracing::debug!(request_id, blocks = block_count, "sync response sent");
                    }
                } else {
                    tracing::warn!(request_id, "no pending channel for sync response");
                }
            }
            NetworkCommand::RegisterPeer {
                peer_id,
                addrs,
                trusted,
            } => {
                tracing::debug!(%peer_id, trusted, addrs = addrs.len(), "registering peer");
                self.reconnection.register_peer(peer_id, addrs, trusted);
            }
            NetworkCommand::AuthenticateValidatorPeer {
                peer_id,
                validator_index,
            } => {
                self.authenticate_validator_peer(peer_id, validator_index);
            }
            NetworkCommand::ReplaceExpectedValidatorPeers { peers } => {
                self.replace_expected_validator_peers(peers);
            }
            NetworkCommand::AddKademliaPeer { peer_id, addrs } => {
                if let Some(kad) = self.swarm.behaviour_mut().kademlia.as_mut() {
                    for addr in &addrs {
                        kad.add_address(&peer_id, addr.clone());
                    }
                    tracing::debug!(%peer_id, addrs = addrs.len(), "added peer to kademlia");
                }
            }
            NetworkCommand::SetValidatorContext {
                my_index,
                validator_count,
            } => {
                self.my_validator_index = Some(my_index);
                self.validator_count = validator_count;
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::transport::deterministic_validator_peer_id;

    fn served_block_fixture(number: u64) -> Vec<u8> {
        use alloy_consensus::{Block, Header, TxEnvelope, proofs::calculate_transaction_root};
        let block: Block<TxEnvelope> = Block {
            header: Header {
                number,
                ommers_hash: B256::ZERO,
                transactions_root: calculate_transaction_root::<TxEnvelope>(&[]),
                base_fee_per_gas: Some(0),
                extra_data: alloy_primitives::Bytes::from_static(b"N42H\x07\0\0\0\0\0\0\0"),
                ..Default::default()
            },
            body: Default::default(),
        };
        crate::gov5_block::encode_gov5_block_rlp(
            &alloy_rpc_types_engine::ExecutionData::from_block_unchecked(
                block.header.hash_slow(),
                &block,
            ),
        )
        .unwrap()
    }

    #[test]
    fn gov5_mismatched_fetch_does_not_remove_cached_block_or_grow_fifo() {
        let mut blocks = HashMap::new();
        let mut order = VecDeque::new();
        let rlp = served_block_fixture(1);
        let hash = cache_gov5_served_block(&mut blocks, &mut order, &rlp, None).unwrap();
        let other = served_block_fixture(2);
        for response in [&rlp, &other]
            .into_iter()
            .cycle()
            .take(MAX_SERVED_GOV5_BLOCKS * 2)
        {
            assert!(matches!(
                cache_gov5_served_block(&mut blocks, &mut order, response, Some(B256::ZERO)),
                Err(Gov5BlockError::UnexpectedBlockHash { .. })
            ));
        }
        assert_eq!(blocks.len(), 1);
        assert_eq!(blocks[&hash], rlp);
        assert_eq!(order, VecDeque::from([hash]));
    }

    #[test]
    fn gov5_duplicate_reuses_cached_allocation_but_validates_changed_body() {
        let mut blocks = HashMap::new();
        let mut order = VecDeque::new();
        let rlp = served_block_fixture(1);
        let hash = cache_gov5_served_block(&mut blocks, &mut order, &rlp, None).unwrap();
        let allocation = blocks[&hash].as_ptr();
        assert_eq!(
            cache_gov5_served_block(&mut blocks, &mut order, &rlp, Some(hash)).unwrap(),
            hash
        );
        assert_eq!(blocks[&hash].as_ptr(), allocation);
        let mut corrupt = rlp.clone();
        *corrupt.last_mut().unwrap() = 0x80;
        assert_eq!(attributable_hash(&corrupt), Some(hash));
        assert!(cache_gov5_served_block(&mut blocks, &mut order, &corrupt, Some(hash)).is_err());
        assert_eq!(blocks[&hash], rlp);
        assert_eq!(order, VecDeque::from([hash]));
    }

    #[test]
    fn gov5_serve_cache_evicts_in_fifo_order_at_capacity() {
        let mut blocks = HashMap::new();
        let mut order = VecDeque::new();
        let first =
            cache_gov5_served_block(&mut blocks, &mut order, &served_block_fixture(0), None)
                .unwrap();
        for number in 1..=MAX_SERVED_GOV5_BLOCKS {
            cache_gov5_served_block(
                &mut blocks,
                &mut order,
                &served_block_fixture(number as u64),
                None,
            )
            .unwrap();
        }
        assert_eq!(blocks.len(), MAX_SERVED_GOV5_BLOCKS);
        assert_eq!(order.len(), MAX_SERVED_GOV5_BLOCKS);
        assert!(!blocks.contains_key(&first));
        assert!(order.iter().all(|hash| blocks.contains_key(hash)));
    }

    #[test]
    fn gov5_direct_requires_trust_or_validator_binding() {
        let peer = PeerId::random();
        let other = PeerId::random();
        let routed = HashMap::from([(peer, 3)]);
        let authenticated = HashMap::from([(peer, 3)]);

        assert!(!gov5_direct_source_authorized(
            peer,
            false,
            &HashMap::new(),
            &HashMap::new(),
        ));
        assert!(gov5_direct_source_authorized(
            peer,
            true,
            &HashMap::new(),
            &HashMap::new(),
        ));
        assert!(gov5_direct_source_authorized(
            peer,
            false,
            &routed,
            &HashMap::new(),
        ));
        assert!(gov5_direct_source_authorized(
            peer,
            false,
            &HashMap::new(),
            &authenticated,
        ));
        assert!(!gov5_direct_source_authorized(
            other,
            false,
            &routed,
            &authenticated,
        ));
    }

    #[test]
    fn block_direct_digest_cache_reuses_arc_without_retaining_it() {
        let mut cache = BlockDirectDigestCache::default();
        let data = Arc::new(vec![0x42; 4096]);

        let first = cache.transfer_id(&data);
        let second = cache.transfer_id(&data);

        assert_eq!(first, second);
        assert_eq!(Arc::strong_count(&data), 1, "cache must retain only a Weak");
        let cached = cache
            .last
            .as_ref()
            .and_then(|(weak, _)| weak.upgrade())
            .expect("live Arc remains cache-addressable");
        assert!(Arc::ptr_eq(&cached, &data));

        let replacement = Arc::new(vec![0x24; 4096]);
        assert_ne!(cache.transfer_id(&replacement), first);
        let cached = cache
            .last
            .as_ref()
            .and_then(|(weak, _)| weak.upgrade())
            .expect("replacement Arc remains cache-addressable");
        assert!(Arc::ptr_eq(&cached, &replacement));
    }

    /// Creates a test handle with both normal and priority channels.
    /// Returns (handle, normal_rx, priority_rx).
    fn test_handle() -> (
        NetworkHandle,
        mpsc::Receiver<NetworkCommand>,
        mpsc::Receiver<NetworkCommand>,
    ) {
        let (tx, rx) = mpsc::channel(8);
        let (ptx, prx) = mpsc::channel(8);
        (NetworkHandle::new(tx, ptx), rx, prx)
    }

    #[test]
    fn test_handle_announce_block() {
        let (handle, _rx, mut prx) = test_handle();
        handle.announce_block(vec![1, 2, 3]).unwrap();
        match prx.try_recv().unwrap() {
            NetworkCommand::AnnounceBlock(data) => assert_eq!(data, vec![1, 2, 3]),
            other => panic!("expected AnnounceBlock, got {other:?}"),
        }
    }

    #[tokio::test]
    async fn test_handle_cancel_gov5_block_fetch_uses_priority_lane() {
        let (handle, _rx, mut prx) = test_handle();
        let block_hash = B256::repeat_byte(0x42);

        handle
            .cancel_gov5_block_fetch_reliable(block_hash)
            .await
            .expect("fetch cancellation should queue");

        match prx.try_recv().expect("queued cancellation") {
            NetworkCommand::CancelGov5BlockFetch {
                block_hash: received,
            } => assert_eq!(received, block_hash),
            other => panic!("expected CancelGov5BlockFetch, got {other:?}"),
        }
    }

    #[test]
    fn fulfilled_gov5_block_suppresses_reordered_request_until_expiry() {
        let block_hash = B256::repeat_byte(0x43);
        let started = Instant::now();
        let mut fulfilled = HashMap::new();
        remember_gov5_block_fulfilled(&mut fulfilled, block_hash, started);

        assert!(gov5_block_fulfilled_recently(
            &mut fulfilled,
            block_hash,
            started + Duration::from_secs(29)
        ));
        assert!(!gov5_block_fulfilled_recently(
            &mut fulfilled,
            block_hash,
            started + Duration::from_secs(31)
        ));
        assert!(!fulfilled.contains_key(&block_hash));
    }

    #[test]
    fn test_handle_broadcast_transaction() {
        let (handle, mut rx, _prx) = test_handle();
        handle.broadcast_transaction(vec![0xAA, 0xBB]).unwrap();
        match rx.try_recv().unwrap() {
            NetworkCommand::BroadcastTransaction(data) => assert_eq!(data, vec![0xAA, 0xBB]),
            other => panic!("expected BroadcastTransaction, got {other:?}"),
        }
    }

    #[test]
    fn test_handle_dial() {
        let (handle, mut rx, _prx) = test_handle();
        let addr: Multiaddr = "/ip4/127.0.0.1/udp/9400/quic-v1".parse().unwrap();
        handle.dial(addr.clone()).unwrap();
        match rx.try_recv().unwrap() {
            NetworkCommand::Dial(a) => assert_eq!(a, addr),
            other => panic!("expected Dial, got {other:?}"),
        }
    }

    #[test]
    fn test_handle_channel_closed_returns_error() {
        let (handle, _rx, prx) = test_handle();
        drop(prx);
        let result = handle.announce_block(vec![1]);
        assert!(matches!(result.unwrap_err(), NetworkError::ChannelClosed));
    }

    #[test]
    fn test_handle_channel_full_returns_error() {
        let (handle, _rx, mut prx) = test_handle();
        for _ in 0..8 {
            handle.announce_block(vec![1]).unwrap();
        }
        let result = handle.announce_block(vec![2]);
        assert!(matches!(result.unwrap_err(), NetworkError::ChannelFull));
        while prx.try_recv().is_ok() {}
    }

    #[tokio::test]
    async fn test_reliable_priority_send_waits_for_capacity() {
        let (tx, _rx) = mpsc::channel(1);
        let (ptx, mut prx) = mpsc::channel(1);
        let handle = NetworkHandle::new(tx, ptx);

        handle.announce_block(vec![1]).unwrap();

        let drain = tokio::spawn(async move {
            tokio::time::sleep(Duration::from_millis(10)).await;
            let first = prx.recv().await.expect("first queued command");
            let second = prx.recv().await.expect("reliable queued command");
            (first, second)
        });

        handle
            .announce_block_reliable(vec![2, 3, 4])
            .await
            .expect("reliable send should wait for capacity");

        let (first, second) = drain.await.expect("drain task");
        match first {
            NetworkCommand::AnnounceBlock(data) => assert_eq!(data, vec![1]),
            other => panic!("expected first AnnounceBlock, got {other:?}"),
        }
        match second {
            NetworkCommand::AnnounceBlock(data) => assert_eq!(data, vec![2, 3, 4]),
            other => panic!("expected second AnnounceBlock, got {other:?}"),
        }
    }

    #[test]
    fn test_handle_validator_peer_map() {
        let (handle, _rx, _prx) = test_handle();
        assert!(handle.validator_peer(0).is_none());

        let peer = PeerId::random();
        handle.validator_peer_map.write().unwrap().insert(0, peer);
        assert_eq!(handle.validator_peer(0), Some(peer));
        assert!(handle.validator_peer(1).is_none());
    }

    #[test]
    fn sync_request_window_enforces_limit_and_resets() {
        let started_at = Instant::now();
        let mut window = SyncRequestWindow::new(started_at);

        for _ in 0..MAX_SYNC_REQUESTS_UNTRUSTED {
            assert!(window.allow(started_at, MAX_SYNC_REQUESTS_UNTRUSTED));
        }
        assert!(!window.allow(started_at, MAX_SYNC_REQUESTS_UNTRUSTED));
        assert!(window.allow(started_at + SYNC_RATE_WINDOW, MAX_SYNC_REQUESTS_UNTRUSTED));
    }

    #[test]
    fn validator_sync_window_has_explicit_higher_allowance() {
        let now = Instant::now();
        let mut validator = SyncRequestWindow::new(now);
        let mut untrusted = SyncRequestWindow::new(now);

        for _ in 0..MAX_SYNC_REQUESTS_UNTRUSTED {
            assert!(validator.allow(now, MAX_SYNC_REQUESTS_VALIDATOR));
            assert!(untrusted.allow(now, MAX_SYNC_REQUESTS_UNTRUSTED));
        }
        assert!(validator.allow(now, MAX_SYNC_REQUESTS_VALIDATOR));
        assert!(!untrusted.allow(now, MAX_SYNC_REQUESTS_UNTRUSTED));
    }

    #[test]
    fn gov5_range_quota_matches_four_batch_burst_and_steady_refill() {
        let now = Instant::now();
        let mut quota = Gov5RangeQuota::new(now);

        for _ in 0..4 {
            assert!(quota.allow(now, 1024));
        }
        assert!(!quota.allow(now, 1));
        assert!(quota.allow(now + Duration::from_secs(1), 1024));
        assert!(!quota.allow(now + Duration::from_secs(1), 1));
    }

    #[test]
    fn test_handle_register_peer() {
        let (handle, mut rx, _prx) = test_handle();
        let peer = PeerId::random();
        let addr: Multiaddr = "/ip4/10.0.0.1/udp/9400/quic-v1".parse().unwrap();
        handle.register_peer(peer, vec![addr], true).unwrap();
        match rx.try_recv().unwrap() {
            NetworkCommand::RegisterPeer {
                peer_id,
                addrs,
                trusted,
            } => {
                assert_eq!(peer_id, peer);
                assert_eq!(addrs.len(), 1);
                assert!(trusted);
            }
            other => panic!("expected RegisterPeer, got {other:?}"),
        }
    }

    #[test]
    fn test_handle_authenticate_validator_peer() {
        let (handle, mut rx, _prx) = test_handle();
        let peer = PeerId::random();
        handle.authenticate_validator_peer(peer, 7).unwrap();
        match rx.try_recv().unwrap() {
            NetworkCommand::AuthenticateValidatorPeer {
                peer_id,
                validator_index,
            } => {
                assert_eq!(peer_id, peer);
                assert_eq!(validator_index, 7);
            }
            other => panic!("expected AuthenticateValidatorPeer, got {other:?}"),
        }
    }

    #[test]
    fn test_handle_replace_expected_validator_peers() {
        let (handle, mut rx, _prx) = test_handle();
        let peer = PeerId::random();
        let mut peers = HashMap::new();
        peers.insert(7, peer);
        handle
            .replace_expected_validator_peers(peers.clone())
            .unwrap();
        match rx.try_recv().unwrap() {
            NetworkCommand::ReplaceExpectedValidatorPeers { peers: received } => {
                assert_eq!(received, peers);
            }
            other => panic!("expected ReplaceExpectedValidatorPeers, got {other:?}"),
        }
    }

    #[test]
    fn test_handle_request_sync() {
        let (handle, mut rx, _prx) = test_handle();
        let peer = PeerId::random();
        let request = BlockSyncRequest {
            from_view: 10,
            to_view: 20,
            local_committed_view: 5,
        };
        handle.request_sync(peer, request).unwrap();
        match rx.try_recv().unwrap() {
            NetworkCommand::RequestSync {
                peer: p,
                request: r,
            } => {
                assert_eq!(p, peer);
                assert_eq!(r.from_view, 10);
                assert_eq!(r.to_view, 20);
            }
            other => panic!("expected RequestSync, got {other:?}"),
        }
    }

    #[test]
    fn test_handle_broadcast_blob_sidecar() {
        let (handle, mut rx, _prx) = test_handle();
        handle.broadcast_blob_sidecar(vec![0xDE, 0xAD]).unwrap();
        match rx.try_recv().unwrap() {
            NetworkCommand::BroadcastBlobSidecar(data) => assert_eq!(data, vec![0xDE, 0xAD]),
            other => panic!("expected BroadcastBlobSidecar, got {other:?}"),
        }
    }

    #[test]
    fn test_handle_clone_shares_peer_map() {
        let (handle1, _rx, _prx) = test_handle();
        let handle2 = handle1.clone();
        let peer = PeerId::random();
        handle1.validator_peer_map.write().unwrap().insert(42, peer);
        assert_eq!(handle2.validator_peer(42), Some(peer));
    }

    #[test]
    fn test_block_direct_uses_priority_channel() {
        let (handle, _rx, mut prx) = test_handle();
        let peer = PeerId::random();
        handle.send_block_direct(peer, vec![0x42]).unwrap();
        match prx.try_recv().unwrap() {
            NetworkCommand::SendBlockDirect { peer: p, data } => {
                assert_eq!(p, peer);
                assert_eq!(data.as_slice(), &[0x42]);
            }
            other => panic!("expected SendBlockDirect, got {other:?}"),
        }
    }

    #[test]
    fn test_recent_block_announcement_dedup_drops_only_repeats() {
        let mut dedup = RecentBlockAnnouncementDedup::default();
        assert!(!dedup.observe(b"block-a"));
        assert!(dedup.observe(b"block-a"));
        assert!(!dedup.observe(b"block-b"));
        assert!(dedup.observe(b"block-b"));
    }

    #[test]
    fn gov5_block_fetch_uses_one_preferred_peer_per_attempt() {
        let preferred = PeerId::random();
        let advertised = PeerId::random();
        let rust_peer = PeerId::random();
        let connected = vec![preferred, advertised, rust_peer];

        let peers = gov5_block_fetch_fanout(preferred, Some(rust_peer), &[advertised], &connected);

        assert_eq!(peers, vec![preferred]);

        let rotated =
            gov5_block_fetch_fanout(preferred, Some(preferred), &[advertised], &connected);
        assert_eq!(rotated, vec![advertised]);
    }

    #[test]
    fn gov5_block_fetch_fanout_ignores_unconnected_preferred_peer() {
        let preferred = PeerId::random();
        let connected = vec![PeerId::random(), PeerId::random()];

        let peers = gov5_block_fetch_fanout(preferred, None, &[], &connected);

        assert!(!peers.contains(&preferred));
        assert_eq!(peers.len(), 1);
        assert!(connected.contains(&peers[0]));
    }

    #[test]
    fn stale_gov5_block_fetch_is_rearmed_after_transport_deadline() {
        let now = Instant::now();
        let stale_hash = B256::repeat_byte(0x41);
        let live_hash = B256::repeat_byte(0x42);
        let peer = PeerId::random();
        let pending = HashSet::from([stale_hash, live_hash]);
        let recent = HashMap::from([
            (stale_hash, (now - GOV5_BLOCK_REQUEST_STALE_AFTER, peer)),
            (
                live_hash,
                (
                    now - GOV5_BLOCK_REQUEST_STALE_AFTER + Duration::from_millis(1),
                    peer,
                ),
            ),
        ]);

        assert_eq!(
            stale_gov5_block_fetches(&pending, &recent, now),
            vec![stale_hash],
            "only a hash at or beyond the transport deadline may bypass pending de-duplication"
        );
    }

    #[test]
    fn h2_participant_block_lifecycle_uses_consensus_lane() {
        let source = PeerId::random();
        let block_hash = B256::repeat_byte(0x42);
        let events = [
            NetworkEvent::Gov5Block {
                source,
                rlp: vec![0xc0],
            },
            NetworkEvent::Gov5BlockFetched {
                source,
                requested_hash: block_hash,
                rlp: vec![0xc0],
            },
            NetworkEvent::Gov5BlockFetchFailed {
                source,
                block_hash,
                error: "deadline".to_owned(),
                permanent: false,
            },
        ];

        for event in &events {
            assert!(
                event_uses_consensus_lane(event, true),
                "participant execution event must not be starved in the data lane: {event:?}"
            );
            assert!(
                !event_uses_consensus_lane(event, false),
                "observer block handling must remain isolated from the consensus lane: {event:?}"
            );
        }
    }

    #[test]
    fn test_claimed_validator_index_parses_expected_format() {
        assert_eq!(claimed_validator_index("n42/1.0.0/v7"), Some(7));
        assert_eq!(claimed_validator_index("n42/1.0.0"), None);
        assert_eq!(claimed_validator_index("n42/1.0.0/vbad"), None);
    }

    #[test]
    fn test_deterministic_validator_peer_id_is_stable() {
        let peer_id = deterministic_validator_peer_id(3).expect("deterministic peer id");
        assert_eq!(
            deterministic_validator_peer_id(3).expect("repeat derivation"),
            peer_id
        );
        assert_ne!(
            deterministic_validator_peer_id(4).expect("different validator"),
            peer_id
        );
    }

    #[test]
    fn test_expected_peer_id_for_validator_uses_explicit_binding() {
        let peer_id = PeerId::random();
        let mut expected = HashMap::new();
        expected.insert(7, peer_id);

        assert_eq!(
            expected_peer_id_for_validator(&expected, 7, false).unwrap(),
            peer_id
        );
    }

    #[test]
    fn test_validator_index_for_expected_peer_requires_exact_noise_identity() {
        let expected_peer = PeerId::random();
        let mut expected = HashMap::new();
        expected.insert(7, expected_peer);

        assert_eq!(
            validator_index_for_expected_peer(&expected, expected_peer),
            Some(7)
        );
        assert_eq!(
            validator_index_for_expected_peer(&expected, PeerId::random()),
            None
        );
    }

    #[test]
    fn test_expected_peer_id_for_validator_respects_strict_policy() {
        let error = expected_peer_id_for_validator(&HashMap::new(), 3, false).unwrap_err();
        assert!(
            error
                .to_string()
                .contains("no configured expected peer id for validator index 3")
        );
    }

    #[test]
    fn test_expected_peer_id_for_validator_can_use_deterministic_fallback() {
        assert_eq!(
            expected_peer_id_for_validator(&HashMap::new(), 3, true).unwrap(),
            deterministic_validator_peer_id(3).unwrap()
        );
    }

    #[test]
    fn test_push_bounded_backlog_drops_newest_when_full() {
        let mut queue = VecDeque::from([1, 2]);

        push_bounded_backlog(&mut queue, 2, 3, "test");

        assert_eq!(queue, VecDeque::from([1, 2]));
    }
}
