use alloy_primitives::B256;
use futures::prelude::*;
use libp2p::StreamProtocol;
use libp2p::request_response;
use n42_primitives::consensus::QuorumCertificate;
use serde::{Deserialize, Serialize};
use std::io;

use crate::codec;

/// Maximum number of blocks that can be requested in a single sync request.
pub const MAX_BLOCKS_PER_SYNC_REQUEST: u64 = 128;

/// Block sync request: asks a peer for blocks in a view range.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct BlockSyncRequest {
    /// Start of the requested view range (inclusive).
    pub from_view: u64,
    /// End of the requested view range (inclusive).
    pub to_view: u64,
    /// Requester's committed view (for peer to gauge how far behind we are).
    pub local_committed_view: u64,
}

impl BlockSyncRequest {
    /// Validates the request range. Returns an error string if invalid.
    pub fn validate(&self) -> Result<(), String> {
        if self.from_view > self.to_view {
            return Err(format!(
                "invalid sync range: from_view ({}) > to_view ({})",
                self.from_view, self.to_view
            ));
        }
        // Inclusive range [from_view, to_view] contains (to_view - from_view + 1) views.
        let block_count = self.to_view - self.from_view + 1;
        if block_count > MAX_BLOCKS_PER_SYNC_REQUEST {
            return Err(format!(
                "sync range too large: {} blocks (max {})",
                block_count, MAX_BLOCKS_PER_SYNC_REQUEST
            ));
        }
        Ok(())
    }
}

/// Block sync response: contains committed blocks for the requested range.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct BlockSyncResponse {
    /// Blocks in view order.
    pub blocks: Vec<SyncBlock>,
    /// Peer's latest committed view.
    pub peer_committed_view: u64,
    /// Full block-data broadcasts for the execution lineage covered by the
    /// committed blocks above. This includes prepared ancestors which became
    /// canonical only when a descendant obtained a CommitQC. Keeping the raw
    /// broadcast preserves the cached execution output and sidecar StateDiff.
    pub execution_lineage: Vec<SyncPayload>,
}

/// A raw execution payload in a CommitQC-proven lineage.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct SyncPayload {
    pub view: u64,
    pub block_hash: B256,
    /// Bincode-encoded consensus `BlockDataBroadcast`.
    pub block_data: Vec<u8>,
}

/// A single committed block for sync purposes.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct SyncBlock {
    pub view: u64,
    pub block_hash: B256,
    pub commit_qc: QuorumCertificate,
    /// Serialized block payload (RLP or JSON encoded).
    pub payload: Vec<u8>,
    /// Validator changes committed with this block (if any).
    /// Needed so syncing nodes can reconstruct epoch transitions.
    #[serde(default)]
    pub validator_changes: Option<Vec<n42_primitives::consensus::ValidatorChange>>,
}

// ── libp2p request-response codec ──

/// Protocol identifier for block sync.
// `BlockSyncResponse` v2 carries the raw execution lineage required to recover
// prepared ancestors. Bincode is not self-describing, so mixed v1/v2 peers
// must negotiate different protocol IDs instead of mis-decoding the wire body.
pub const SYNC_PROTOCOL: &str = "/n42/sync/2";

/// Maximum sync message size (16 MB — supports batches of blocks).
pub const MAX_SYNC_MESSAGE_SIZE: usize = 16 * 1024 * 1024;

/// Codec for serializing/deserializing block sync messages.
#[derive(Clone, Debug, Default)]
pub struct StateSyncCodec;

impl request_response::Codec for StateSyncCodec {
    type Protocol = StreamProtocol;
    type Request = BlockSyncRequest;
    type Response = BlockSyncResponse;

    async fn read_request<T>(
        &mut self,
        _protocol: &Self::Protocol,
        io: &mut T,
    ) -> io::Result<Self::Request>
    where
        T: AsyncRead + Unpin + Send,
    {
        codec::read_length_prefixed(io, MAX_SYNC_MESSAGE_SIZE).await
    }

    async fn read_response<T>(
        &mut self,
        _protocol: &Self::Protocol,
        io: &mut T,
    ) -> io::Result<Self::Response>
    where
        T: AsyncRead + Unpin + Send,
    {
        codec::read_length_prefixed(io, MAX_SYNC_MESSAGE_SIZE).await
    }

    async fn write_request<T>(
        &mut self,
        _protocol: &Self::Protocol,
        io: &mut T,
        req: Self::Request,
    ) -> io::Result<()>
    where
        T: AsyncWrite + Unpin + Send,
    {
        codec::write_length_prefixed(io, &req, MAX_SYNC_MESSAGE_SIZE).await
    }

    async fn write_response<T>(
        &mut self,
        _protocol: &Self::Protocol,
        io: &mut T,
        res: Self::Response,
    ) -> io::Result<()>
    where
        T: AsyncWrite + Unpin + Send,
    {
        codec::write_length_prefixed(io, &res, MAX_SYNC_MESSAGE_SIZE).await
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use alloy_primitives::B256;
    use n42_primitives::consensus::QuorumCertificate;

    fn test_key(seed: u8) -> n42_primitives::BlsSecretKey {
        n42_primitives::BlsSecretKey::key_gen(&[seed; 32])
            .expect("deterministic test key should be valid")
    }

    fn sample_request() -> BlockSyncRequest {
        BlockSyncRequest {
            from_view: 10,
            to_view: 20,
            local_committed_view: 8,
        }
    }

    fn sample_sync_block() -> SyncBlock {
        let sk = test_key(0x11);
        let sig = sk.sign(b"test");
        SyncBlock {
            view: 15,
            block_hash: B256::repeat_byte(0xAA),
            commit_qc: QuorumCertificate {
                view: 15,
                block_hash: B256::repeat_byte(0xAA),
                aggregate_signature: sig,
                signers: Default::default(),
            },
            payload: vec![1, 2, 3, 4],
            validator_changes: None,
        }
    }

    fn sample_response() -> BlockSyncResponse {
        BlockSyncResponse {
            blocks: vec![sample_sync_block()],
            peer_committed_view: 25,
            execution_lineage: vec![SyncPayload {
                view: 15,
                block_hash: B256::repeat_byte(0xAA),
                block_data: vec![5, 6, 7],
            }],
        }
    }

    #[test]
    fn test_block_sync_request_serde_roundtrip() {
        let req = sample_request();
        let bytes = bincode::serialize(&req).unwrap();
        let decoded: BlockSyncRequest = bincode::deserialize(&bytes).unwrap();
        assert_eq!(decoded.from_view, req.from_view);
        assert_eq!(decoded.to_view, req.to_view);
        assert_eq!(decoded.local_committed_view, req.local_committed_view);
    }

    #[test]
    fn test_block_sync_response_serde_roundtrip() {
        let resp = sample_response();
        let bytes = bincode::serialize(&resp).unwrap();
        let decoded: BlockSyncResponse = bincode::deserialize(&bytes).unwrap();
        assert_eq!(decoded.blocks.len(), 1);
        assert_eq!(decoded.blocks[0].view, 15);
        assert_eq!(decoded.blocks[0].block_hash, B256::repeat_byte(0xAA));
        assert_eq!(decoded.blocks[0].payload, vec![1, 2, 3, 4]);
        assert_eq!(decoded.peer_committed_view, 25);
        assert_eq!(decoded.execution_lineage[0].block_data, vec![5, 6, 7]);
    }

    #[test]
    fn test_block_sync_response_empty_blocks() {
        let resp = BlockSyncResponse {
            blocks: vec![],
            peer_committed_view: 100,
            execution_lineage: Vec::new(),
        };
        let bytes = bincode::serialize(&resp).unwrap();
        let decoded: BlockSyncResponse = bincode::deserialize(&bytes).unwrap();
        assert!(decoded.blocks.is_empty());
        assert_eq!(decoded.peer_committed_view, 100);
    }

    #[test]
    fn test_block_sync_request_validate_accepts_inclusive_limit() {
        let req = BlockSyncRequest {
            from_view: 10,
            to_view: 10 + MAX_BLOCKS_PER_SYNC_REQUEST - 1,
            local_committed_view: 9,
        };

        assert!(req.validate().is_ok());
    }

    #[test]
    fn test_block_sync_request_validate_rejects_reverse_range() {
        let req = BlockSyncRequest {
            from_view: 20,
            to_view: 10,
            local_committed_view: 9,
        };

        let err = req.validate().unwrap_err();
        assert!(err.contains("from_view"));
        assert!(err.contains("to_view"));
    }

    #[test]
    fn test_block_sync_request_validate_rejects_oversized_range() {
        let req = BlockSyncRequest {
            from_view: 10,
            to_view: 10 + MAX_BLOCKS_PER_SYNC_REQUEST,
            local_committed_view: 9,
        };

        let err = req.validate().unwrap_err();
        assert!(err.contains("too large"));
        assert!(err.contains(&MAX_BLOCKS_PER_SYNC_REQUEST.to_string()));
    }

    #[tokio::test]
    async fn test_codec_write_read_request_roundtrip() {
        let req = sample_request();
        let mut buf = futures::io::Cursor::new(Vec::new());
        codec::write_length_prefixed(&mut buf, &req, MAX_SYNC_MESSAGE_SIZE)
            .await
            .unwrap();

        let data = buf.into_inner();
        let len = u32::from_be_bytes([data[0], data[1], data[2], data[3]]) as usize;
        assert_eq!(len, data.len() - 4);

        let mut reader = futures::io::Cursor::new(data);
        let decoded: BlockSyncRequest =
            codec::read_length_prefixed(&mut reader, MAX_SYNC_MESSAGE_SIZE)
                .await
                .unwrap();
        assert_eq!(decoded.from_view, req.from_view);
        assert_eq!(decoded.to_view, req.to_view);
        assert_eq!(decoded.local_committed_view, req.local_committed_view);
    }

    #[tokio::test]
    async fn test_codec_write_read_response_roundtrip() {
        let resp = sample_response();
        let mut buf = futures::io::Cursor::new(Vec::new());
        codec::write_length_prefixed(&mut buf, &resp, MAX_SYNC_MESSAGE_SIZE)
            .await
            .unwrap();

        let data = buf.into_inner();
        let mut reader = futures::io::Cursor::new(data);
        let decoded: BlockSyncResponse =
            codec::read_length_prefixed(&mut reader, MAX_SYNC_MESSAGE_SIZE)
                .await
                .unwrap();
        assert_eq!(decoded.blocks.len(), 1);
        assert_eq!(decoded.blocks[0].view, 15);
        assert_eq!(decoded.peer_committed_view, 25);
    }

    #[tokio::test]
    async fn test_codec_read_rejects_oversized() {
        let fake_len = (MAX_SYNC_MESSAGE_SIZE as u32 + 1).to_be_bytes();
        let mut data = Vec::new();
        data.extend_from_slice(&fake_len);
        data.extend_from_slice(&[0u8; 100]);

        let mut reader = futures::io::Cursor::new(data);
        let result: io::Result<BlockSyncRequest> =
            codec::read_length_prefixed(&mut reader, MAX_SYNC_MESSAGE_SIZE).await;
        assert!(result.is_err());
        assert_eq!(result.unwrap_err().kind(), io::ErrorKind::InvalidData);
    }
}
