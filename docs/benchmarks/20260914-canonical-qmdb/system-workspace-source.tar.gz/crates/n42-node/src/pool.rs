use reth_chainspec::EthereumHardforks;
use reth_evm::ConfigureEvm;
use reth_node_builder::{
    BuilderContext, PrimitivesTy,
    components::{PoolBuilder, TxPoolBuilder},
    node::{FullNodeTypes, NodeTypes},
};
use reth_tasks::{RayonConfig, RuntimeBuilder, RuntimeConfig, TokioConfig};
use reth_transaction_pool::{
    CoinbaseTipOrdering, EthPooledTransaction, EthTransactionValidator, PoolConfig, SubPoolLimit,
    TransactionValidationTaskExecutor, blobstore::DiskFileBlobStore,
};
use tracing::info;

const DEFAULT_POOL_MAX_TXS: usize = 100_000;
const DEFAULT_POOL_MAX_SIZE_BYTES: usize = 200 * 1024 * 1024;

fn configured_block_cap() -> Option<usize> {
    std::env::var("N42_MAX_TXS_PER_BLOCK")
        .ok()
        .and_then(|v| v.parse().ok())
        .filter(|cap| *cap > 0)
}

fn adaptive_pool_limit_txs() -> usize {
    std::env::var("N42_POOL_MAX_TXS")
        .ok()
        .and_then(|v| v.parse().ok())
        .filter(|cap| *cap > 0)
        .unwrap_or_else(|| {
            configured_block_cap()
                .map(|cap| DEFAULT_POOL_MAX_TXS.max(cap.saturating_mul(3)))
                .unwrap_or(DEFAULT_POOL_MAX_TXS)
        })
}

fn adaptive_pool_limit_size(max_txs: usize) -> usize {
    std::env::var("N42_POOL_MAX_SIZE_MB")
        .ok()
        .and_then(|v| v.parse::<usize>().ok())
        .filter(|mb| *mb > 0)
        .map(|mb| mb.saturating_mul(1024 * 1024))
        .unwrap_or_else(|| DEFAULT_POOL_MAX_SIZE_BYTES.max(max_txs.saturating_mul(2 * 1024)))
}

/// N42 transaction pool type — uses DiskFileBlobStore for EIP-4844 blob transaction support.
pub type N42TransactionPool<Provider, Evm> = reth_transaction_pool::Pool<
    TransactionValidationTaskExecutor<EthTransactionValidator<Provider, EthPooledTransaction, Evm>>,
    CoinbaseTipOrdering<EthPooledTransaction>,
    DiskFileBlobStore,
>;

/// IDC high-bandwidth transaction pool builder.
///
/// Differences from EthereumPoolBuilder:
/// - EIP-4844 blob transactions enabled (DiskFileBlobStore)
/// - Larger pending/basefee/queued limits for IDC throughput
/// - Higher per-account slot limit
#[derive(Debug, Default, Clone, Copy)]
#[non_exhaustive]
pub struct N42PoolBuilder;

impl<Types, Node, Evm> PoolBuilder<Node, Evm> for N42PoolBuilder
where
    Types: NodeTypes<
            ChainSpec: EthereumHardforks,
            Primitives: reth_primitives_traits::NodePrimitives<
                SignedTx = reth_ethereum_primitives::TransactionSigned,
            >,
        >,
    Node: FullNodeTypes<Types = Types>,
    Evm: ConfigureEvm<Primitives = PrimitivesTy<Types>> + Clone + 'static,
{
    type Pool = N42TransactionPool<Node::Provider, Evm>;

    async fn build_pool(
        self,
        ctx: &BuilderContext<Node>,
        evm_config: Evm,
    ) -> eyre::Result<Self::Pool> {
        let blob_store = reth_node_builder::components::create_blob_store(ctx)?;

        // Dedicated runtime for TX pool validation tasks.
        // Isolates ECDSA recovery + DB read CPU from consensus/GossipSub,
        // preventing R1_collect latency spikes under high TX load.
        let low_mem = std::env::var("N42_LOW_MEMORY")
            .map(|v| v == "1" || v.eq_ignore_ascii_case("true"))
            .unwrap_or(false);
        let default_threads: usize = if low_mem { 1 } else { 4 };
        let validation_threads: usize = std::env::var("N42_POOL_VALIDATION_THREADS")
            .ok()
            .and_then(|v| v.parse().ok())
            .unwrap_or(default_threads);

        // Leak the runtime so it lives as long as the process — avoids
        // "Cannot drop a runtime in a context where blocking is not allowed"
        // since build_pool() is async and Runtime::drop needs blocking.
        // RuntimeBuilder also owns three eager Rayon pools.  The validation
        // executor only uses the Tokio handle, so inheriting the machine-wide
        // defaults here used to create another cpu/rpc/storage set (525
        // threads on the 256-thread benchmark host) for every validator.
        let auxiliary_rayon = RayonConfig {
            cpu_threads: Some(1),
            reserved_cpu_cores: 0,
            rpc_threads: Some(1),
            storage_threads: Some(1),
            max_blocking_tasks: 1,
            proof_storage_worker_threads: Some(1),
            proof_account_worker_threads: Some(1),
            prewarming_threads: Some(1),
            bal_streaming_threads: Some(1),
            state_trie_overlay_worker_threads: Some(1),
        };
        let runtime_config = RuntimeConfig::default()
            .with_tokio(TokioConfig::Owned {
                worker_threads: Some(validation_threads),
                thread_keep_alive: std::time::Duration::from_secs(60),
                thread_name: "pool-val",
            })
            .with_rayon(auxiliary_rayon);
        let pool_runtime: &'static _ =
            Box::leak(Box::new(RuntimeBuilder::new(runtime_config).build()?));

        info!(
            target: "n42::pool",
            threads = validation_threads,
            auxiliary_rayon_threads = 3,
            "TX pool validation running on dedicated runtime"
        );

        let additional_tasks = ctx.config().txpool.additional_validation_tasks.max(16);
        let validator =
            TransactionValidationTaskExecutor::eth_builder(ctx.provider().clone(), evm_config)
                .with_local_transactions_config(ctx.pool_config().local_transactions_config.clone())
                .set_tx_fee_cap(ctx.config().rpc.rpc_tx_fee_cap)
                .with_max_tx_input_bytes(ctx.config().txpool.max_tx_input_bytes)
                .with_max_tx_gas_limit(ctx.config().txpool.max_tx_gas_limit)
                .with_minimum_priority_fee(ctx.config().txpool.minimum_priority_fee)
                .with_additional_tasks(additional_tasks)
                .build_with_tasks(pool_runtime.clone(), blob_store.clone());

        let pool_config = idc_pool_config(&ctx.pool_config());

        let pool = TxPoolBuilder::new(ctx)
            .with_validator(validator)
            .build_and_spawn_maintenance_task(blob_store, pool_config)?;

        Ok(pool)
    }
}

/// IDC-optimized pool configuration: higher limits for high-bandwidth, large-memory nodes.
///
/// With 2G gas limit and 2s slot, each block can hold ~95k txs.
/// Pool must buffer several blocks worth of txs during burst injection.
///
/// When `N42_LOW_MEMORY=1`, limits are reduced ~20× to save ~570 MB per node,
/// suitable for local multi-node testnets where memory is the bottleneck.
fn idc_pool_config(base: &PoolConfig) -> PoolConfig {
    let low_mem = std::env::var("N42_LOW_MEMORY")
        .map(|v| v == "1" || v.eq_ignore_ascii_case("true"))
        .unwrap_or(false);

    if low_mem {
        info!(target: "n42::pool", "LOW_MEMORY mode: pool limits reduced (5K txs, 10MB per subpool)");
        PoolConfig {
            pending_limit: SubPoolLimit {
                max_txs: 5_000,
                max_size: 10 * 1024 * 1024,
            },
            basefee_limit: SubPoolLimit {
                max_txs: 5_000,
                max_size: 10 * 1024 * 1024,
            },
            queued_limit: SubPoolLimit {
                max_txs: 5_000,
                max_size: 10 * 1024 * 1024,
            },
            blob_limit: SubPoolLimit {
                max_txs: 16,
                max_size: 4 * 1024 * 1024,
            },
            max_account_slots: 1_024,
            ..base.clone()
        }
    } else {
        let max_txs = adaptive_pool_limit_txs();
        let max_size = adaptive_pool_limit_size(max_txs);
        if max_txs != DEFAULT_POOL_MAX_TXS || max_size != DEFAULT_POOL_MAX_SIZE_BYTES {
            info!(
                target: "n42::pool",
                block_cap = configured_block_cap(),
                max_txs,
                max_size_mb = max_size / (1024 * 1024),
                "benchmark pool limits scaled for larger block cap"
            );
        }
        PoolConfig {
            pending_limit: SubPoolLimit { max_txs, max_size },
            basefee_limit: SubPoolLimit { max_txs, max_size },
            queued_limit: SubPoolLimit { max_txs, max_size },
            blob_limit: SubPoolLimit {
                max_txs: 256,
                max_size: 50 * 1024 * 1024,
            },
            max_account_slots: 16_384,
            ..base.clone()
        }
    }
}
