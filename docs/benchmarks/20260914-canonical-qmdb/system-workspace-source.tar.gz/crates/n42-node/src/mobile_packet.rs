use alloy_consensus::BlockHeader;
use alloy_eips::BlockHashOrNumber;
use alloy_primitives::{B256, Bytes};
use alloy_rlp::Encodable;
use bytes::BufMut;
use n42_execution::{N42EvmConfig, read_log::ReadLogDatabase};
use n42_mobile::code_cache::{CacheSyncMessage, encode_cache_sync};
use n42_mobile::packet::{StreamPacket, encode_stream_packet};
use n42_network::ShardedStarHubHandle;
use reth_chainspec::ChainSpec;
use reth_ethereum_primitives::EthPrimitives;
use reth_evm::{ConfigureEvm, execute::Executor};
use reth_primitives_traits::{BlockBody, NodePrimitives};
use reth_provider::BlockHashReader;
use reth_storage_api::{
    BlockNumReader, BlockReader, StateProviderBox, StateProviderFactory, TransactionVariant,
};
use std::collections::{HashMap, VecDeque};
use std::sync::{
    Arc,
    atomic::{AtomicBool, Ordering},
};
use tokio::sync::mpsc;
use tracing::{debug, info, warn};

use crate::mobile_bridge::DispatchedBlockRoot;

/// Errors that can occur during mobile packet generation.
#[derive(Debug, thiserror::Error)]
pub enum MobilePacketError {
    #[error("block not found: {0}")]
    BlockNotFound(B256),

    #[error("state provider error: {0}")]
    StateProvider(String),

    #[error("execution error: {0}")]
    Execution(String),

    #[error("compression error: {0}")]
    Compression(String),

    #[error("starhub error: {0}")]
    Hub(String),
}

/// A block commit notification: `(block_hash, consensus_view)`.
pub type BlockCommitNotification = (B256, u64);

/// Maximum number of previously-sent bytecodes to track for differential transmission.
/// At ~20 codes per block and 8-second slots, 2000 entries covers ~100 blocks (~13 min).
const MAX_PREVIOUSLY_SENT_CODES: usize = 2000;

fn packet_max_retries() -> u32 {
    std::env::var("N42_PACKET_MAX_RETRIES")
        .ok()
        .and_then(|s| s.parse::<u32>().ok())
        .unwrap_or(10)
}

fn packet_retry_base_ms() -> u64 {
    std::env::var("N42_PACKET_RETRY_BASE_MS")
        .ok()
        .and_then(|s| s.parse::<u64>().ok())
        .unwrap_or(200)
}

/// Insertion-order bounded code cache with FIFO eviction.
struct CodeCache {
    map: HashMap<B256, Bytes>,
    order: VecDeque<B256>,
    capacity: usize,
}

impl CodeCache {
    fn new(capacity: usize) -> Self {
        Self {
            map: HashMap::new(),
            order: VecDeque::new(),
            capacity,
        }
    }

    fn contains_key(&self, key: &B256) -> bool {
        self.map.contains_key(key)
    }

    fn insert(&mut self, key: B256, value: Bytes) {
        if self.map.contains_key(&key) {
            return;
        }
        self.map.insert(key, value);
        self.order.push_back(key);
        while self.map.len() > self.capacity {
            if let Some(old_key) = self.order.pop_front() {
                self.map.remove(&old_key);
            }
        }
    }

    fn is_empty(&self) -> bool {
        self.map.is_empty()
    }

    fn iter(&self) -> impl Iterator<Item = (&B256, &Bytes)> {
        self.map.iter()
    }
}

/// Runs the mobile packet generation loop (V2 stream format).
///
/// Uses `ReadLogDatabase` to capture ordered state reads during block execution,
/// then broadcasts a compact `StreamPacket`. Only new bytecodes are transmitted
/// (differential encoding against `previously_sent_codes`).
pub async fn mobile_packet_loop<P>(
    mut rx: mpsc::Receiver<BlockCommitNotification>,
    provider: P,
    chain_spec: Arc<ChainSpec>,
    hub_handle: ShardedStarHubHandle,
    sidecar_healthy: Arc<AtomicBool>,
    mut phone_connected_rx: mpsc::Receiver<u64>,
    dispatched_block_tx: Option<mpsc::Sender<DispatchedBlockRoot>>,
) where
    P: BlockReader<Block = <EthPrimitives as NodePrimitives>::Block>
        + StateProviderFactory
        + BlockHashReader
        + Clone
        + 'static,
{
    info!("mobile packet generation loop started (V2 stream format)");

    let evm_config = N42EvmConfig::new(chain_spec);
    let mut previously_sent_codes = CodeCache::new(MAX_PREVIOUSLY_SENT_CODES);
    let max_retries = packet_max_retries();
    let base_delay = std::time::Duration::from_millis(packet_retry_base_ms());

    loop {
        tokio::select! {
            commit = rx.recv() => {
                let Some((block_hash, _view)) = commit else { break };
                if !sidecar_healthy.load(Ordering::Acquire) {
                    metrics::counter!("n42_mobile_packet_suppressed_unhealthy_sidecar_total")
                        .increment(1);
                    warn!(
                        %block_hash,
                        "mobile packet suppressed while Twig sidecar is unhealthy"
                    );
                    continue;
                }
                debug!(%block_hash, "generating mobile stream packet");

                let mut last_err = None;
                for attempt in 0..max_retries {
                    if attempt > 0 {
                        tokio::time::sleep(base_delay * (1 << attempt.min(4))).await;
                        debug!(%block_hash, attempt, "retrying mobile packet generation");
                    }

                    match generate_and_broadcast_v2(
                        &provider,
                        &evm_config,
                        &hub_handle,
                        block_hash,
                        &mut previously_sent_codes,
                        dispatched_block_tx.as_ref(),
                    )
                    .await
                    {
                        Ok(packet_size) => {
                            if attempt > 0 {
                                info!(%block_hash, packet_size, attempt, "mobile stream packet broadcast (after retry)");
                            } else {
                                info!(%block_hash, packet_size, "mobile stream packet broadcast");
                            }
                            last_err = None;
                            break;
                        }
                        Err(e) => {
                            if matches!(e, MobilePacketError::BlockNotFound(_)) {
                                last_err = Some(e);
                                continue;
                            }
                            warn!(%block_hash, error = %e, "failed to generate mobile packet (non-retryable)");
                            last_err = None;
                            break;
                        }
                    }
                }

                if let Some(e) = last_err {
                    warn!(%block_hash, error = %e, max_retries, "failed to generate mobile packet after all retries");
                }
            }

            Some(session_id) = phone_connected_rx.recv() => {
                if !sidecar_healthy.load(Ordering::Acquire) {
                    metrics::counter!("n42_mobile_cache_sync_suppressed_unhealthy_sidecar_total")
                        .increment(1);
                    warn!(session_id, "mobile cache sync suppressed while Twig sidecar is unhealthy");
                    continue;
                }
                if previously_sent_codes.is_empty() {
                    continue;
                }
                let msg = CacheSyncMessage {
                    codes: previously_sent_codes.iter().map(|(h, c)| (*h, c.clone())).collect(),
                    evict_hints: vec![],
                };
                let data = encode_cache_sync(&msg);
                let code_count = msg.codes.len();
                let raw_len = data.len();
                let (compressed, msg_type) = match zstd::bulk::compress(&data, 3) {
                    Ok(c) => (c, n42_network::MSG_TYPE_CACHE_SYNC_ZSTD),
                    Err(e) => {
                        warn!(error = %e, "zstd compression failed for cache sync, sending uncompressed");
                        (data, n42_network::MSG_TYPE_CACHE_SYNC)
                    }
                };
                let compressed_len = compressed.len();
                let mut framed = bytes::BytesMut::with_capacity(1 + compressed.len());
                framed.put_u8(msg_type);
                framed.extend_from_slice(&compressed);
                if let Err(e) = hub_handle.send_to_session(session_id, framed.freeze()).await {
                    warn!(error = %e, session_id, "failed to send cache sync to new phone");
                } else {
                    info!(
                        codes = code_count,
                        raw_bytes = raw_len,
                        compressed_bytes = compressed_len,
                        session_id,
                        "sent targeted cache sync to new phone (V2 format)"
                    );
                }
            }
        }
    }

    info!("mobile packet generation loop stopped (channel closed)");
}

/// Which state a witness was generated against.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum WitnessStateSource {
    /// The parent is the canonical head: the tip state provider serves reads
    /// from the in-memory overlay without per-key history lookups.
    Tip,
    /// Any other parent: the historical provider at that block.
    Historical,
}

impl WitnessStateSource {
    const fn label(self) -> &'static str {
        match self {
            Self::Tip => "tip",
            Self::Historical => "historical",
        }
    }
}

fn canonical_head<P>(provider: &P) -> Option<(u64, B256)>
where
    P: BlockNumReader + BlockHashReader,
{
    let number = provider.best_block_number().ok()?;
    let hash = provider.block_hash(number).ok()??;
    Some((number, hash))
}

/// Whether `state` is exactly the state after `parent_hash` at
/// `parent_number`: it knows the parent under that number and nothing after
/// it. Asked of the state provider itself, so the answer cannot lag it.
fn state_is_at(state: &StateProviderBox, parent_number: u64, parent_hash: B256) -> bool {
    let at_parent =
        matches!(state.block_hash(parent_number), Ok(Some(hash)) if hash == parent_hash);
    let nothing_after = matches!(
        parent_number
            .checked_add(1)
            .map(|next| state.block_hash(next)),
        Some(Ok(None))
    );
    at_parent && nothing_after
}

/// Pick the parent state a witness executes against.
///
/// When `parent_hash` is the canonical head, `latest()` is the same state as
/// `history_by_block_hash(parent_hash)` but skips the block-number lookup,
/// the canonical check and the historical overlay setup.
///
/// The head check alone is not enough: `best_block_number()` reads the chain
/// info tracker while `latest()` reads the in-memory block map, and the
/// engine updates the map before the tracker, so for a moment the tracker
/// still names the parent while `latest()` already includes its child (and
/// re-reading the tracker afterwards would still name the parent). The state
/// provider is therefore asked which blocks it knows; the historical path is
/// used unless it knows the parent and nothing after it.
fn parent_state_provider<P>(
    provider: &P,
    parent_hash: B256,
) -> Result<(StateProviderBox, WitnessStateSource), MobilePacketError>
where
    P: StateProviderFactory + BlockNumReader + BlockHashReader,
{
    if let Some((parent_number, head_hash)) = canonical_head(provider)
        && head_hash == parent_hash
    {
        let latest = provider
            .latest()
            .map_err(|e| MobilePacketError::StateProvider(e.to_string()))?;
        if state_is_at(&latest, parent_number, parent_hash) {
            metrics::counter!("n42_mobile_witness_state_source_total", "source" => "tip")
                .increment(1);
            return Ok((latest, WitnessStateSource::Tip));
        }
        metrics::counter!("n42_mobile_witness_state_source_total", "source" => "tip_moved")
            .increment(1);
    }
    let state = provider
        .history_by_block_hash(parent_hash)
        .map_err(|e| MobilePacketError::StateProvider(e.to_string()))?;
    metrics::counter!("n42_mobile_witness_state_source_total", "source" => "historical")
        .increment(1);
    Ok((state, WitnessStateSource::Historical))
}

/// Generates a V2 stream packet and broadcasts it.
///
/// Flow: fetch block → get parent state → wrap with ReadLogDatabase → execute
/// → extract read log + bytecodes → differential filter → encode → zstd → broadcast.
async fn generate_and_broadcast_v2<P>(
    provider: &P,
    evm_config: &N42EvmConfig,
    hub_handle: &ShardedStarHubHandle,
    block_hash: B256,
    previously_sent_codes: &mut CodeCache,
    dispatched_block_tx: Option<&mpsc::Sender<DispatchedBlockRoot>>,
) -> Result<usize, MobilePacketError>
where
    P: BlockReader<Block = <EthPrimitives as NodePrimitives>::Block>
        + StateProviderFactory
        + BlockHashReader
        + 'static,
{
    let (compressed, packet_size, all_codes, block_number, receipts_root) = {
        let recovered_block = provider
            .recovered_block(
                BlockHashOrNumber::Hash(block_hash),
                TransactionVariant::WithHash,
            )
            .map_err(|e| MobilePacketError::StateProvider(e.to_string()))?
            .ok_or(MobilePacketError::BlockNotFound(block_hash))?;

        let parent_hash = recovered_block.header().parent_hash();
        let (state_provider, state_source) = parent_state_provider(provider, parent_hash)?;

        let inner_db = reth_revm::database::StateProviderDatabase::new(&state_provider);
        let logged_db = ReadLogDatabase::new(inner_db);
        let log_handle = logged_db.log_handle();
        let codes_handle = logged_db.codes_handle();

        let mut executor = evm_config.executor(logged_db);
        let _output = executor
            .execute_one(&recovered_block)
            .map_err(|e| MobilePacketError::Execution(e.to_string()))?;

        let read_log = match Arc::try_unwrap(log_handle) {
            Ok(mutex) => mutex.into_inner().unwrap_or_else(|e| {
                tracing::warn!("read_log mutex poisoned, recovering");
                e.into_inner()
            }),
            Err(arc) => arc
                .lock()
                .unwrap_or_else(|e| {
                    tracing::warn!("read_log mutex poisoned, recovering");
                    e.into_inner()
                })
                .clone(),
        };
        let read_log_count = read_log.len();
        let read_log_data = n42_execution::read_log::encode_read_log(&read_log);

        let captured_codes = match Arc::try_unwrap(codes_handle) {
            Ok(mutex) => mutex.into_inner().unwrap_or_else(|e| {
                tracing::warn!("read_log mutex poisoned, recovering");
                e.into_inner()
            }),
            Err(arc) => arc
                .lock()
                .unwrap_or_else(|e| {
                    tracing::warn!("read_log mutex poisoned, recovering");
                    e.into_inner()
                })
                .clone(),
        };

        let header = recovered_block.header();
        let block_number = header.number();
        let receipts_root = header.receipts_root();
        let mut header_buf = Vec::new();
        header.encode(&mut header_buf);
        let transactions = recovered_block.body().encoded_2718_transactions();

        let all_codes: Vec<(B256, Bytes)> = captured_codes.into_iter().collect();
        let total_codes = all_codes.len();
        let new_codes: Vec<(B256, Bytes)> = all_codes
            .iter()
            .filter(|(hash, _)| !previously_sent_codes.contains_key(hash))
            .cloned()
            .collect();
        let filtered_codes = total_codes - new_codes.len();

        let packet = StreamPacket {
            block_hash,
            header_rlp: Bytes::from(header_buf),
            transactions,
            read_log_data,
            bytecodes: new_codes,
        };

        debug!(
            block_number,
            state_source = state_source.label(),
            read_log_entries = read_log_count,
            read_log_bytes = packet.read_log_data.len(),
            bytecodes = packet.bytecodes.len(),
            filtered_codes,
            total_codes,
            txs = packet.transactions.len(),
            estimated_size = packet.estimated_size(),
            "stream packet built (V2 differential)"
        );

        let encoded = encode_stream_packet(&packet);
        let raw_size = encoded.len();
        let compressed = zstd::bulk::compress(&encoded, 3)
            .map_err(|e| MobilePacketError::Compression(e.to_string()))?;
        let packet_size = compressed.len();
        debug!(
            block_number,
            raw_size,
            compressed_size = packet_size,
            "stream packet compressed"
        );

        (
            bytes::Bytes::from(compressed),
            packet_size,
            all_codes,
            block_number,
            receipts_root,
        )
    };

    if let Some(tx) = dispatched_block_tx {
        let notification = DispatchedBlockRoot {
            block_hash,
            block_number,
            receipts_root,
        };
        match tx.try_send(notification) {
            Ok(()) => {
                debug!(
                    block_number,
                    %block_hash,
                    %receipts_root,
                    "registered mobile packet root before broadcast"
                );
            }
            Err(tokio::sync::mpsc::error::TrySendError::Full(notification)) => {
                warn!(
                    block_number,
                    %block_hash,
                    "mobile packet root channel full, waiting before broadcast"
                );
                if let Err(error) = tx.send(notification).await {
                    warn!(
                        block_number,
                        %block_hash,
                        error = %error,
                        "failed to register mobile packet root before broadcast"
                    );
                }
            }
            Err(tokio::sync::mpsc::error::TrySendError::Closed(_)) => {
                warn!(
                    block_number,
                    %block_hash,
                    "mobile packet root channel closed before broadcast"
                );
            }
        }
    }

    hub_handle
        .broadcast_packet(compressed)
        .await
        .map_err(|e| MobilePacketError::Hub(e.to_string()))?;

    for (hash, code) in all_codes {
        previously_sent_codes.insert(hash, code);
    }

    Ok(packet_size)
}

#[cfg(test)]
mod tests {
    use super::*;
    use alloy_primitives::{B256, Bytes};

    #[test]
    fn witness_state_source_uses_the_tip_only_for_the_canonical_head() {
        use metrics_util::debugging::{DebugValue, DebuggingRecorder};
        use reth_provider::test_utils::MockEthProvider;

        let recorder = DebuggingRecorder::new();
        let snapshotter = recorder.snapshotter();
        let _guard = metrics::set_default_local_recorder(&recorder);

        let provider = MockEthProvider::default();
        let older = B256::repeat_byte(0x11);
        let head = B256::repeat_byte(0x22);
        for (number, hash) in [(6u64, older), (7, head)] {
            provider.add_block(
                hash,
                reth_ethereum_primitives::Block {
                    header: alloy_consensus::Header {
                        number,
                        ..Default::default()
                    },
                    body: Default::default(),
                },
            );
        }
        assert_eq!(canonical_head(&provider), Some((7, head)));

        let (_, source) = parent_state_provider(&provider, head).unwrap();
        assert_eq!(source, WitnessStateSource::Tip);
        let (_, source) = parent_state_provider(&provider, older).unwrap();
        assert_eq!(source, WitnessStateSource::Historical);
        let (_, source) = parent_state_provider(&provider, B256::repeat_byte(0x33)).unwrap();
        assert_eq!(source, WitnessStateSource::Historical);

        let counts: HashMap<String, u64> = snapshotter
            .snapshot()
            .into_vec()
            .into_iter()
            .filter(|(key, _, _, _)| key.key().name() == "n42_mobile_witness_state_source_total")
            .map(|(key, _, _, value)| {
                let source = key
                    .key()
                    .labels()
                    .find(|label| label.key() == "source")
                    .map(|label| label.value().to_string())
                    .unwrap();
                let DebugValue::Counter(count) = value else {
                    panic!("counter expected");
                };
                (source, count)
            })
            .collect();
        assert_eq!(counts.get("tip"), Some(&1));
        assert_eq!(counts.get("historical"), Some(&2));
    }

    /// The engine updates the in-memory block map before the chain info
    /// tracker, so `best_block_number()` can still name the parent while
    /// `latest()` already carries its child. That window must take the
    /// historical path: a witness against the child's state is wrong.
    #[test]
    fn witness_state_source_falls_back_when_the_tip_state_is_ahead_of_the_head() {
        use alloy_eips::{BlockNumHash, BlockNumberOrTag};
        use reth_provider::test_utils::MockEthProvider;
        use reth_storage_api::{BlockIdReader, StateProviderBox};

        /// `head` answers the chain-info questions, `tip` serves `latest()`.
        struct LaggingHead {
            head: MockEthProvider,
            tip: MockEthProvider,
        }

        impl BlockHashReader for LaggingHead {
            fn block_hash(&self, number: u64) -> reth_provider::ProviderResult<Option<B256>> {
                self.head.block_hash(number)
            }
            fn canonical_hashes_range(
                &self,
                start: u64,
                end: u64,
            ) -> reth_provider::ProviderResult<Vec<B256>> {
                self.head.canonical_hashes_range(start, end)
            }
        }

        impl BlockNumReader for LaggingHead {
            fn chain_info(&self) -> reth_provider::ProviderResult<reth_chainspec::ChainInfo> {
                self.head.chain_info()
            }
            fn best_block_number(&self) -> reth_provider::ProviderResult<u64> {
                self.head.best_block_number()
            }
            fn last_block_number(&self) -> reth_provider::ProviderResult<u64> {
                self.head.last_block_number()
            }
            fn block_number(&self, hash: B256) -> reth_provider::ProviderResult<Option<u64>> {
                self.head.block_number(hash)
            }
        }

        impl BlockIdReader for LaggingHead {
            fn pending_block_num_hash(
                &self,
            ) -> reth_provider::ProviderResult<Option<BlockNumHash>> {
                self.head.pending_block_num_hash()
            }
            fn safe_block_num_hash(&self) -> reth_provider::ProviderResult<Option<BlockNumHash>> {
                self.head.safe_block_num_hash()
            }
            fn finalized_block_num_hash(
                &self,
            ) -> reth_provider::ProviderResult<Option<BlockNumHash>> {
                self.head.finalized_block_num_hash()
            }
        }

        impl StateProviderFactory for LaggingHead {
            fn latest(&self) -> reth_provider::ProviderResult<StateProviderBox> {
                self.tip.latest()
            }
            fn state_by_block_number_or_tag(
                &self,
                number_or_tag: BlockNumberOrTag,
            ) -> reth_provider::ProviderResult<StateProviderBox> {
                self.head.state_by_block_number_or_tag(number_or_tag)
            }
            fn history_by_block_number(
                &self,
                block: u64,
            ) -> reth_provider::ProviderResult<StateProviderBox> {
                self.head.history_by_block_number(block)
            }
            fn history_by_block_hash(
                &self,
                block: B256,
            ) -> reth_provider::ProviderResult<StateProviderBox> {
                self.head.history_by_block_hash(block)
            }
            fn state_by_block_hash(
                &self,
                block: B256,
            ) -> reth_provider::ProviderResult<StateProviderBox> {
                self.head.state_by_block_hash(block)
            }
            fn pending(&self) -> reth_provider::ProviderResult<StateProviderBox> {
                self.head.pending()
            }
            fn pending_state_by_hash(
                &self,
                block_hash: B256,
            ) -> reth_provider::ProviderResult<Option<StateProviderBox>> {
                self.head.pending_state_by_hash(block_hash)
            }
            fn maybe_pending(&self) -> reth_provider::ProviderResult<Option<StateProviderBox>> {
                self.head.maybe_pending()
            }
        }

        let parent = B256::repeat_byte(0x22);
        let child = B256::repeat_byte(0x33);
        let block = |number: u64| reth_ethereum_primitives::Block {
            header: alloy_consensus::Header {
                number,
                ..Default::default()
            },
            body: Default::default(),
        };
        let head = MockEthProvider::default();
        head.add_block(parent, block(7));
        let tip = MockEthProvider::default();
        tip.add_block(parent, block(7));
        tip.add_block(child, block(8));
        let provider = LaggingHead { head, tip };
        assert_eq!(canonical_head(&provider), Some((7, parent)));

        let (state, source) = parent_state_provider(&provider, parent).unwrap();
        assert_eq!(source, WitnessStateSource::Historical);
        assert_eq!(state.block_hash(8).unwrap(), None);

        // Once the tracker catches up the tip state is used again.
        provider.head.add_block(child, block(8));
        let (_, source) = parent_state_provider(&provider, child).unwrap();
        assert_eq!(source, WitnessStateSource::Tip);
    }

    #[test]
    fn test_code_cache_insert_and_contains() {
        let mut cache = CodeCache::new(10);
        let hash = B256::repeat_byte(0xAA);
        let code = Bytes::from(vec![0x60, 0x00]);

        assert!(!cache.contains_key(&hash));
        assert!(cache.is_empty());

        cache.insert(hash, code);
        assert!(cache.contains_key(&hash));
        assert!(!cache.is_empty());
    }

    #[test]
    fn test_code_cache_duplicate_insert_noop() {
        let mut cache = CodeCache::new(10);
        let hash = B256::repeat_byte(0xBB);
        let code = Bytes::from(vec![0x60, 0x01]);

        cache.insert(hash, code.clone());
        cache.insert(hash, code);

        assert_eq!(cache.order.len(), 1);
        assert_eq!(cache.map.len(), 1);
    }

    #[test]
    fn test_code_cache_fifo_eviction() {
        let mut cache = CodeCache::new(3);

        let h1 = B256::repeat_byte(0x01);
        let h2 = B256::repeat_byte(0x02);
        let h3 = B256::repeat_byte(0x03);
        let h4 = B256::repeat_byte(0x04);

        cache.insert(h1, Bytes::from(vec![1]));
        cache.insert(h2, Bytes::from(vec![2]));
        cache.insert(h3, Bytes::from(vec![3]));
        assert_eq!(cache.map.len(), 3);

        cache.insert(h4, Bytes::from(vec![4]));
        assert_eq!(cache.map.len(), 3);
        assert!(!cache.contains_key(&h1), "oldest entry should be evicted");
        assert!(cache.contains_key(&h2));
        assert!(cache.contains_key(&h3));
        assert!(cache.contains_key(&h4));
    }

    #[test]
    fn test_code_cache_iter() {
        let mut cache = CodeCache::new(10);
        cache.insert(B256::repeat_byte(0x01), Bytes::from(vec![1]));
        cache.insert(B256::repeat_byte(0x02), Bytes::from(vec![2]));

        assert_eq!(cache.iter().count(), 2);
    }

    #[test]
    fn test_code_cache_zero_capacity() {
        let mut cache = CodeCache::new(0);
        cache.insert(B256::repeat_byte(0xFF), Bytes::from(vec![0xFF]));
        assert!(cache.is_empty(), "capacity 0 should keep nothing");
    }

    #[test]
    fn test_code_cache_capacity_one() {
        let mut cache = CodeCache::new(1);
        let h1 = B256::repeat_byte(0x01);
        let h2 = B256::repeat_byte(0x02);

        cache.insert(h1, Bytes::from(vec![1]));
        cache.insert(h2, Bytes::from(vec![2]));
        assert!(!cache.contains_key(&h1), "h1 should be evicted");
        assert!(cache.contains_key(&h2));
        assert_eq!(cache.map.len(), 1);
    }

    #[test]
    fn test_packet_retry_defaults() {
        assert_eq!(packet_max_retries(), 10);
        assert_eq!(packet_retry_base_ms(), 200);
    }

    #[test]
    fn test_zstd_roundtrip() {
        let data = vec![0xABu8; 10_000];
        let compressed = zstd::bulk::compress(&data, 3).unwrap();
        assert!(compressed.len() < data.len());
        let decompressed = zstd::bulk::decompress(&compressed, 16 * 1024 * 1024).unwrap();
        assert_eq!(decompressed, data);
    }

    #[test]
    fn test_zstd_witness_like_data_compresses_well() {
        let mut data = Vec::new();
        for _ in 0..100 {
            data.extend_from_slice(&[0x00; 20]);
            data.extend_from_slice(&[0x00; 32]);
            data.extend_from_slice(&[0xAB; 32]);
        }
        let compressed = zstd::bulk::compress(&data, 3).unwrap();
        assert!(
            compressed.len() * 2 < data.len(),
            "should achieve >50% compression"
        );
    }
}
