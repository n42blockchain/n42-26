//! JMT snapshot persistence.
//!
//! Provides file-based snapshots for the ShardedJmt. Since the jmt crate's
//! internal Node/NodeKey types don't support serde, we take a value-level
//! approach: dump all live key-value pairs and version, then reconstruct
//! the tree from scratch on restore.
//!
//! Snapshots are written atomically (write to temp file + rename) and
//! compressed with zstd for compact storage.

use crate::sharded::{SHARD_COUNT, ShardedJmt};
use crate::store::{MemTreeStore, TreeStore};
use crate::tree::N42JmtTree;
use alloy_primitives::hex;
use jmt::KeyHash;
use parking_lot::Mutex;
use std::path::Path;
use std::sync::Arc;
use tracing::info;

/// Makes a file's directory entry durable after creation or atomic replacement.
/// On Unix an error must stop checkpointing before the covered WAL is truncated.
/// Other platforms retain their existing file-sync/rename durability semantics.
pub fn sync_parent_directory(path: &Path) -> std::io::Result<()> {
    #[cfg(unix)]
    {
        // A bare relative filename has an empty parent, meaning the current directory.
        let parent = path
            .parent()
            .filter(|p| !p.as_os_str().is_empty())
            .unwrap_or(Path::new("."));
        std::fs::File::open(parent)?.sync_all()?;
    }
    #[cfg(not(unix))]
    let _ = path;
    Ok(())
}

pub(crate) fn write_snapshot_bytes(path: &Path, bytes: &[u8]) -> std::io::Result<()> {
    write_snapshot_bytes_with_sync(path, bytes, sync_parent_directory)
}

fn write_snapshot_bytes_with_sync(
    path: &Path,
    bytes: &[u8],
    sync_directory: impl FnOnce(&Path) -> std::io::Result<()>,
) -> std::io::Result<()> {
    use std::io::Write;
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let tmp_path = path.with_extension("tmp");
    {
        let mut file = std::fs::File::create(&tmp_path)?;
        file.write_all(bytes)?;
        file.sync_all()?;
    }
    std::fs::rename(&tmp_path, path)?;
    sync_directory(path)
}

/// Serializable snapshot of a ShardedJmt's state.
#[derive(serde::Serialize, serde::Deserialize)]
pub struct JmtSnapshot {
    /// JMT version at the time of snapshot.
    pub version: u64,
    /// Combined root hash bytes.
    pub root: [u8; 32],
    /// All live key-value pairs: `(KeyHash bytes, value bytes)`.
    pub entries: Vec<([u8; 32], Vec<u8>)>,
}

impl JmtSnapshot {
    /// Number of entries in the snapshot.
    pub fn len(&self) -> usize {
        self.entries.len()
    }

    /// Whether the snapshot is empty.
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }
}

impl<S: TreeStore> ShardedJmt<S> {
    /// Create a snapshot of the current JMT state.
    ///
    /// Collects all live key-value pairs from all 16 shards.
    pub fn snapshot(&self) -> eyre::Result<JmtSnapshot> {
        let root = self.root_hash()?;
        let mut entries = Vec::new();
        for shard in self.shards() {
            let tree = shard.lock();
            let store = tree.store();
            entries.extend(store.dump_latest());
        }
        Ok(JmtSnapshot {
            version: self.version(),
            root: root.0,
            entries,
        })
    }
}

impl ShardedJmt<MemTreeStore> {
    /// Reconstruct a ShardedJmt from a snapshot.
    ///
    /// Creates a new tree with 16 shards, distributes all entries by shard index,
    /// and applies them as a single batch per shard. The restored tree will have
    /// the same combined root hash as the original.
    pub fn from_snapshot(snapshot: JmtSnapshot) -> eyre::Result<Self> {
        let start = std::time::Instant::now();

        // Partition entries by shard.
        let mut shard_entries: Vec<Vec<(KeyHash, Option<Vec<u8>>)>> =
            (0..SHARD_COUNT).map(|_| Vec::new()).collect();

        for (key_bytes, value) in &snapshot.entries {
            let key = KeyHash(*key_bytes);
            let idx = n42_bmt_core::shard_index_for_key(&key.0);
            shard_entries[idx].push((key, Some(value.clone())));
        }

        // Build each shard.
        let shards: Vec<Mutex<N42JmtTree>> = shard_entries
            .into_iter()
            .map(|entries| {
                let mut tree = N42JmtTree::with_store(Arc::new(MemTreeStore::new()));
                if !entries.is_empty() {
                    tree.apply_batch(entries).map_err(|error| {
                        eyre::eyre!("failed to apply snapshot entries to shard: {error}")
                    })?;
                }
                Ok(Mutex::new(tree))
            })
            .collect::<eyre::Result<_>>()?;

        let jmt = ShardedJmt::from_parts(shards, snapshot.version);
        let restored_root = jmt.root_hash()?;
        if restored_root.0 != snapshot.root {
            return Err(eyre::eyre!(
                "restored snapshot root mismatch: expected 0x{}, got 0x{}",
                hex::encode(snapshot.root),
                hex::encode(restored_root.0),
            ));
        }
        let elapsed_ms = start.elapsed().as_millis();
        info!(
            target: "n42::jmt",
            version = snapshot.version,
            entries = snapshot.entries.len(),
            elapsed_ms,
            "JMT restored from snapshot"
        );
        Ok(jmt)
    }
}

/// Save a JMT snapshot to a file (bincode + zstd compressed).
///
/// Writes atomically: temp file → rename.
pub fn save_snapshot(path: &Path, snapshot: &JmtSnapshot) -> eyre::Result<()> {
    let start = std::time::Instant::now();

    let raw = bincode::serialize(snapshot)?;
    let compressed = zstd::bulk::compress(&raw, 3)?;

    write_snapshot_bytes(path, &compressed)?;

    let elapsed_ms = start.elapsed().as_millis();
    info!(
        target: "n42::jmt",
        version = snapshot.version,
        entries = snapshot.entries.len(),
        raw_kb = raw.len() / 1024,
        compressed_kb = compressed.len() / 1024,
        elapsed_ms,
        path = %path.display(),
        "JMT snapshot saved"
    );
    Ok(())
}

/// Load a JMT snapshot from a file.
///
/// Returns `None` if the file doesn't exist.
pub fn load_snapshot(path: &Path) -> eyre::Result<Option<JmtSnapshot>> {
    if !path.exists() {
        return Ok(None);
    }

    let start = std::time::Instant::now();
    let compressed = std::fs::read(path)?;
    let raw = zstd::bulk::decompress(&compressed, 256 * 1024 * 1024)?; // 256 MB max
    let snapshot: JmtSnapshot = bincode::deserialize(&raw)?;
    let elapsed_ms = start.elapsed().as_millis();

    info!(
        target: "n42::jmt",
        version = snapshot.version,
        entries = snapshot.entries.len(),
        elapsed_ms,
        path = %path.display(),
        "JMT snapshot loaded"
    );
    Ok(Some(snapshot))
}

#[cfg(test)]
mod tests {
    use super::*;
    use alloy_primitives::{Address, U256};
    use n42_execution::state_diff::{AccountChangeType, AccountDiff, StateDiff, ValueChange};
    use std::collections::BTreeMap;

    #[test]
    fn snapshot_directory_sync_failure_is_not_reported_as_success() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("snapshot");
        let error = write_snapshot_bytes_with_sync(&path, b"snapshot", |renamed| {
            assert_eq!(std::fs::read(renamed).unwrap(), b"snapshot");
            Err(std::io::Error::other("injected directory sync failure"))
        })
        .unwrap_err();
        assert!(
            error
                .to_string()
                .contains("injected directory sync failure")
        );
    }

    #[cfg(unix)]
    #[test]
    fn directory_sync_propagates_open_failure_and_accepts_relative_filenames() {
        let dir = tempfile::tempdir().unwrap();
        assert!(sync_parent_directory(&dir.path().join("missing/snapshot")).is_err());
        sync_parent_directory(Path::new("snapshot")).unwrap();
    }

    fn make_diff(n: usize) -> StateDiff {
        let mut accounts = BTreeMap::new();
        for i in 0..n {
            accounts.insert(
                Address::with_last_byte(i as u8),
                AccountDiff {
                    change_type: AccountChangeType::Created,
                    balance: Some(ValueChange::new(U256::ZERO, U256::from(1000 + i as u64))),
                    nonce: Some(ValueChange::new(0, 1)),
                    code_change: None,
                    storage: BTreeMap::new(),
                },
            );
        }
        StateDiff { accounts }
    }

    #[test]
    fn snapshot_roundtrip() {
        let mut jmt = ShardedJmt::new();
        let diff = make_diff(50);
        jmt.apply_diff(&diff).unwrap();
        let original_root = jmt.root_hash().unwrap();
        let original_version = jmt.version();

        let snapshot = jmt.snapshot().unwrap();
        assert_eq!(snapshot.version, original_version);
        assert_eq!(snapshot.entries.len(), 50);

        let restored = ShardedJmt::from_snapshot(snapshot).unwrap();
        let restored_root = restored.root_hash().unwrap();
        assert_eq!(
            restored_root, original_root,
            "restored root must match original"
        );
        assert_eq!(restored.version(), original_version);
    }

    #[test]
    fn snapshot_restore_rejects_root_mismatch() {
        let mut jmt = ShardedJmt::new();
        jmt.apply_diff(&make_diff(4)).unwrap();

        let mut snapshot = jmt.snapshot().unwrap();
        snapshot.root[0] ^= 0xFF;

        let err = match ShardedJmt::from_snapshot(snapshot) {
            Ok(_) => panic!("restoring a root-mismatched snapshot should fail"),
            Err(err) => err,
        };
        assert!(
            err.to_string().contains("restored snapshot root mismatch"),
            "unexpected error: {err}"
        );
    }

    #[test]
    fn snapshot_file_roundtrip() {
        let mut jmt = ShardedJmt::new();
        let diff = make_diff(100);
        jmt.apply_diff(&diff).unwrap();
        let original_root = jmt.root_hash().unwrap();

        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("jmt.snapshot");

        let snapshot = jmt.snapshot().unwrap();
        save_snapshot(&path, &snapshot).unwrap();

        let loaded = load_snapshot(&path)
            .unwrap()
            .expect("snapshot should exist");
        let restored = ShardedJmt::from_snapshot(loaded).unwrap();
        assert_eq!(restored.root_hash().unwrap(), original_root);
    }

    #[test]
    fn save_snapshot_creates_missing_parent_directories() {
        let mut jmt = ShardedJmt::new();
        jmt.apply_diff(&make_diff(8)).unwrap();

        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("nested").join("state").join("jmt.snapshot");
        let snapshot = jmt.snapshot().unwrap();

        save_snapshot(&path, &snapshot).unwrap();

        assert!(path.exists(), "snapshot file should be created");
        assert!(
            path.parent().unwrap().exists(),
            "missing parent directories should be created"
        );
    }

    #[test]
    fn load_nonexistent_file() {
        let result = load_snapshot(Path::new("/tmp/nonexistent_jmt_snapshot_12345"));
        assert!(result.unwrap().is_none());
    }

    #[test]
    fn load_snapshot_rejects_corrupt_file() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("corrupt.snapshot");
        std::fs::write(&path, b"not-a-zstd-snapshot").unwrap();

        let err = match load_snapshot(&path) {
            Ok(_) => panic!("loading a corrupt snapshot should fail"),
            Err(err) => err,
        };
        assert!(
            err.to_string().contains("Unknown frame descriptor")
                || err.to_string().contains("corrupt")
                || err.to_string().contains("zstd"),
            "unexpected error: {err}"
        );
    }

    #[test]
    fn snapshot_empty_tree() {
        let jmt = ShardedJmt::new();
        let snapshot = jmt.snapshot().unwrap();
        assert!(snapshot.is_empty());
        assert_eq!(snapshot.version, 0);

        let restored = ShardedJmt::from_snapshot(snapshot).unwrap();
        assert_eq!(restored.version(), 0);
    }
}
