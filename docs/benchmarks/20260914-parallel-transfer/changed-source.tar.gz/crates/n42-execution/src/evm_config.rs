use alloy_eips::Decodable2718;
use alloy_primitives::Bytes;
use alloy_rpc_types_engine::ExecutionData;
use reth_chainspec::ChainSpec;
use reth_evm::{
    ConfigureEngineEvm, ConfigureEvm, EvmEnvFor, ExecutableTxIterator, ExecutionCtxFor,
};
use reth_evm_ethereum::EthEvmConfig;
use reth_primitives_traits::{
    BlockTy, HeaderTy, SealedBlock, SealedHeader, SignedTransaction, TxTy,
};
use reth_storage_errors::any::AnyError;
use std::sync::Arc;

use crate::{evm_factory::N42EvmFactory, restored_slots::TrackingBlockExecutorFactory};

/// The inner EthEvmConfig type we delegate to (parameterized with N42EvmFactory).
type InnerConfig = EthEvmConfig<ChainSpec, N42EvmFactory>;

/// N42 EVM configuration wrapping `EthEvmConfig<ChainSpec>`.
/// All `ConfigureEvm` methods delegate to the inner config, except that every
/// block executor is wrapped by [`TrackingBlockExecutorFactory`] so the slots
/// a block changes and restores are recorded for the QMDB root job (see
/// `restored_slots`). Provides a distinct type for N42-specific extensions.
#[derive(Debug, Clone)]
pub struct N42EvmConfig {
    /// Inner Ethereum EVM configuration.
    inner: InnerConfig,
    /// The inner block executor factory, watched for restored slots.
    factory: TrackingBlockExecutorFactory<<InnerConfig as ConfigureEvm>::BlockExecutorFactory>,
}

impl N42EvmConfig {
    /// Creates a new N42 EVM configuration from a chain spec.
    pub fn new(chain_spec: Arc<ChainSpec>) -> Self {
        Self::with_evm_factory(chain_spec, N42EvmFactory::from_env())
    }

    /// Configure the transaction executor while retaining block-level system calls,
    /// receipts, withdrawals and restored-slot tracking.
    pub fn with_evm_factory(chain_spec: Arc<ChainSpec>, evm_factory: N42EvmFactory) -> Self {
        let inner = EthEvmConfig::new_with_evm_factory(chain_spec, evm_factory);
        let factory = TrackingBlockExecutorFactory::new(inner.block_executor_factory().clone());
        Self { inner, factory }
    }

    /// Returns a reference to the inner `EthEvmConfig`.
    pub fn inner(&self) -> &InnerConfig {
        &self.inner
    }

    /// Returns the chain spec.
    pub fn chain_spec(&self) -> &Arc<ChainSpec> {
        self.inner.chain_spec()
    }
}

impl ConfigureEvm for N42EvmConfig {
    type Primitives = <InnerConfig as ConfigureEvm>::Primitives;
    type Error = <InnerConfig as ConfigureEvm>::Error;
    type NextBlockEnvCtx = <InnerConfig as ConfigureEvm>::NextBlockEnvCtx;
    type BlockExecutorFactory =
        TrackingBlockExecutorFactory<<InnerConfig as ConfigureEvm>::BlockExecutorFactory>;
    type BlockAssembler = <InnerConfig as ConfigureEvm>::BlockAssembler;

    fn block_executor_factory(&self) -> &Self::BlockExecutorFactory {
        &self.factory
    }

    fn block_assembler(&self) -> &Self::BlockAssembler {
        self.inner.block_assembler()
    }

    fn evm_env(&self, header: &HeaderTy<Self::Primitives>) -> Result<EvmEnvFor<Self>, Self::Error> {
        self.inner.evm_env(header)
    }

    fn next_evm_env(
        &self,
        parent: &HeaderTy<Self::Primitives>,
        attributes: &Self::NextBlockEnvCtx,
    ) -> Result<EvmEnvFor<Self>, Self::Error> {
        self.inner.next_evm_env(parent, attributes)
    }

    fn context_for_block<'a>(
        &self,
        block: &'a SealedBlock<BlockTy<Self::Primitives>>,
    ) -> Result<ExecutionCtxFor<'a, Self>, Self::Error> {
        self.inner.context_for_block(block)
    }

    fn context_for_next_block(
        &self,
        parent: &SealedHeader<HeaderTy<Self::Primitives>>,
        attributes: Self::NextBlockEnvCtx,
    ) -> Result<ExecutionCtxFor<'_, Self>, Self::Error> {
        self.inner.context_for_next_block(parent, attributes)
    }
}

impl ConfigureEngineEvm<ExecutionData> for N42EvmConfig {
    fn evm_env_for_payload(&self, payload: &ExecutionData) -> Result<EvmEnvFor<Self>, Self::Error> {
        self.inner.evm_env_for_payload(payload)
    }

    fn context_for_payload<'a>(
        &self,
        payload: &'a ExecutionData,
    ) -> Result<ExecutionCtxFor<'a, Self>, Self::Error> {
        self.inner.context_for_payload(payload)
    }

    fn tx_iterator_for_payload(
        &self,
        payload: &ExecutionData,
    ) -> Result<impl ExecutableTxIterator<Self>, Self::Error> {
        let txs = payload.payload.transactions().clone();
        let convert = |tx: Bytes| {
            let tx =
                TxTy::<Self::Primitives>::decode_2718_exact(tx.as_ref()).map_err(AnyError::new)?;
            let signer = tx.try_recover().map_err(AnyError::new)?;
            Ok::<_, AnyError>(tx.with_signer(signer))
        };
        Ok((txs, convert))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use n42_chainspec::{N42_CHAIN_ID, n42_dev_chainspec};

    #[test]
    fn test_evm_config_creation() {
        let chain_spec = n42_dev_chainspec();
        let config = N42EvmConfig::new(chain_spec);

        // Should not panic, and the config should be usable.
        assert_eq!(
            config.chain_spec().chain().id(),
            N42_CHAIN_ID,
            "chain_spec should have N42 chain ID"
        );
    }

    #[test]
    fn test_evm_config_chain_spec() {
        let chain_spec = n42_dev_chainspec();
        let config = N42EvmConfig::new(chain_spec.clone());
        assert!(Arc::ptr_eq(config.chain_spec(), &chain_spec));
    }

    #[test]
    fn test_evm_config_inner() {
        let chain_spec = n42_dev_chainspec();
        let config = N42EvmConfig::new(chain_spec);
        let _inner = config.inner();
    }

    #[test]
    fn test_evm_config_clone() {
        let chain_spec = n42_dev_chainspec();
        let config = N42EvmConfig::new(chain_spec);
        let cloned = config.clone();

        assert_eq!(
            cloned.chain_spec().chain().id(),
            config.chain_spec().chain().id(),
            "cloned config should have the same chain ID"
        );
    }

    #[test]
    fn test_evm_config_debug() {
        let chain_spec = n42_dev_chainspec();
        let config = N42EvmConfig::new(chain_spec);
        let debug_str = format!("{:?}", config);
        assert!(!debug_str.is_empty());
    }
}
