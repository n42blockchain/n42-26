//! Production provider hook + actual payload builder + native QMDB root preparation.
//! The write-once adapter registry lives in this separate test process.
use alloy_consensus::{Header, TxLegacy};
use alloy_primitives::{Address, B256, Bytes, TxKind, U256};
use n42_execution::{N42EvmConfig, N42EvmFactory};
use n42_node::{
    consensus_state::SharedConsensusState,
    exec_cache::{ExecutionOutputCache, RethExecutionOutputCache},
    payload::N42InnerPayloadBuilder,
    qmdb_state_reader::{self, QmdbReadsMode},
    qmdb_state_root::Gov5QmdbStateRootStore,
};
use n42_twig_core::qmdb_compat::{
    QmdbCompatTree, QmdbOperation, encode_gov5_account_value, gov5_account_key,
};
use reth_basic_payload_builder::{BuildArguments, PayloadBuilder, PayloadConfig};
use reth_ethereum_payload_builder::EthereumBuilderConfig;
use reth_ethereum_primitives::{Block, Transaction};
use reth_evm::execute::{BasicBlockExecutor, BlockExecutionOutput, Executor};
use reth_primitives_traits::{
    Block as _, SignedTransaction, crypto::secp256k1::public_key_to_address,
};
use reth_provider::{
    providers::BlockchainProvider, test_utils::create_test_provider_factory_with_chain_spec,
};
use reth_storage_api::{BlockWriter, StateProviderFactory};
use reth_testing_utils::generators::sign_tx_with_key_pair;
use reth_transaction_pool::{
    CoinbaseTipOrdering, EthPooledTransaction, Pool, PoolConfig, PoolTransaction,
    TransactionOrigin, TransactionPool, blobstore::InMemoryBlobStore,
    noop::MockTransactionValidator,
};
use secp256k1::{Keypair, Secp256k1, SecretKey};
use std::sync::Arc;

fn account(tree: &mut QmdbCompatTree, address: Address, nonce: u64, balance: U256) {
    tree.set(
        gov5_account_key(address.as_ref()),
        encode_gov5_account_value(nonce, &balance.to_be_bytes(), &B256::ZERO.0),
    );
}

#[tokio::test]
async fn default_cancun_builder_reads_qmdb_and_prepares_the_native_root() -> eyre::Result<()> {
    let chain = n42_chainspec::n42_dev_chainspec();
    let secp = Secp256k1::new();
    let keys: Vec<_> = [1u8, 2]
        .into_iter()
        .map(|n| Keypair::from_secret_key(&secp, &SecretKey::from_slice(&[n; 32]).unwrap()))
        .collect();
    let senders: Vec<_> = keys
        .iter()
        .map(|key| public_key_to_address(key.public_key()))
        .collect();
    let recipient = Address::repeat_byte(0x33);
    let beneficiary = Address::repeat_byte(0x44);
    let untouched = Address::repeat_byte(0x55);
    let funding = U256::from(1_000_000_000_000_000u64);
    let mut tree = QmdbCompatTree::new();
    for sender in &senders {
        account(&mut tree, *sender, 0, funding);
    }
    account(&mut tree, recipient, 0, U256::from(1));
    account(&mut tree, beneficiary, 0, U256::from(1));
    account(&mut tree, untouched, 7, U256::from(42));
    let base_root = B256::from(tree.root());
    let genesis = Block {
        header: Header {
            state_root: base_root,
            gas_limit: 200_000_000,
            gas_used: 100_000_000,
            base_fee_per_gas: Some(7),
            timestamp: 1_700_000_000,
            blob_gas_used: Some(0),
            excess_blob_gas: Some(0),
            ..Default::default()
        },
        ..Default::default()
    }
    .seal_slow();
    let parent = genesis.hash();
    let factory = create_test_provider_factory_with_chain_spec(chain.clone());
    let writer = factory.provider_rw()?;
    writer.insert_block(&genesis.clone().try_recover()?)?;
    writer.commit()?;
    let provider = BlockchainProvider::new(factory)?;
    assert!(
        provider
            .state_by_block_hash(parent)?
            .basic_account(&senders[0])?
            .is_none()
    );
    let directory = tempfile::tempdir()?;
    let store = Arc::new(Gov5QmdbStateRootStore::persistent(
        parent,
        base_root,
        tree.snapshot(),
        100,
        directory.path().join("state.bin"),
    )?);
    qmdb_state_reader::register(store.clone(), QmdbReadsMode::Only)?;
    let before = qmdb_state_reader::status(Some(parent))?;
    // Use the real in-memory pool and transaction representation. Its test
    // validator supplies admission metadata; every signature is checked below.
    let pool = Pool::new(
        MockTransactionValidator::<EthPooledTransaction>::default(),
        CoinbaseTipOrdering::default(),
        InMemoryBlobStore::default(),
        PoolConfig {
            max_account_slots: 4_096,
            ..Default::default()
        }
        .with_disabled_protocol_base_fee(),
    );
    const PER_SENDER: u64 = 2_048;
    for nonce in 0..PER_SENDER {
        for (key, sender) in keys.iter().zip(&senders) {
            let signed = sign_tx_with_key_pair(
                *key,
                Transaction::Legacy(TxLegacy {
                    chain_id: Some(chain.chain.id()),
                    nonce,
                    gas_price: 9,
                    gas_limit: 21_000,
                    to: TxKind::Call(recipient),
                    value: U256::from(1),
                    input: Bytes::new(),
                }),
            );
            let recovered = signed
                .try_into_recovered()
                .map_err(|_| eyre::eyre!("signature recovery failed"))?;
            assert_eq!(recovered.signer(), *sender);
            pool.add_transaction(
                TransactionOrigin::Local,
                EthPooledTransaction::try_from_consensus(recovered)?,
            )
            .await?;
        }
    }
    assert_eq!(pool.pool_size().pending, 4_096);
    let config =
        N42EvmConfig::with_evm_factory(chain.clone(), N42EvmFactory::with_fast_transfers(false));
    let builder = N42InnerPayloadBuilder::new(
        provider.clone(),
        pool,
        config.clone(),
        EthereumBuilderConfig::new().with_gas_limit(200_000_000),
        Arc::new(SharedConsensusState::new(n42_consensus::ValidatorSet::new(
            &[],
            0,
        ))),
    )
    .with_parallel_transfers(true);
    let attributes = alloy_rpc_types_engine::PayloadAttributes {
        timestamp: 1_700_000_001,
        prev_randao: B256::repeat_byte(1),
        suggested_fee_recipient: beneficiary,
        parent_beacon_block_root: Some(B256::ZERO),
        withdrawals: Some(Default::default()),
        ..Default::default()
    };
    let args = BuildArguments::new(
        Default::default(),
        Default::default(),
        None,
        PayloadConfig::new(
            Arc::new(genesis.clone_sealed_header()),
            attributes,
            Default::default(),
        ),
        Default::default(),
        None,
    );
    let recorder = metrics_util::debugging::DebuggingRecorder::new();
    let payload = metrics::with_local_recorder(&recorder, || builder.try_build(args))?
        .into_payload()
        .ok_or_else(|| eyre::eyre!("no payload"))?;
    assert!(
        recorder
            .snapshotter()
            .snapshot()
            .into_vec()
            .iter()
            .any(
                |(key, _, _, value)| key.key().name() == "n42_parallel_payload_executed_total"
                    && matches!(value, metrics_util::debugging::DebugValue::Counter(4_096))
            )
    );
    assert_eq!(payload.block().body().transactions.len(), 4_096);
    let after = qmdb_state_reader::status(Some(parent))?;
    assert!(after.counters.account_reads > before.counters.account_reads);
    assert_eq!(
        after.counters.read_errors
            + after.counters.provider_errors
            + after.counters.mismatches
            + after.counters.unavailable_providers,
        0
    );
    let hash = payload.block().hash();
    type Cached = (
        BlockExecutionOutput<reth_ethereum_primitives::Receipt>,
        Vec<Address>,
    );
    let (mut cached, _) = reth_evm::payload_cache::take_payload_execution::<Cached>(&hash).unwrap();
    let db = reth_revm::database::StateProviderDatabase::new(provider.state_by_block_hash(parent)?);
    let mut serial = BasicBlockExecutor::new(config, db).execute(payload.recovered_block())?;
    for output in [&mut cached, &mut serial] {
        for reverts in output.state.reverts.iter_mut() {
            reverts.sort_unstable_by_key(|(address, _)| *address);
        }
    }
    assert_eq!(cached.state, serial.state);
    assert_eq!(cached.result, serial.result);
    // The actual normalization bridge consumes the builder's broadcast copy.
    // Compare its binary QMDB candidate root to independently derived balances,
    // including an untouched account that is absent from the Reth database.
    let balances = senders
        .iter()
        .map(|sender| {
            (
                *sender,
                PER_SENDER,
                funding - U256::from(PER_SENDER) * U256::from(21_000 * 9 + 1),
            )
        })
        .chain([
            (recipient, 0, U256::from(4_097)),
            (beneficiary, 0, U256::from(1 + 4_096 * 21_000 * 2u64)),
        ]);
    let mut operations: Vec<_> = balances
        .map(|(address, nonce, balance)| QmdbOperation {
            key: gov5_account_key(address.as_ref()),
            value: Some(encode_gov5_account_value(
                nonce,
                &balance.to_be_bytes(),
                &B256::ZERO.0,
            )),
        })
        .collect();
    // Frozen leaf positions are part of the root: apply the protocol's sorted
    // operation order, not the arbitrary order of the independent balance list.
    operations.sort_unstable_by_key(|operation| operation.key);
    tree.apply_sorted_ops(operations)?;
    let execution = payload.into_execution_data();
    let roots = RethExecutionOutputCache::new(Some(store.clone()), chain)
        .take_gov5_normalization(&execution)
        .ok_or_else(|| eyre::eyre!("native normalization root unavailable"))?;
    assert_eq!(roots.0, B256::from(tree.root()));
    assert_eq!(
        roots.1,
        n42_network::gov5_native_receipts_root(&serial.result.receipts)
    );
    assert_eq!(store.root_for(parent)?, Some(base_root));
    assert_eq!(
        store.root_for(hash)?,
        None,
        "preparing a candidate must not commit it"
    );
    Ok(())
}
