#!/usr/bin/env bash
# Apply the N42 APIs required on top of the reth CI baseline.
set -euo pipefail

script_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
reth_dir=${1:-"$script_dir/../../reth"}
pending=()
for name in reth-payload-transactions-root reth-qmdb-state-reader reth-import-batch; do
    patch_file="$script_dir/../patches/$name.patch"
    if git -C "$reth_dir" apply --reverse --check "$patch_file" 2>/dev/null; then
        echo "Reth $name patch already applied"
    elif git -C "$reth_dir" apply --check "$patch_file"; then
        pending+=("$patch_file")
    else
        echo "Reth patch $name does not match; use the baseline documented in README.md." >&2
        exit 1
    fi
done
# Validate the entire missing set before changing any file.
if ((${#pending[@]})); then
    git -C "$reth_dir" apply --check "${pending[@]}"
    git -C "$reth_dir" apply "${pending[@]}"
fi
